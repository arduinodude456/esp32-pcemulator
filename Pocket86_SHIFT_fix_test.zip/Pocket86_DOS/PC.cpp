#include "PC.h"
#include <string.h>
#ifdef ARDUINO
#include <Arduino.h>
#include <esp_heap_caps.h>
#else
#include <new>
#include <stdlib.h>
#endif

namespace Pocket86 {
namespace {
inline bool tagged(const uint8_t* p) { return (reinterpret_cast<uintptr_t>(p) & 1u) != 0; }
inline uint32_t* words(uint8_t* p) { return reinterpret_cast<uint32_t*>(reinterpret_cast<uintptr_t>(p) & ~(uintptr_t)1); }
inline const uint32_t* words(const uint8_t* p) { return reinterpret_cast<const uint32_t*>(reinterpret_cast<uintptr_t>(p) & ~(uintptr_t)1); }
}

PCMemory::PCMemory() : pages_{}, ramSize_(0), iramPages_(0), allocatedBytes_(0), chunks_{}, chunkCount_(0), swapPath_{}, swapEnabled_(false), swapSlots_(0), slotNext_(0), slotPtr_{}, slotPage_{}, hash_{}, swapIn_(0), swapOut_(0), video_{}, stubs_{}, romTable_{}, romTop_{}
#ifdef ARDUINO
    , swapFile_()
#endif
{
    memset(stubs_, 0xCF, sizeof(stubs_));
    memset(romTable_, 0xFF, sizeof(romTable_));
    memset(romTop_, 0xFF, sizeof(romTop_));
    for (int i = 0; i < MaxSlots; i++) slotPage_[i] = -1;
}

PCMemory::~PCMemory() { release(); }

void PCMemory::release() {
#ifdef ARDUINO
    if (swapFile_) swapFile_.close();
#endif
    for (int i = 0; i < 256; i++) pages_[i] = nullptr;
    for (int i = 0; i < MaxSlots; i++) { slotPtr_[i] = nullptr; slotPage_[i] = -1; }   // slots live inside the chunks freed below
    swapSlots_ = 0; slotNext_ = 0;
    for (uint32_t i = 0; i < chunkCount_; i++) {
#ifdef ARDUINO
        free(chunks_[i]);
#else
        delete[] static_cast<uint8_t*>(chunks_[i]);
#endif
        chunks_[i] = nullptr;
    }
    chunkCount_ = 0;
    ramSize_ = allocatedBytes_ = 0;
    iramPages_ = 0;
}

bool PCMemory::configureSwap(const char* path) {
#ifdef ARDUINO
    strncpy(swapPath_, path, sizeof(swapPath_) - 1);
    swapPath_[sizeof(swapPath_) - 1] = 0;
    swapEnabled_ = true;
    return true;
#else
    (void)path;
    return false;
#endif
}

bool PCMemory::prepareSwap(uint32_t pages) {
#ifdef ARDUINO
    if (!swapEnabled_ || !swapPath_[0] || !swapSlots_) return false;
    if (swapFile_) swapFile_.close();
    SD.remove(swapPath_);                              // start from an all-zero swap file every boot
    File f = SD.open(swapPath_, FILE_WRITE);
    if (!f) return false;
    const uint8_t* zero = slotPtr_[0];                 // a freshly allocated, still zeroed byte page
    for (uint32_t p = 0; p < pages; p++) {
        if (f.write(zero, 4096) != 4096) { f.close(); return false; }
    }
    f.flush();
    f.close();
    swapFile_ = SD.open(swapPath_, "r+");
    return (bool)swapFile_;
#else
    (void)pages;
    return false;
#endif
}

#ifdef ARDUINO
namespace {
// RTC fast memory is reachable by the PRO CPU only; the Arduino loop() runs on the APP CPU.
inline bool cpuUnsafeAddr(const void* p) {
    uintptr_t a = reinterpret_cast<uintptr_t>(p);
    return (a >= 0x3FF80000u && a < 0x3FFA0000u) || (a >= 0x400C0000u && a < 0x400C2000u);
}
}

// Takes as many 4-KiB pages as possible out of one heap capability class.  Memory is requested
// in the biggest blocks the heap can still offer (one header per block instead of per page, and
// no sub-page leftovers), then cut into pages.  keepFree bytes of that class stay untouched.
// Returns the number of pages added; 'tag32' marks them as 32-bit-only (IRAM).
uint32_t PCMemory::grabPages(uint32_t caps, uint32_t keepFree, uint32_t wantPages, uint32_t& got, bool tag32) {
    uint32_t added = 0;
    void* rejects[8]; int nrej = 0;
    while (got < wantPages && chunkCount_ < (uint32_t)MaxChunks) {
        size_t freeNow = heap_caps_get_free_size(caps);
        size_t largest = heap_caps_get_largest_free_block(caps);
        size_t usable = freeNow > keepFree ? freeNow - keepFree : 0;
        size_t bytes = largest < usable ? largest : usable;
        size_t cap = (size_t)(wantPages - got) * 4096u;
        if (bytes > cap) bytes = cap;
        bytes &= ~(size_t)4095;
        uint8_t* p = nullptr;
        for (int tries = 0; bytes >= 4096u && tries < 16; tries++, bytes -= 4096u) {
            p = (uint8_t*)heap_caps_malloc(bytes, caps);
            if (p) break;
        }
        if (!p) break;
        if ((reinterpret_cast<uintptr_t>(p) & 3u) || cpuUnsafeAddr(p)) {   // unusable: hold it so the heap hands out something else
            if (nrej < 8) rejects[nrej++] = p; else free(p);
            if (nrej >= 8) break;
            continue;
        }
        chunks_[chunkCount_++] = p;
        const uint32_t n = (uint32_t)(bytes / 4096u);
        for (uint32_t i = 0; i < n; i++, got++, added++) {
            uint8_t* pg = p + (size_t)i * 4096u;
            if (tag32) {
                uint32_t* w = reinterpret_cast<uint32_t*>(pg);
                for (int k = 0; k < 1024; k++) w[k] = 0;
                pages_[got] = reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(pg) | 1u);
                iramPages_++;
            } else {
                memset(pg, 0, 4096);
                pages_[got] = pg;
            }
            allocatedBytes_ += 4096u;
        }
    }
    for (int i = 0; i < nrej; i++) free(rejects[i]);
    return added;
}
#endif

bool PCMemory::allocate(uint32_t maxKb, uint32_t reserveBytes) {
    if (maxKb > 640) maxKb = 640;
    release();
    const uint32_t wanted = maxKb / 4;
    uint32_t got = 0;
#ifdef ARDUINO
    // 1) PSRAM (if any), 2) internal DRAM down to reserveBytes, 3) every free byte of executable
    //    IRAM as 32-bit-only pages.  Each tier is reported on the serial console.
    uint32_t n;
    if (psramFound()) {
        n = grabPages(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT, 0, wanted, got, false);
        Serial.printf("[Pocket86]   PSRAM : %u KB\n", (unsigned)(n * 4));
    }
    n = grabPages(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT, reserveBytes, wanted, got, false);
    Serial.printf("[Pocket86]   DRAM  : %u KB (kept %u bytes free)\n", (unsigned)(n * 4), (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
    n = grabPages(MALLOC_CAP_EXEC, 0, wanted, got, true);
    Serial.printf("[Pocket86]   IRAM  : %u KB (EXEC heap left %u, largest block %u)\n", (unsigned)(n * 4),
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_EXEC), (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_EXEC));
    // Anything else that is 32-bit capable but not yet taken (other IRAM-like pools); the DRAM reserve is respected.
    n = grabPages(MALLOC_CAP_INTERNAL | MALLOC_CAP_32BIT, reserveBytes, wanted, got, true);
    if (n) Serial.printf("[Pocket86]   other 32-bit memory: %u KB\n", (unsigned)(n * 4));
#else
    (void)reserveBytes;
    for (; got < wanted; got++) {
        uint8_t* p = new (std::nothrow) uint8_t[4096];
        if (!p) break;
        memset(p, 0, 4096);
        chunks_[chunkCount_++] = p;
#ifdef POCKET86_SIM_IRAM_FROM
        if (got >= POCKET86_SIM_IRAM_FROM) { pages_[got] = reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(p) | 1u); iramPages_++; }
        else pages_[got] = p;
#else
        pages_[got] = p;
#endif
        allocatedBytes_ += 4096u;
    }
#endif
#ifdef ARDUINO
    if (got < wanted && swapEnabled_ && got >= 8) {
        // SD swap: the biggest part of the DRAM pages becomes a pool of cache slots.  Every other
        // physical page keeps its fixed place; all remaining 4-KiB pages of the emulated RAM live in
        // the swap file and are paged into the slots on demand (see pageIn()).
        uint32_t byteCount = 0;
        for (uint32_t i = 0; i < got; i++) if (!tagged(pages_[i])) byteCount++;
        uint32_t want = POCKET86_SWAP_SLOTS;
        if (want > (uint32_t)MaxSlots) want = MaxSlots;
        if (want > byteCount / 2) want = byteCount / 2;
        uint16_t orig[MaxSlots];
        for (int i = (int)got - 1; i >= 0 && swapSlots_ < want; i--) {
            if (tagged(pages_[i])) continue;
            orig[swapSlots_] = (uint16_t)i;
            slotPtr_[swapSlots_] = pages_[i];
            slotPage_[swapSlots_] = -1;
            pages_[i] = nullptr;
            swapSlots_++;
        }
        if (swapSlots_ && prepareSwap(wanted)) {
            ramSize_ = wanted * 4096u;
            Serial.printf("[Pocket86]   SD swap: %u KB virtual, %u KB resident, %u pool slots\n", (unsigned)(wanted * 4), (unsigned)((allocatedBytes_ - swapSlots_ * 4096u) / 1024u), (unsigned)swapSlots_);
        } else {
            for (uint8_t s = 0; s < swapSlots_; s++) { pages_[orig[s]] = slotPtr_[s]; slotPtr_[s] = nullptr; }
            swapSlots_ = 0;
            Serial.println("[Pocket86]   SD swap failed (cannot create swap file)");
        }
    }
#endif
    if (!ramSize_) ramSize_ = allocatedBytes_;
    return ramSize_ > 0;
}

namespace {
// Cheap 32-bit digest of a 4-KiB page: lets pageIn() skip the SD write-back of pages that were only read.
inline uint32_t pageHash(const uint8_t* p) {
    const uint32_t* w = reinterpret_cast<const uint32_t*>(p);
    uint32_t h = 2166136261u;
    for (int i = 0; i < 1024; i++) { h = (h ^ w[i]) * 16777619u; h ^= h >> 15; }
    return h;
}
}

// Brings a non-resident page into a pool slot (FIFO replacement) and returns the slot, or nullptr.
// The CPU writes through the page table without telling us, so a victim is written back only if its
// digest differs from the one taken when it was loaded.
uint8_t* PCMemory::pageIn(uint16_t page) const {
#ifdef ARDUINO
    if (!swapSlots_ || !swapFile_ || page >= 160) return nullptr;
    uint8_t s = slotNext_;
    uint8_t* raw = slotPtr_[s];
    int16_t old = slotPage_[s];
    if (old >= 0) {
        if (pageHash(raw) != hash_[old]) {
            if (!swapFile_.seek((uint32_t)old * 4096UL)) return nullptr;
            if (swapFile_.write(raw, 4096) != 4096) return nullptr;
            swapOut_++;
        }
        pages_[old] = nullptr;
        slotPage_[s] = -1;
    }
    if (!swapFile_.seek((uint32_t)page * 4096UL)) return nullptr;
    if (swapFile_.read(raw, 4096) != 4096) return nullptr;
    hash_[page] = pageHash(raw);
    slotPage_[s] = (int16_t)page;
    pages_[page] = raw;
    slotNext_ = (uint8_t)((s + 1u) % swapSlots_);
    swapIn_++;
    return raw;
#else
    (void)page;
    return nullptr;
#endif
}

uint8_t PCMemory::read8(uint32_t a) const {
    a &= 0xFFFFFu;
    uint16_t page = (uint16_t)(a >> 12);
    uint8_t* p = pages_[page];
    if (!p && a < ramSize_) p = pageIn(page);
    if (p) {
        uint32_t o = a & 0xFFF;
        if (!tagged(p)) return p[o];
        return (uint8_t)(words(p)[o >> 2] >> ((o & 3) * 8));
    }
    if (a >= VideoBase && a < VideoBase + VideoSize) { uint32_t o = a - VideoBase; return o < VideoStore ? video_[o] : 0; }
    if (a >= StubBase && a < StubBase + 0x1000u) { uint32_t o = a - StubBase; return o < StubStore ? stubs_[o] : 0xCF; }
    if (a >= TableBase && a < TableBase + 0x40) return romTable_[a - TableBase];
    if (a >= TopBase) return romTop_[a - TopBase];
    return 0xFF;
}

void PCMemory::write8(uint32_t a, uint8_t v) {
    a &= 0xFFFFFu;
    uint16_t page = (uint16_t)(a >> 12);
    uint8_t* p = pages_[page];
    if (!p && a < ramSize_) p = pageIn(page);
    if (p) {
        uint32_t o = a & 0xFFF;
        if (!tagged(p)) { p[o] = v; return; }
        uint32_t* w = words(p); uint32_t sh = (o & 3) * 8;
        w[o >> 2] = (w[o >> 2] & ~(0xFFu << sh)) | ((uint32_t)v << sh);
        return;
    }
    if (a >= VideoBase && a < VideoBase + VideoSize) { uint32_t o = a - VideoBase; if (o < VideoStore) video_[o] = v; return; }
}

bool PCMemory::loadROM(uint32_t a, const uint8_t* d, size_t n) {
    if (a >= StubBase && a + n <= StubBase + StubStore) { memcpy(stubs_ + (a - StubBase), d, n); return true; }
    if (a >= TableBase && a + n <= TableBase + 0x40) { memcpy(romTable_ + (a - TableBase), d, n); return true; }
    if (a >= TopBase && a + n <= 0x100000u) { memcpy(romTop_ + (a - TopBase), d, n); return true; }
    return false;
}
}
