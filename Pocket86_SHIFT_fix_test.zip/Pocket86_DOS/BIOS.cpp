#include "BIOS.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace Pocket86 {

namespace {
const uint16_t kBdaKbdBuf   = 0x1E;     // keyboard ring buffer 0040:001E..003D
const uint16_t kBdaKbdEnd   = 0x3E;
const uint32_t kPitHz       = 1193182UL;
const uint16_t kDisketteTable = 0xEFC7; // F000:EFC7

inline uint8_t hi8(uint16_t v) { return (uint8_t)(v >> 8); }
inline uint8_t lo8(uint16_t v) { return (uint8_t)v; }
inline void setHi(uint16_t& v, uint8_t b) { v = (uint16_t)((v & 0x00FF) | ((uint16_t)b << 8)); }
inline void setLo(uint16_t& v, uint8_t b) { v = (uint16_t)((v & 0xFF00) | b); }
inline void setCF(CPU8086::Registers& r, bool c) { if (c) r.flags |= CPU8086::CF; else r.flags &= (uint16_t)~CPU8086::CF; }
inline void setZF(CPU8086::Registers& r, bool z) { if (z) r.flags |= CPU8086::ZF; else r.flags &= (uint16_t)~CPU8086::ZF; }

CPU8086::TrapResult trapThunk(void* u, CPU8086&, uint16_t id) { return static_cast<BIOS*>(u)->trap(id); }
uint8_t portInThunk(void* u, uint16_t p) { return static_cast<BIOS*>(u)->portRead(p); }
void portOutThunk(void* u, uint16_t p, uint8_t v) { static_cast<BIOS*>(u)->portWrite(p, v); }
int irqThunk(void* u) { return static_cast<BIOS*>(u)->irqAck(); }
}

BIOS::BIOS(CPU8086& cpu, PCMemory& memory, CGA& video, Drives& drives)
    : cpu_(cpu), mem_(memory), cga_(video), drives_(drives), log_(nullptr),
      booted_(false), bootFailed_(false), posted_(false), bootDrive_(0),
      irr_(0), isr_(0), imr_(0), picBase_(8), picIcwStep_(0), picReadIsr_(0),
      reload0_(65536), count0_(65536), reload2_(65536), pitPending_(0), pitFrac_(0), pitTotal_(0),
      pitRw_{3, 3, 3}, pitWritePhase_{0, 0, 0}, pitReadPhase_{0, 0, 0}, pitWriteLatch_{0, 0, 0}, pitReadLatch_{0, 0, 0},
      pitLatched_{false, false, false}, port61_(0), port61Toggle_(0), scancode_(0), cmosIndex_(0),
      hwSc_{}, hwWord_{}, hwHead_(0), hwCnt_(0), curWord_(0), relScan_(0), pendMods_(0), relUs_(0), relActive_(false), held_(false),
      modShift_(false), modCtrl_(false), modAlt_(false) {}

void BIOS::say(const char* fmt, ...) {
    if (!log_) return;
    char buf[120];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
    log_(buf);
}

// ------------------------------------------------------------------ installation / POST

void BIOS::install() {
    cpu_.setTrapHook(trapThunk, this);
    cpu_.setPortCallbacks(portInThunk, portOutThunk, this);
    cpu_.setIrqAck(irqThunk, this);

    // ROM top: reset vector -> F000:1101 (POST trap), date, model byte, diskette parameter table.
    static const uint8_t resetVec[5] = { 0xEA, 0x01, 0x11, 0x00, 0xF0 };
    mem_.loadROM(0xFFFF0, resetVec, sizeof(resetVec));
    static const char date[9] = { '1', '0', '/', '1', '9', '/', '2', '6', 0 };
    mem_.loadROM(0xFFFF5, reinterpret_cast<const uint8_t*>(date), 9);
    static const uint8_t model = 0xFE;                 // PC/XT class machine
    mem_.loadROM(0xFFFFE, &model, 1);
    static const uint8_t table[11] = { 0xAF, 0x02, 0x25, 0x02, 0x12, 0x1B, 0xFF, 0x54, 0xF6, 0x0F, 0x08 };
    mem_.loadROM(0xF0000u + kDisketteTable, table, sizeof(table));
}

void BIOS::post() {
    // interrupt vector table: every vector points at its own trap stub
    for (uint16_t n = 0; n < 256; n++) {
        mem_.write16((uint32_t)n * 4u, (uint16_t)(CPU8086::TrapBase + n));
        mem_.write16((uint32_t)n * 4u + 2u, CPU8086::TrapSegment);
    }
    mem_.write16(0x1E * 4u, kDisketteTable);
    mem_.write16(0x1E * 4u + 2u, CPU8086::TrapSegment);

    // BIOS data area
    for (uint16_t i = 0; i < 0x100; i++) mem_.write8(0x400u + i, 0);
    uint8_t floppies = drives_.floppyCount();
    uint16_t equip = 0x0020;                              // 80x25 colour adapter
    if (floppies) equip |= (uint16_t)(0x0001 | ((floppies - 1) << 6));
    setBda16(0x10, equip);
    setBda16(0x13, (uint16_t)mem_.ramKilobytes());
    setBda16(0x1A, kBdaKbdBuf); setBda16(0x1C, kBdaKbdBuf);
    setBda16(0x80, kBdaKbdBuf); setBda16(0x82, kBdaKbdEnd);
    setBda8(0x49, 3); setBda16(0x4A, 80); setBda16(0x4C, 0x1000); setBda16(0x4E, 0);
    setBda16(0x60, 0x0607); setBda8(0x62, 0); setBda16(0x63, 0x3D4);
    setBda8(0x65, 0x29); setBda8(0x66, 0x30);
    setBda8(0x75, drives_.hardCount());
    setBda8(0x84, 24); setBda16(0x85, 8);
    setBda8(0x96, 0);                                     // no enhanced keyboard
    hwHead_ = hwCnt_ = 0; curWord_ = 0; relActive_ = false; pendMods_ = 0; held_ = false; modShift_ = modCtrl_ = modAlt_ = false;

    // chipset
    irr_ = isr_ = 0; imr_ = 0x00; picBase_ = 8; picIcwStep_ = 0; picReadIsr_ = 0;
    reload0_ = count0_ = 65536; pitPending_ = 0; pitFrac_ = 0;
    for (int i = 0; i < 3; i++) { pitRw_[i] = 3; pitWritePhase_[i] = 0; pitReadPhase_[i] = 0; pitLatched_[i] = false; }
    updateIrq();

    cga_.setMode(0x29, 0x30);
    cga_.clear();
    cga_.setCursorShape(6, 7);
    printString("Pocket86 BIOS - 8086 PC\r\n");
    char line[48];
    snprintf(line, sizeof(line), "%uK RAM  ", (unsigned)mem_.ramKilobytes());
    printString(line);
    snprintf(line, sizeof(line), "FD:%u HD:%u\r\n\r\n", (unsigned)drives_.floppyCount(), (unsigned)drives_.hardCount());
    printString(line);
    posted_ = true;
}

bool BIOS::bootstrap() {
    static const uint8_t order[2] = { 0x00, 0x80 };
    for (int i = 0; i < 2; i++) {
        DiskImage* d = drives_.byBiosNumber(order[i]);
        if (!d || !d->present()) continue;
        uint8_t buf[512];
        if (!d->read(0, buf)) continue;
        if (buf[510] != 0x55 || buf[511] != 0xAA) continue;
        for (int k = 0; k < 512; k++) mem_.write8(0x7C00u + k, buf[k]);
        CPU8086::Registers& r = cpu_.registers();
        memset(&r.w, 0, sizeof(r.w));
        r.dx = order[i];
        r.es = r.ds = r.ss = 0; r.sp = 0x7C00;
        r.cs = 0; r.ip = 0x7C00;
        r.flags = 0xF202;
        bootDrive_ = order[i];
        booted_ = true;
        bootFailed_ = false;
        say("[BIOS] booting from drive %02X", order[i]);
        return true;
    }
    return false;
}

// ------------------------------------------------------------------ time / PIC / PIT

uint32_t BIOS::ticks() const {
    return (uint32_t)mem_.read16(0x46C) | ((uint32_t)mem_.read16(0x46E) << 16);
}

void BIOS::updateIrq() {
    uint8_t pend = (uint8_t)(irr_ & ~imr_);
    bool deliver = false;
    for (int i = 0; i < 8; i++) {
        if (isr_ & (1u << i)) break;
        if (pend & (1u << i)) { deliver = true; break; }
    }
    cpu_.setIrqLine(deliver);
}

int BIOS::irqAck() {
    uint8_t pend = (uint8_t)(irr_ & ~imr_);
    for (int i = 0; i < 8; i++) {
        if (isr_ & (1u << i)) break;
        if (pend & (1u << i)) {
            isr_ |= (uint8_t)(1u << i);
            irr_ &= (uint8_t)~(1u << i);
            if (i == 0 && pitPending_) pitPending_--;
            if (i == 1 && hwCnt_) {                          // keyboard: hand the next scan code to port 60h
                scancode_ = hwSc_[hwHead_]; curWord_ = hwWord_[hwHead_];
                hwHead_ = (uint8_t)((hwHead_ + 1) & 15); hwCnt_--;
                if (hwCnt_) irr_ |= 2;
            }
            updateIrq();
            return picBase_ + i;
        }
    }
    updateIrq();
    return -1;
}

void BIOS::raiseTimer() {
    if (pitPending_ && !(isr_ & 1)) irr_ |= 1;
    updateIrq();
}

uint32_t BIOS::pitCurrent(uint8_t c) const {
    if (c == 0) return count0_;
    if (c == 2) { uint32_t r = reload2_ ? reload2_ : 65536; return r - (uint32_t)(pitTotal_ % r); }
    return (uint32_t)(0x10000 - (pitTotal_ & 0xFFFF));
}

void BIOS::advance(uint32_t us) {
    if (relActive_ && !held_) {                          // auto-release of keys that are not physically held (serial input)
        if (us >= relUs_) releaseKey();
        else relUs_ -= us;
    }
    pitFrac_ += (uint64_t)us * kPitHz;
    uint32_t t = (uint32_t)(pitFrac_ / 1000000ULL);
    pitFrac_ %= 1000000ULL;
    pitTotal_ += t;
    if (t >= count0_) {
        t -= count0_;
        uint32_t wraps = 1 + t / reload0_;
        t %= reload0_;
        count0_ = reload0_ - t;
        pitPending_ += wraps;
        if (pitPending_ > 18) pitPending_ = 18;
    } else {
        count0_ -= t;
    }
    raiseTimer();
}

void BIOS::pitWriteData(uint8_t c, uint8_t v) {
    uint8_t rw = pitRw_[c];
    uint16_t value;
    bool complete = false;
    if (rw == 1) { value = v; complete = true; }
    else if (rw == 2) { value = (uint16_t)(v << 8); complete = true; }
    else {
        if (pitWritePhase_[c] == 0) { pitWriteLatch_[c] = v; pitWritePhase_[c] = 1; return; }
        value = (uint16_t)(pitWriteLatch_[c] | ((uint16_t)v << 8));
        pitWritePhase_[c] = 0;
        complete = true;
    }
    if (!complete) return;
    uint32_t reload = value ? value : 65536;
    if (c == 0) { reload0_ = reload; count0_ = reload; }
    else if (c == 2) reload2_ = reload;
}

uint8_t BIOS::pitReadData(uint8_t c) {
    uint16_t value = pitLatched_[c] ? pitReadLatch_[c] : (uint16_t)pitCurrent(c);
    uint8_t rw = pitRw_[c];
    uint8_t out;
    if (rw == 1) { out = (uint8_t)value; pitLatched_[c] = false; }
    else if (rw == 2) { out = (uint8_t)(value >> 8); pitLatched_[c] = false; }
    else {
        if (pitReadPhase_[c] == 0) { out = (uint8_t)value; pitReadPhase_[c] = 1; }
        else { out = (uint8_t)(value >> 8); pitReadPhase_[c] = 0; pitLatched_[c] = false; }
    }
    return out;
}

// ------------------------------------------------------------------ ports

uint8_t BIOS::portRead(uint16_t p) {
    if (cga_.handlesPort(p)) return cga_.ioRead(p);
    switch (p) {
        case 0x20: return picReadIsr_ ? isr_ : irr_;
        case 0x21: return imr_;
        case 0x40: return pitReadData(0);
        case 0x41: return 0;
        case 0x42: return pitReadData(2);
        case 0x60: return scancode_;
        case 0x61: port61Toggle_ ^= 0x30; return (uint8_t)((port61_ & 0x0F) | port61Toggle_);
        case 0x64: return 0x00;
        case 0x71: return 0x00;
        default: return 0xFF;
    }
}

void BIOS::portWrite(uint16_t p, uint8_t v) {
    if (cga_.handlesPort(p)) { cga_.ioWrite(p, v); return; }
    switch (p) {
        case 0x20:
            if (v & 0x10) { picIcwStep_ = 1; imr_ = 0; isr_ = 0; irr_ = 0; }          // ICW1
            else if (v & 0x08) { if ((v & 0x03) == 0x02) picReadIsr_ = 0; else if ((v & 0x03) == 0x03) picReadIsr_ = 1; }   // OCW3
            else {                                                                      // OCW2: EOI
                if ((v & 0xE0) == 0x20) { for (int i = 0; i < 8; i++) if (isr_ & (1u << i)) { isr_ &= (uint8_t)~(1u << i); break; } }
                else if ((v & 0xE0) == 0x60) isr_ &= (uint8_t)~(1u << (v & 7));
                raiseTimer();
            }
            updateIrq();
            break;
        case 0x21:
            if (picIcwStep_ == 1) { picBase_ = (uint8_t)(v & 0xF8); picIcwStep_ = 2; }
            else if (picIcwStep_ == 2) { picIcwStep_ = 0; /* ICW3/ICW4: nothing to do */ }
            else { imr_ = v; }
            updateIrq();
            break;
        case 0x40: pitWriteData(0, v); break;
        case 0x42: pitWriteData(2, v); break;
        case 0x43: {
            uint8_t sc = v >> 6, rw = (v >> 4) & 3;
            if (sc == 3) break;                                                         // read-back: ignored
            if (rw == 0) { pitReadLatch_[sc] = (uint16_t)pitCurrent(sc); pitLatched_[sc] = true; pitReadPhase_[sc] = 0; }
            else { pitRw_[sc] = rw; pitWritePhase_[sc] = 0; pitReadPhase_[sc] = 0; }
            break;
        }
        case 0x61: port61_ = v; break;
        case 0x70: cmosIndex_ = v & 0x7F; break;
        default: break;
    }
}

// ------------------------------------------------------------------ keyboard

bool BIOS::kbdPeek(uint16_t& key) {
    uint16_t head = bda16(0x1A), tail = bda16(0x1C);
    if (head == tail) return false;
    key = bda16(head);
    return true;
}

uint16_t BIOS::kbdGet() {
    uint16_t head = bda16(0x1A);
    uint16_t key = bda16(head);
    head = (uint16_t)(head + 2);
    if (head >= kBdaKbdEnd) head = kBdaKbdBuf;
    setBda16(0x1A, head);
    return key;
}

bool BIOS::kbdStore(uint16_t word) {
    uint16_t head = bda16(0x1A), tail = bda16(0x1C);
    uint16_t next = (uint16_t)(tail + 2);
    if (next >= kBdaKbdEnd) next = kBdaKbdBuf;
    if (next == head) return false;                        // buffer full
    setBda16(tail, word);
    setBda16(0x1C, next);
    return true;
}

bool BIOS::int9Owned() const {
    return mem_.read16(9u * 4u) == (uint16_t)(CPU8086::TrapBase + 9) && mem_.read16(9u * 4u + 2u) == CPU8086::TrapSegment;
}

// Scan code queue of the keyboard controller. Delivered via IRQ1 -> INT 9; port 60h returns the current code.
void BIOS::hwPush(uint8_t sc, uint16_t word) {
    if (imr_ & 2) { scancode_ = sc; return; }              // IRQ1 masked: program polls port 60h
    if (hwCnt_ >= 16) return;
    if (hwCnt_ == 0) scancode_ = sc;
    uint8_t idx = (uint8_t)((hwHead_ + hwCnt_) & 15);
    hwSc_[idx] = sc; hwWord_[idx] = word; hwCnt_++;
    irr_ |= 2;
    updateIrq();
}

// Break code of the current key, then of the Shift/Ctrl that were made up for it.
void BIOS::releaseKey() {
    if (!relActive_) return;
    relActive_ = false;
    hwPush((uint8_t)(relScan_ | 0x80), 0);
    if (pendMods_ & 2) hwPush(0x9D, 0);
    if (pendMods_ & 1) hwPush(0xAA, 0);
    pendMods_ = 0;
}

// mods: bit0 = key needs Shift, bit1 = key needs Ctrl. Programs reading port 60h / hooking INT 9 only see
// scan codes, so without a Shift/Ctrl make code "A", "!" or Ctrl+C arrive as the plain base key.
bool BIOS::pushKey(uint8_t ascii, uint8_t scan, uint8_t hwScan, uint8_t mods) {
    uint8_t hw = (hwScan == 0xFF) ? scan : hwScan;
    uint16_t word = (uint16_t)(((uint16_t)scan << 8) | ascii);
    bool owned = int9Owned();                              // default BIOS INT 9: fill the buffer right away
    if (hw) {
        uint8_t need = 0;
        // A shifted ASCII character must carry a Shift make/break pair even when
        // the on-screen Shift toggle is already active. Some DOS INT 9 handlers
        // maintain their own modifier state and can miss the earlier toggle event.
        if (mods & 1) need |= 1;
        if (mods & 2) need |= 2;
        if (relActive_ && (relScan_ != hw || need != pendMods_)) releaseKey();   // previous key released
        if ((need & 1) && !(pendMods_ & 1)) { hwPush(0x2A, 0); pendMods_ |= 1; }
        if ((need & 2) && !(pendMods_ & 2)) { hwPush(0x1D, 0); pendMods_ |= 2; }
        hwPush(hw, owned ? 0 : word);                      // user INT 9 hooked: the word is stored when it chains to the BIOS
        relScan_ = hw; relActive_ = true; relUs_ = 60000;
    }
    if (owned || !hw) return kbdStore(word);
    return true;
}

void BIOS::keyRelease() {
    held_ = false;
    releaseKey();
}

void BIOS::setModifiers(bool s, bool c, bool a) {
    uint8_t f = (uint8_t)(bda8(0x17) & 0xF0);
    if (s) f |= 0x02;
    if (c) f |= 0x04;
    if (a) f |= 0x08;
    setBda8(0x17, f);
    if (s != modShift_) { modShift_ = s; hwPush(s ? 0x2A : 0xAA, 0); }
    if (c != modCtrl_)  { modCtrl_ = c;  hwPush(c ? 0x1D : 0x9D, 0); }
    if (a != modAlt_)   { modAlt_ = a;   hwPush(a ? 0x38 : 0xB8, 0); }
}

static uint8_t scanOf(uint8_t ch) {
    static const char* const rows[4] = { "1234567890-=", "qwertyuiop[]", "asdfghjkl;'", "zxcvbnm,./" };
    static const uint8_t base[4] = { 0x02, 0x10, 0x1E, 0x2C };
    if (ch >= 'A' && ch <= 'Z') ch = (uint8_t)(ch + 32);
    switch (ch) {
        case ' ': return 0x39;
        case '\r': case '\n': return 0x1C;
        case 0x1B: return 0x01;
        case 0x08: case 0x7F: return 0x0E;
        case '\t': return 0x0F;
        case '`': return 0x29;
        case '\\': return 0x2B;
    }
    for (int r = 0; r < 4; r++)
        for (int i = 0; rows[r][i]; i++) if ((uint8_t)rows[r][i] == ch) return (uint8_t)(base[r] + i);
    return 0;
}

bool BIOS::pushAlt(uint8_t ch) {
    uint8_t sc = scanOf(ch);
    return sc ? pushKey(0, sc) : false;                    // Alt+key = 00:scan
}

bool BIOS::pushAltScan(uint8_t scan) {
    if (scan >= 0x3B && scan <= 0x44) return pushKey(0, (uint8_t)(scan + 0x2D), scan);   // Alt+F1..F10 = 68h..71h
    return pushKey(0, scan);
}

bool BIOS::pushAscii(uint8_t ch) {
    static const char row0[] = "1234567890-=";   // scan 02..0D
    static const char row0s[] = "!@#$%^&*()_+";
    static const char row1[] = "qwertyuiop[]";    // 10..1B
    static const char row1s[] = "QWERTYUIOP{}";
    static const char row2[] = "asdfghjkl;'";     // 1E..28
    static const char row2s[] = "ASDFGHJKL:\"";
    static const char row3[] = "zxcvbnm,./";      // 2C..35
    static const char row3s[] = "ZXCVBNM<>?";
    if (ch == '\r' || ch == '\n') return pushKey(0x0D, 0x1C);
    if (ch == 0x1B) return pushKey(0x1B, 0x01);
    if (ch == 0x08 || ch == 0x7F) return pushKey(0x08, 0x0E);
    if (ch == '\t') return pushKey(0x09, 0x0F);
    if (ch == ' ') return pushKey(' ', 0x39);
    if (ch == '`') return pushKey(ch, 0x29);
    if (ch == '~') return pushKey(ch, 0x29, 0xFF, 1);
    if (ch == '\\') return pushKey(ch, 0x2B);
    if (ch == '|') return pushKey(ch, 0x2B, 0xFF, 1);
    static const char* const rows[4]  = { row0, row1, row2, row3 };
    static const char* const rowsS[4] = { row0s, row1s, row2s, row3s };
    static const uint8_t base[4] = { 0x02, 0x10, 0x1E, 0x2C };
    for (int r = 0; r < 4; r++)
        for (int i = 0; rows[r][i]; i++) {
            if (ch == (uint8_t)rows[r][i])  return pushKey(ch, (uint8_t)(base[r] + i));
            if (ch == (uint8_t)rowsS[r][i]) return pushKey(ch, (uint8_t)(base[r] + i), 0xFF, 1);   // needs Shift
        }
    if (ch >= 1 && ch <= 26) {                                            // Ctrl+letter
        char letter = (char)('a' + ch - 1);
        for (int r = 1; r < 4; r++)
            for (int i = 0; rows[r][i]; i++) if (letter == rows[r][i]) return pushKey(ch, (uint8_t)(base[r] + i), 0xFF, 2);
    }
    return pushKey(ch, 0);
}

// ------------------------------------------------------------------ video helpers

void BIOS::getCursor(uint8_t p, uint8_t& row, uint8_t& col) const {
    uint16_t v = mem_.read16(0x450u + (p & 7) * 2u);
    col = lo8(v); row = hi8(v);
}

void BIOS::setCursor(uint8_t p, uint8_t row, uint8_t col) {
    p &= 7;
    mem_.write16(0x450u + p * 2u, (uint16_t)(((uint16_t)row << 8) | col));
    if (p == bda8(0x62)) cga_.setCursorCell((uint16_t)(p * 0x800u + (uint16_t)row * 80u + col));
}

void BIOS::setVideoMode(uint8_t mode, bool clear) {
    uint8_t modeReg, colorReg;
    switch (mode) {
        case 4:  modeReg = 0x0A; colorReg = 0x30; break;   // 320x200, 4 colours
        case 5:  modeReg = 0x0E; colorReg = 0x30; break;   // 320x200, colour burst off
        case 6:  modeReg = 0x1E; colorReg = 0x3F; break;   // 640x200, 2 colours
        case 0: case 1: modeReg = 0x28; colorReg = 0x30; mode &= 1; break;
        default: modeReg = 0x29; colorReg = 0x30; mode = 3; break;
    }
    cga_.setMode(modeReg, colorReg);
    setBda8(0x49, mode);
    setBda8(0x65, modeReg);
    setBda8(0x66, colorReg);
    if (clear) clearScreen();
}

void BIOS::clearScreen() {
    if (cga_.graphics()) cga_.clearGraphics(); else cga_.clear(0x07);
    for (int p = 0; p < 8; p++) mem_.write16(0x450u + p * 2u, 0);
    setBda8(0x62, 0);
    setBda16(0x4E, 0);
}

void BIOS::scroll(bool up, uint8_t lines, uint8_t attr, uint8_t top, uint8_t left, uint8_t bottom, uint8_t right) {
    if (cga_.graphics()) {                               // no text rendering in graphics modes: only "clear window" for the full screen
        if (lines == 0 && top == 0 && left == 0 && bottom >= 24 && right >= (cga_.hires() ? 79 : 39)) cga_.clearGraphics();
        return;
    }
    if (bottom > 24) bottom = 24;
    if (right > 79) right = 79;
    if (top > bottom || left > right) return;
    uint8_t* v = page(bda8(0x62));
    uint8_t height = (uint8_t)(bottom - top + 1);
    if (lines == 0 || lines >= height) {
        for (uint8_t r = top; r <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
        return;
    }
    if (up) {
        for (uint8_t r = top; r + lines <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = v[((r + lines) * 80 + c) * 2]; v[(r * 80 + c) * 2 + 1] = v[((r + lines) * 80 + c) * 2 + 1]; }
        for (uint8_t r = (uint8_t)(bottom - lines + 1); r <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
    } else {
        for (int r = bottom; r - lines >= top; r--)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = v[((r - lines) * 80 + c) * 2]; v[(r * 80 + c) * 2 + 1] = v[((r - lines) * 80 + c) * 2 + 1]; }
        for (uint8_t r = top; r < top + lines; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
    }
}

void BIOS::teletype(uint8_t ch, uint8_t pageNo, bool useAttr, uint8_t attr) {
    uint8_t row, col;
    getCursor(pageNo, row, col);
    uint8_t* v = page(pageNo);
    const bool gfx = cga_.graphics();
    const uint8_t cols = (gfx && !cga_.hires()) ? 40 : 80;
    switch (ch) {
        case 0x07: break;
        case 0x08: if (col > 0) col--; break;
        case 0x0A: row++; break;
        case 0x0D: col = 0; break;
        default:
            if (!gfx) {
                v[(row * 80 + col) * 2] = ch;
                if (useAttr) v[(row * 80 + col) * 2 + 1] = attr;
            }                                            // graphics: no ROM font, the cursor just advances
            col++;
            if (col >= cols) { col = 0; row++; }
            break;
    }
    if (row >= 25) { scroll(true, 1, 0x07, 0, 0, 24, 79); row = 24; }
    setCursor(pageNo, row, col);
}

void BIOS::printString(const char* s) { while (*s) teletype((uint8_t)*s++, 0); }

// ------------------------------------------------------------------ INT 10h

CPU8086::TrapResult BIOS::int10() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax), al = lo8(r.ax);
    uint8_t activePage = bda8(0x62);
    switch (ah) {
        case 0x00: {
            uint8_t mode = al & 0x7F;                     // 0-3 text, 4/5/6 CGA graphics, anything else (MDA/EGA/VGA) -> mode 3
            setVideoMode(mode, !(al & 0x80));
            break;
        }
        case 0x01:
            cga_.setCursorShape(hi8(r.cx), lo8(r.cx));
            setBda16(0x60, (uint16_t)((lo8(r.cx) ) | (hi8(r.cx) << 8)));
            break;
        case 0x02: setCursor(hi8(r.bx), hi8(r.dx), lo8(r.dx)); break;
        case 0x03: {
            uint8_t row, col; getCursor(hi8(r.bx), row, col);
            r.dx = (uint16_t)((row << 8) | col);
            r.cx = (uint16_t)((cga_.cursorStartLine() << 8) | cga_.cursorEndLine());
            r.ax = 0;
            break;
        }
        case 0x04: r.ax = 0; break;
        case 0x05: {
            break;                                       // only page 0 exists
        }
        case 0x06: case 0x07: scroll(ah == 0x06, al, hi8(r.bx), hi8(r.cx), lo8(r.cx), hi8(r.dx), lo8(r.dx)); break;
        case 0x0B:                                       // CGA palette: BH=0 background/border colour, BH=1 palette select
            if (hi8(r.bx) == 0) cga_.setMode(cga_.modeControl(), (uint8_t)((cga_.colorControl() & 0xF0) | (lo8(r.bx) & 0x0F)));
            else if (hi8(r.bx) == 1) cga_.setMode(cga_.modeControl(), (uint8_t)((cga_.colorControl() & ~0x20) | ((lo8(r.bx) & 1) ? 0x20 : 0)));
            setBda8(0x66, cga_.colorControl());
            break;
        case 0x0C:                                       // write pixel: AL colour (bit 7 = XOR), CX x, DX y
            if (cga_.graphics()) cga_.putPixel(r.cx, r.dx, al & 0x7F, (al & 0x80) != 0);
            break;
        case 0x0D:                                       // read pixel
            if (cga_.graphics()) setLo(r.ax, cga_.getPixel(r.cx, r.dx));
            break;
        case 0x08: {
            if (cga_.graphics()) { r.ax = 0x0700; break; }
            uint8_t p = hi8(r.bx) & 3, row, col; getCursor(p, row, col);
            uint8_t* v = page(p);
            r.ax = (uint16_t)((v[(row * 80 + col) * 2 + 1] << 8) | v[(row * 80 + col) * 2]);
            break;
        }
        case 0x09: case 0x0A: {
            if (cga_.graphics()) break;                  // no ROM font: nothing is drawn
            uint8_t p = hi8(r.bx) & 3, row, col; getCursor(p, row, col);
            uint8_t* v = page(p);
            uint16_t n = r.cx; uint16_t cell = (uint16_t)(row * 80 + col);
            while (n-- && cell < 2000) {
                v[cell * 2] = al;
                if (ah == 0x09) v[cell * 2 + 1] = lo8(r.bx);
                cell++;
            }
            break;
        }
        case 0x0E: teletype(al, activePage); break;
        case 0x0F: r.ax = (uint16_t)(((cga_.graphics() && !cga_.hires() ? 40 : 80) << 8) | bda8(0x49)); setHi(r.bx, activePage); break;
        case 0x13: {
            uint8_t p = hi8(r.bx) & 3;
            uint8_t savedRow, savedCol; getCursor(p, savedRow, savedCol);
            setCursor(p, hi8(r.dx), lo8(r.dx));
            for (uint16_t i = 0; i < r.cx; i++) {
                uint8_t ch, at;
                if (al & 2) { ch = cpu_.peek8(r.es, (uint16_t)(r.bp + i * 2)); at = cpu_.peek8(r.es, (uint16_t)(r.bp + i * 2 + 1)); }
                else { ch = cpu_.peek8(r.es, (uint16_t)(r.bp + i)); at = lo8(r.bx); }
                if (ch == 7 || ch == 8 || ch == 10 || ch == 13) teletype(ch, p);
                else teletype(ch, p, true, at);
            }
            if (!(al & 1)) setCursor(p, savedRow, savedCol);
            break;
        }
        default: break;                                  // everything else: accepted, ignored
    }
    return CPU8086::TrapReturn;
}

// ------------------------------------------------------------------ INT 13h

uint8_t BIOS::diskResult(uint8_t status, bool setCarry) {
    CPU8086::Registers& r = cpu_.registers();
    setBda8(0x41, status);
    setHi(r.ax, status);
    if (setCarry) setCF(r, status != 0);
    return status;
}

uint8_t BIOS::transfer(DiskImage* d, bool write, uint8_t count, uint16_t cyl, uint8_t head, uint8_t sec, uint16_t seg, uint16_t off, uint8_t& done) {
    done = 0;
    if (!d || !d->present()) return 0x80;
    if (cyl >= d->cylinders() || head >= d->heads() || sec == 0 || sec > d->sectorsPerTrack()) return 0x04;
    if (write && !d->writable()) return 0x03;
    uint32_t lba = ((uint32_t)cyl * d->heads() + head) * d->sectorsPerTrack() + (sec - 1);
    for (uint8_t i = 0; i < count; i++) {
        uint32_t phys = (((uint32_t)seg << 4) + (uint16_t)(off + i * 512u)) & 0xFFFFFu;
        uint8_t* pg = mem_.pagePtr(phys);
        bool direct = pg && ((phys & 0xFFFu) + 512u <= 4096u) && ((uint32_t)(uint16_t)(off + i * 512u) + 512u <= 0x10000u);
        uint8_t* ram = direct ? pg + (phys & 0xFFFu) : nullptr;
        if (write) {
            uint8_t buf[512];
            const uint8_t* src = direct ? ram : buf;
            if (!direct) for (int k = 0; k < 512; k++) buf[k] = mem_.read8((phys + k) & 0xFFFFFu);
            if (!d->write(lba + i, src)) return 0x04;
        } else {
            if (direct) { if (!d->read(lba + i, ram)) return 0x04; }
            else {
                uint8_t buf[512];
                if (!d->read(lba + i, buf)) return 0x04;
                for (int k = 0; k < 512; k++) mem_.write8((phys + k) & 0xFFFFFu, buf[k]);
            }
        }
        done++;
    }
    return 0;
}

CPU8086::TrapResult BIOS::int13() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax), al = lo8(r.ax), dl = lo8(r.dx);
    DiskImage* d = drives_.byBiosNumber(dl);
    bool present = d && d->present();
    uint16_t cyl = (uint16_t)(hi8(r.cx) | ((uint16_t)(lo8(r.cx) & 0xC0) << 2));
    uint8_t sec = lo8(r.cx) & 0x3F, head = hi8(r.dx);

    switch (ah) {
        case 0x00: case 0x0D: case 0x10: case 0x11: case 0x0C: case 0x14:
            diskResult(present ? 0 : 0x80); break;
        case 0x01: {
            uint8_t st = bda8(0x41);
            setHi(r.ax, st); setCF(r, st != 0);
            break;
        }
        case 0x02: case 0x03: case 0x04: {
            uint8_t done = 0, st;
            if (al == 0) st = 0x01;
            else if (ah == 0x04) st = present ? ((cyl < d->cylinders() && head < d->heads() && sec >= 1 && sec <= d->sectorsPerTrack()) ? 0 : 0x04) : 0x80;
            else st = transfer(d, ah == 0x03, al, cyl, head, sec, r.es, r.bx, done);
            if (ah == 0x04) done = al;
            setLo(r.ax, done);
            diskResult(st);
            if (st && ah != 0x04) setLo(r.ax, done);
            break;
        }
        case 0x05: {
            uint8_t st = 0;
            if (!present) st = 0x80;
            else if (!d->writable()) st = 0x03;
            else if (cyl >= d->cylinders() || head >= d->heads()) st = 0x04;
            else {
                uint8_t blank[512]; memset(blank, 0xF6, sizeof(blank));
                uint32_t base = ((uint32_t)cyl * d->heads() + head) * d->sectorsPerTrack();
                for (uint8_t s = 0; s < d->sectorsPerTrack(); s++) d->write(base + s, blank);
            }
            diskResult(st);
            break;
        }
        case 0x08: {
            if (!present) { diskResult(dl & 0x80 ? 0x07 : 0x01); r.cx = r.dx = 0; break; }
            uint16_t maxCyl = (uint16_t)(d->cylinders() - 1);
            r.cx = (uint16_t)(((maxCyl & 0xFF) << 8) | ((maxCyl >> 2) & 0xC0) | d->sectorsPerTrack());
            r.dx = (uint16_t)(((d->heads() - 1) << 8) | (d->isFloppy() ? drives_.floppyCount() : drives_.hardCount()));
            if (d->isFloppy()) { setLo(r.bx, d->floppyType()); r.es = CPU8086::TrapSegment; r.di = kDisketteTable; }
            r.ax = 0;
            setBda8(0x41, 0);
            setCF(r, false);
            break;
        }
        case 0x15: {
            if (!present) { r.ax = 0; setCF(r, false); break; }
            if (d->isFloppy()) { r.ax = 0x0200; setCF(r, false); }
            else { uint32_t s = d->totalSectors(); r.cx = (uint16_t)(s >> 16); r.dx = (uint16_t)s; r.ax = 0x0300; setCF(r, false); }
            break;
        }
        case 0x16: {
            if (!present) { diskResult(0x80); break; }
            if (d->isFloppy() && d->takeChanged()) diskResult(0x06); else diskResult(0);
            break;
        }
        case 0x17: case 0x09: diskResult(present ? 0 : 0x80); break;
        case 0x18: {
            if (!present || !d->isFloppy()) { diskResult(present ? 0x01 : 0x80); break; }
            r.es = CPU8086::TrapSegment; r.di = kDisketteTable; diskResult(0);
            break;
        }
        default:
            diskResult(0x01);                              // invalid function (also: no INT 13h extensions)
            break;
    }
    return CPU8086::TrapReturn;
}

// ------------------------------------------------------------------ INT 16h

CPU8086::TrapResult BIOS::int16h() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax);
    uint16_t key;
    switch (ah) {
        case 0x00: case 0x10:
            if (kbdPeek(key)) { r.ax = kbdGet(); return CPU8086::TrapReturn; }
            return CPU8086::TrapBlock;
        case 0x01: case 0x11:
            if (kbdPeek(key)) { r.ax = key; setZF(r, false); } else setZF(r, true);
            return CPU8086::TrapReturn;
        case 0x02: case 0x12:
            r.ax = (ah == 0x12) ? bda16(0x17) : (uint16_t)bda8(0x17);
            return CPU8086::TrapReturn;
        case 0x05:
            setLo(r.ax, pushKey(lo8(r.cx), hi8(r.cx)) ? 0 : 1);
            return CPU8086::TrapReturn;
        default:
            return CPU8086::TrapReturn;
    }
}

// ------------------------------------------------------------------ INT 1Ah / INT 08h

CPU8086::TrapResult BIOS::int1A() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax);
    if (ah == 0x00) {
        r.dx = bda16(0x6C); r.cx = bda16(0x6E);
        r.ax = (uint16_t)bda8(0x70);
        setBda8(0x70, 0);
    } else if (ah == 0x01) {
        setBda16(0x6C, r.dx); setBda16(0x6E, r.cx); setBda8(0x70, 0);
        setHi(r.ax, 0);
    } else {
        setCF(r, true);                                  // no RTC / PCI BIOS on an XT-class machine
    }
    return CPU8086::TrapReturn;
}

CPU8086::TrapResult BIOS::int08() {
    uint32_t t = ticks() + 1;
    if (t >= 0x1800B0UL) { t = 0; setBda8(0x70, 1); }
    setBda16(0x6C, (uint16_t)t); setBda16(0x6E, (uint16_t)(t >> 16));
    isr_ &= (uint8_t)~1u;                                // end of interrupt for IRQ0
    raiseTimer();
    // chain to the user timer hook INT 1Ch; its IRET returns straight to the interrupted code
    CPU8086::Registers& r = cpu_.registers();
    r.ip = mem_.read16(0x1C * 4u);
    r.cs = mem_.read16(0x1C * 4u + 2u);
    return CPU8086::TrapJumped;
}

// ------------------------------------------------------------------ trap dispatcher

CPU8086::TrapResult BIOS::trap(uint16_t id) {
    CPU8086::Registers& r = cpu_.registers();
    if (id == 0x101 || id == 0x100) {                    // reset vector / boot retry
        if (id == 0x101 || !posted_) post();
        if (bootstrap()) return CPU8086::TrapJumped;
        if (!bootFailed_) { printString("No bootable disk. Mount an image and press any key.\r\n"); say("[BIOS] no bootable disk"); }
        bootFailed_ = true;
        uint16_t key;
        if (kbdPeek(key)) kbdGet();
        r.cs = CPU8086::TrapSegment; r.ip = 0x1100;
        r.flags |= CPU8086::IF;
        cpu_.clearBlocked();
        return CPU8086::TrapBlock;
    }
    switch (id) {
        case 0x06: {
            uint16_t ip = cpu_.peek16(r.ss, r.sp), cs = cpu_.peek16(r.ss, (uint16_t)(r.sp + 2));
            say("[CPU] invalid opcode %02X at %04X:%04X", cpu_.lastInvalidOpcode(), cs, ip);
            cpu_.halt();
            return CPU8086::TrapJumped;
        }
        case 0x08: return int08();
        case 0x09:                                       // BIOS keyboard handler (reached by IRQ1 or chained from a user INT 9)
            if (curWord_) { kbdStore(curWord_); curWord_ = 0; }
            isr_ &= (uint8_t)~2u; updateIrq(); return CPU8086::TrapReturn;
        case 0x10: return int10();
        case 0x11: r.ax = bda16(0x10); return CPU8086::TrapReturn;
        case 0x12: r.ax = bda16(0x13); return CPU8086::TrapReturn;
        case 0x13: return int13();
        case 0x14: setHi(r.ax, 0x80); return CPU8086::TrapReturn;
        case 0x15: setHi(r.ax, 0x86); setCF(r, true); return CPU8086::TrapReturn;
        case 0x16: return int16h();
        case 0x17: setHi(r.ax, 0x01); return CPU8086::TrapReturn;
        case 0x19:
            if (bootstrap()) return CPU8086::TrapJumped;
            return CPU8086::TrapReturn;
        case 0x1A: return int1A();
        default: return CPU8086::TrapReturn;             // unowned vectors behave like IRET
    }
}

} // namespace Pocket86
