#include "TFTVideo.h"
#include <string.h>
#ifdef ARDUINO
#include <Arduino.h>
#endif

namespace Pocket86 {

TFTVideo::TFTVideo(CGA& cga)
    : cga_(cga), shadow_{}, lastCursor_(0xFFFF), lastCursorOn_(false), initialized_(false), viewDirty_(true),
      lastStart_(0xFFFF), visibleRows_(25), firstRow_(0), lastFirstRow_(0), gfxActive_(false), overlay_(nullptr), overlayCtx_(nullptr), lastMode_(0), lastColor_(0), rowHash_{}, statusText_{}
#ifdef ARDUINO
      , tft_(), palette_{}
#endif
{}

void TFTVideo::begin() {
    memset(shadow_, 0xFF, sizeof(shadow_));
#ifdef ARDUINO
    tft_.init();
    tft_.setRotation(1);
    // Self-test, independent of the emulator: colour flashes + text. If you see nothing at all,
    // the problem is TFT_eSPI User_Setup / pins / backlight, not Pocket86.
    tft_.fillScreen(TFT_RED);   delay(200);
    tft_.fillScreen(TFT_GREEN); delay(200);
    tft_.fillScreen(TFT_BLUE);  delay(200);
    tft_.fillScreen(TFT_BLACK);
    tft_.setTextFont(1);
    tft_.setTextColor(TFT_WHITE, TFT_BLACK);
    tft_.setTextSize(3);
    tft_.drawString("POCKET86 TFT OK", 40, 100, 1);
    tft_.setTextSize(1);
    tft_.drawString("480x320 text screen starts after boot...", 40, 140, 1);
    delay(800);
    tft_.fillScreen(TFT_BLACK);
    static const uint8_t rgb[16][3] = {
        {0,0,0},{0,0,170},{0,170,0},{0,170,170},{170,0,0},{170,0,170},{170,85,0},{170,170,170},
        {85,85,85},{85,85,255},{85,255,85},{85,255,255},{255,85,85},{255,85,255},{255,255,85},{255,255,255}};
    for (int i = 0; i < 16; i++) palette_[i] = tft_.color565(rgb[i][0], rgb[i][1], rgb[i][2]);
#endif
    initialized_ = true;
    update();
}

void TFTVideo::drawCell(uint16_t i, bool cursor) {
    // i is the on-screen cell index 0..1999
    uint16_t src = (uint16_t)((cga_.startCell() + i) & 0x7FF);
    const uint8_t* v = cga_.cells();
    uint8_t c = v[src * 2], a = v[src * 2 + 1];
    shadow_[i * 2] = c;
    shadow_[i * 2 + 1] = a;
#ifdef ARDUINO
    uint16_t x = (uint16_t)((i % 80) * 6), y = (uint16_t)(((i / 80) - firstRow_) * 10);
    uint16_t fg = palette_[a & 0x0F], bg = palette_[(a >> 4) & 0x07];
    tft_.setTextSize(1);
    tft_.setTextColor(fg, bg);
    tft_.drawChar((uint16_t)(c ? c : ' '), x, y, 1);
    tft_.fillRect(x, y + 8, 6, 2, bg);
    if (cursor) tft_.fillRect(x, y + 7, 6, 2, fg);
#else
    (void)cursor;
#endif
}

// Graphics output. 320x200 is scaled 1.5x (nearest) to 480x300, 640x200 is squeezed 4:3 horizontally
// (a pixel is lit if any covered source pixel is lit) and scaled 1.5x vertically. Only scanlines whose
// checksum changed are pushed. With the on-screen keyboard open the image is clipped to the area above it.
void TFTVideo::updateGraphics() {
#ifdef ARDUINO
    uint8_t mode = cga_.modeControl(), col = cga_.colorControl();
    uint16_t limit = visibleRows_ >= 25 ? 320 : (uint16_t)(visibleRows_ * 10);
    bool force = viewDirty_ || !gfxActive_ || mode != lastMode_ || col != lastColor_;
    gfxActive_ = true;
    if (force) tft_.fillRect(0, 0, 480, limit, TFT_BLACK);
    lastMode_ = mode; lastColor_ = col; viewDirty_ = false;

    uint8_t idx[4]; cga_.palette(idx);
    uint16_t pal[4];
    for (int i = 0; i < 4; i++) pal[i] = palette_[idx[i] & 15];
    bool hi = cga_.hires();
    const uint8_t* vram = cga_.cells();
    static uint16_t buf[480];
    bool bottomTouched = force;

    for (uint16_t r = 0; r < 200; r++) {
        const uint8_t* row = vram + ((r & 1) ? 0x2000 : 0) + (uint32_t)(r >> 1) * 80;
        uint32_t h = 2166136261u;
        for (uint8_t i = 0; i < 80; i++) h = (h ^ row[i]) * 16777619u;
        if (!force && h == rowHash_[r]) continue;
        uint16_t y0 = (uint16_t)(10 + (3 * r + 1) / 2);
        uint16_t y1 = (uint16_t)(10 + (3 * (r + 1) + 1) / 2 - 1);
        if (y0 >= limit) continue;                       // hidden behind the keyboard: drawn after it closes (force)
        rowHash_[r] = h;
        if (y1 >= limit) y1 = (uint16_t)(limit - 1);
        if (y1 >= 286) bottomTouched = true;
        if (hi) {
            for (uint16_t x = 0; x < 480; x++) {
                uint16_t s0 = (uint16_t)((4 * x) / 3), s1 = (uint16_t)((4 * x + 6) / 3 - 1);
                bool on = false;
                for (uint16_t s = s0; s <= s1; s++) if ((row[s >> 3] >> (7 - (s & 7))) & 1) { on = true; break; }
                buf[x] = pal[on ? 1 : 0];
            }
        } else {
            for (uint16_t x = 0; x < 480; x++) {
                uint16_t s = (uint16_t)((x * 2) / 3);
                buf[x] = pal[(row[s >> 2] >> (6 - 2 * (s & 3))) & 3];
            }
        }
        for (uint16_t y = y0; y <= y1; y++) tft_.pushImage(0, y, 480, 1, buf);
    }
    if (bottomTouched && overlay_) overlay_(overlayCtx_);   // the graphics image covers the KBD/DISK handles: paint them again
#endif
}

void TFTVideo::update() {
    if (!initialized_) return;
    if (cga_.graphics()) { updateGraphics(); return; }
    if (gfxActive_) {                                    // back to text: wipe the graphics image
        gfxActive_ = false;
#ifdef ARDUINO
        if (visibleRows_ >= 25) { tft_.fillScreen(TFT_BLACK); drawStatus(0); drawStatus(1); }
        else tft_.fillRect(0, 0, 480, (int32_t)visibleRows_ * 10, TFT_BLACK);
#endif
        viewDirty_ = true;
        lastStart_ = 0xFFFF;
    }
    uint16_t start = cga_.startCell();
    uint16_t cur = cga_.cursorCell();
    bool curOn = cga_.cursorVisible();
    uint16_t curIdx = (uint16_t)((cur - start) & 0x7FF);          // on-screen index of the cursor
    bool curValid = curOn && curIdx < 2000;

    // keep the cursor row inside the visible window
    uint8_t curRow = (uint8_t)((curIdx < 2000 ? curIdx : 0) / 80);
    if (visibleRows_ >= 25) firstRow_ = 0;
    else if (curRow < firstRow_) firstRow_ = curRow;
    else if (curRow >= firstRow_ + visibleRows_) firstRow_ = (uint8_t)(curRow - visibleRows_ + 1);

    bool force = (start != lastStart_) || (firstRow_ != lastFirstRow_) || viewDirty_;
    if (viewDirty_) {
#ifdef ARDUINO
        tft_.fillRect(0, 0, 480, (int32_t)visibleRows_ * 10, TFT_BLACK);
#endif
    }
    const uint8_t* v = cga_.cells();
    uint16_t first = (uint16_t)firstRow_ * 80, last = (uint16_t)(firstRow_ + visibleRows_) * 80;
    if (last > 2000) last = 2000;
    for (uint16_t i = first; i < last; i++) {
        uint16_t src = (uint16_t)((start + i) & 0x7FF);
        uint8_t c = v[src * 2], a = v[src * 2 + 1];
        bool isCursor = curValid && i == curIdx;
        bool wasCursor = lastCursorOn_ && i == (uint16_t)((lastCursor_ - lastStart_) & 0x7FF) && lastStart_ == start;
        if (force || c != shadow_[i * 2] || a != shadow_[i * 2 + 1] || isCursor != wasCursor) drawCell(i, isCursor);
    }
    lastStart_ = start;
    lastFirstRow_ = firstRow_;
    lastCursor_ = cur;
    lastCursorOn_ = curValid;
    viewDirty_ = false;
}

void TFTVideo::drawStatus(uint8_t line) {
#ifdef ARDUINO
    if (visibleRows_ < 25 || gfxActive_) return;         // hidden behind the keyboard / graphics image
    uint16_t y = (uint16_t)(262 + line * 12);
    tft_.setTextSize(1);
    tft_.setTextColor(palette_[8], TFT_BLACK);
    tft_.fillRect(0, y, 480, 10, TFT_BLACK);
    tft_.drawString(statusText_[line], 0, y, 1);
#else
    (void)line;
#endif
}

void TFTVideo::status(const char* text, uint8_t line) {
    if (line > 1) line = 1;
    strncpy(statusText_[line], text, sizeof(statusText_[line]) - 1);
    drawStatus(line);
}

void TFTVideo::refreshAll() {
#ifdef ARDUINO
    tft_.fillScreen(TFT_BLACK);
#endif
    viewDirty_ = true;
    lastStart_ = 0xFFFF;
    drawStatus(0);
    drawStatus(1);
    update();
}

void TFTVideo::setVisibleRows(uint8_t rows) {
    if (rows > 25) rows = 25;
    if (rows == visibleRows_) return;
    bool grow = rows > visibleRows_;
    visibleRows_ = rows;
    viewDirty_ = true;
#ifdef ARDUINO
    if (grow) {
        tft_.fillRect(0, 250, 480, 70, TFT_BLACK);        // wipe the keyboard area
        drawStatus(0);
        drawStatus(1);
    }
#endif
}

} // namespace Pocket86
