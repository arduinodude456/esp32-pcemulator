#pragma once
#include "TFTVideo.h"
#include "BIOS.h"
#include <stdint.h>

namespace Pocket86 {

// Touch keyboard that slides over the lower half of the screen (480x180 px, 5 rows, 15 units wide).
// A small "KBD" handle at the bottom right opens it, the "Hide" key closes it.
// Layers: main (QWERTY + arrows) and Fn (F1-F10, PgUp/PgDn, Home/End/Ins/Del, symbols).
//
// Touch source (compile-time):
//   default                   TFT_eSPI touch (needs TOUCH_CS etc. in User_Setup.h); calibration data is
//                             stored in NVS (Preferences "touch"/"cal", same as the VideoPlayer sketch); asked for on the
//                             first start, or when the screen is touched during start-up.
//   -DPOCKET86_CUSTOM_TOUCH   your own function:  bool pocket86ReadTouch(int16_t* x, int16_t* y);
//                             returns true while the screen is pressed, coordinates in 480x320 landscape.
class OnScreenKeyboard {
public:
    OnScreenKeyboard(TFTVideo& video, BIOS& bios);
    void begin();                // touch setup / calibration (call right after display.begin(), before SD.begin)
    void calibrate();            // interactive calibration (TFT_eSPI touch only)
    void poll();                 // call from loop()
    bool visible() const { return visible_; }
    void show(bool on);
    bool touchAvailable() const { return touchOk_; }
    typedef void (*Handler)();
    void setDiskHandler(Handler h) { diskHandler_ = h; }      // called when the DISK button is tapped
    bool pointer(int16_t& x, int16_t& y) { return touchOk_ && readTouch(x, y); }   // raw touch for other screens
    void redraw();                                            // repaint keyboard or handle after another screen used the TFT

    struct Key { const char* label; uint8_t kind; uint8_t code; uint8_t units; };

private:
    TFTVideo& video_;
    BIOS& bios_;
    bool visible_, touchOk_, down_, fnLayer_, shift_, ctrl_, alt_;
    uint8_t pressedRow_, pressedIdx_;
    bool hasPressed_;
    uint32_t lastPoll_, repeatAt_;
    Handler diskHandler_;

    static const uint8_t kRows = 5;
    const Key* rowKeys(uint8_t row, uint8_t& count) const;
    bool readTouch(int16_t& x, int16_t& y);
    bool hit(int16_t x, int16_t y, uint8_t& row, uint8_t& idx) const;
    void keyRect(uint8_t row, uint8_t idx, int16_t& x, int16_t& y, int16_t& w, int16_t& h) const;
    void drawKey(uint8_t row, uint8_t idx, bool pressed);
    void drawAll();
    void drawHandle();
    void fire(const Key& k);
    void sendChar(uint8_t c);
    void syncMods();
    static void overlayThunk(void* self);
};

} // namespace Pocket86
