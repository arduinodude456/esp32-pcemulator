#pragma once
#include "Memory.h"
#include <stdint.h>
#include <stddef.h>
#ifdef ARDUINO
#include <SD.h>
#endif

#ifndef POCKET86_SWAP_SLOTS
#define POCKET86_SWAP_SLOTS 16     // 4-KiB DRAM cache slots for the SD swap (more = fewer SD accesses, less resident RAM)
#endif

namespace Pocket86 {

// IBM-PC style physical memory map:
//   00000h .. ramSize-1     conventional RAM (4 KiB pages, up to 640 KiB)
//   B8000h ..               CGA video RAM, 16 KiB (text page 0 uses the first 4 KiB; graphics modes use all of it)
//   F1000h .. F11FFh        BIOS trap stubs (every byte is an IRET opcode)
//   FEFC0h .. FEFFFh        BIOS ROM: diskette parameter table
//   FFFC0h .. FFFFFh        BIOS ROM: reset vector, date, model byte
// Everything else reads as 0xFF and ignores writes (open bus).
//
// Page table entries are plain pointers, except that bit 0 set marks a page in 32-bit-only
// memory (ESP32 IRAM): such pages may only be touched with aligned 32-bit accesses.
class PCMemory final : public Memory {
public:
    static const uint32_t VideoBase  = 0xB8000u;
    static const uint32_t VideoSize  = 0x4000u;   // address window
    static const uint32_t VideoStore = 0x4000u;   // bytes actually stored (16 KiB: CGA graphics frame buffer)
    static const uint32_t StubBase   = 0xF1000u;
    static const uint32_t StubStore  = 0x0200u;
    static const uint32_t TableBase  = 0xFEFC0u;
    static const uint32_t TopBase    = 0xFFFC0u;

    PCMemory();
    ~PCMemory();

    // Allocates conventional RAM page by page (4 KiB each) up to maxKilobytes (<=640).
    // On ESP32: normal byte-addressable pages first; if more is wanted, the remaining pages
    // come from executable IRAM with aligned 32-bit accesses (or PSRAM if present).
    // Returns true if anything was allocated; ramKilobytes() tells how much.
    bool allocate(uint32_t maxKilobytes, uint32_t reserveBytes = 0);
    bool configureSwap(const char* path);
    uint32_t swapSlots() const { return swapSlots_; }
    uint32_t swapIns() const { return swapIn_; }
    uint32_t swapOuts() const { return swapOut_; }
    uint32_t residentKilobytes() const { return (allocatedBytes_ - (uint32_t)swapSlots_ * 4096u) / 1024u; }
    void release();
    uint32_t ramKilobytes() const { return ramSize_ / 1024u; }
    uint32_t iramKilobytes() const { return iramPages_ * 4u; }
    uint32_t dramKilobytes() const { return (allocatedBytes_ / 1024u) - iramPages_ * 4u; }

    uint8_t read8(uint32_t address) const override;
    void write8(uint32_t address, uint8_t value) override;
    uint8_t* const* pageTable() const override { return pages_; }
    // Direct pointer to a normal (byte-accessible) RAM page, or nullptr.
    uint8_t* pagePtr(uint32_t address) const {
        uint8_t* p = pages_[(address & 0xFFFFFu) >> 12];
        return (reinterpret_cast<uintptr_t>(p) & 1u) ? nullptr : p;
    }

    uint8_t* video() { return video_; }
    const uint8_t* video() const { return video_; }

    // Copies bytes into the ROM / stub areas (BIOS image setup).
    bool loadROM(uint32_t address, const uint8_t* data, size_t length);

private:
    mutable uint8_t* pages_[256];
    uint32_t ramSize_;
    uint32_t iramPages_;
    uint32_t allocatedBytes_;
#ifdef ARDUINO
    static const int MaxChunks = 24;     // RAM comes in a few big heap blocks (no per-page heap headers)
#else
    static const int MaxChunks = 256;
#endif
    void* chunks_[MaxChunks];
    uint32_t chunkCount_;
    char swapPath_[48];
    bool swapEnabled_;
    static const int MaxSlots = 24;
    uint8_t swapSlots_;                   // pool of byte-accessible 4-KiB cache slots for swapped pages
    mutable uint8_t slotNext_;            // FIFO replacement hand
    uint8_t* slotPtr_[MaxSlots];
    mutable int16_t slotPage_[MaxSlots];  // virtual page held by each slot, -1 if free
    mutable uint32_t hash_[160];          // digest of each swapped page as loaded (write-back only if changed)
    mutable uint32_t swapIn_, swapOut_;
#ifdef ARDUINO
    mutable File swapFile_;
#endif
    uint8_t video_[VideoStore];
    uint8_t stubs_[StubStore];
    uint8_t romTable_[0x40];
    uint8_t romTop_[0x40];

#ifdef ARDUINO
    uint32_t grabPages(uint32_t caps, uint32_t keepFree, uint32_t wantPages, uint32_t& got, bool tag32);
#endif
    uint8_t* pageIn(uint16_t page) const;
    bool prepareSwap(uint32_t pages);
};

} // namespace Pocket86
