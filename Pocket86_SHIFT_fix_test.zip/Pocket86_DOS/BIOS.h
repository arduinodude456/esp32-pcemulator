#pragma once
#include "CPU8086.h"
#include "PC.h"
#include "CGA.h"
#include "Disk.h"
#include <stdint.h>

namespace Pocket86 {

// PC/XT-class BIOS plus the small amount of chipset DOS needs (8259 PIC, 8253 PIT,
// keyboard port, CGA ports). All BIOS services are C++ code reached through CPU traps:
// every interrupt vector initially points at F000:(1000h+n); when DOS or an application
// chains to the original vector, the service still runs.
class BIOS {
public:
    typedef void (*LogFn)(const char* line);

    BIOS(CPU8086& cpu, PCMemory& memory, CGA& video, Drives& drives);

    void install();                 // hooks CPU callbacks, loads the ROM tables
    void advance(uint32_t micros);  // real (or virtual) time, drives the PIT / IRQ0
    void setLogger(LogFn fn) { log_ = fn; }

    // Keyboard input (feeds the BIOS keyboard buffer at 0040:001E).
    bool pushKey(uint8_t ascii, uint8_t scan, uint8_t hwScan = 0xFF, uint8_t mods = 0);   // hwScan: scan code seen on port 60h (default = scan)
    bool pushAlt(uint8_t ch);                  // Alt+key (BIOS word = 00:scan)
    bool pushAltScan(uint8_t scan);            // Alt+F-key / Alt+extended key
    void setModifiers(bool shift, bool ctrl, bool alt);   // BDA 0040:0017 flags + port 60h make/break codes
    void keyHold(bool on) { held_ = on; }      // key stays "down" (no break code) until keyRelease()
    void keyRelease();                         // send the break code of the last key
    bool pushAscii(uint8_t ch);                // ASCII with automatic scan code
    bool pushScan(uint8_t scan) { return pushKey(0, scan); }   // extended key (arrows, F-keys)

    bool bootFailed() const { return bootFailed_; }
    bool booted() const { return booted_; }
    uint8_t bootDrive() const { return bootDrive_; }
    uint32_t ticks() const;

    // ---- internals used by the static callbacks
    CPU8086::TrapResult trap(uint16_t id);
    uint8_t portRead(uint16_t port);
    void portWrite(uint16_t port, uint8_t value);
    int irqAck();

private:
    CPU8086& cpu_;
    PCMemory& mem_;
    CGA& cga_;
    Drives& drives_;
    LogFn log_;

    bool booted_, bootFailed_, posted_;
    uint8_t bootDrive_;

    // 8259
    uint8_t irr_, isr_, imr_, picBase_, picIcwStep_, picReadIsr_;
    // 8253
    uint32_t reload0_, count0_, reload2_;
    uint32_t pitPending_;
    uint64_t pitFrac_, pitTotal_;
    uint8_t pitRw_[3], pitWritePhase_[3], pitReadPhase_[3];
    uint16_t pitWriteLatch_[3], pitReadLatch_[3];
    bool pitLatched_[3];
    // misc ports
    uint8_t port61_, port61Toggle_, scancode_, cmosIndex_;
    // keyboard controller: scan code queue -> IRQ1 -> INT 9 / port 60h (needed by programs that hook INT 9, e.g. CGA games)
    uint8_t hwSc_[16];
    uint16_t hwWord_[16];
    uint8_t hwHead_, hwCnt_;
    uint16_t curWord_;                         // BIOS key word to store when the BIOS INT 9 handler runs (0 = none)
    uint8_t relScan_, pendMods_;               // pendMods_: bit0 = Shift, bit1 = Ctrl made up for the current key (released with it)
    uint32_t relUs_;
    bool relActive_, held_, modShift_, modCtrl_, modAlt_;
    void hwPush(uint8_t scan, uint16_t word);
    void releaseKey();
    bool kbdStore(uint16_t word);
    bool int9Owned() const;

    void say(const char* fmt, ...);
    void post();
    bool bootstrap();
    void updateIrq();
    void raiseTimer();
    uint32_t pitCurrent(uint8_t counter) const;
    void pitWriteData(uint8_t counter, uint8_t v);
    uint8_t pitReadData(uint8_t counter);

    // BDA helpers
    uint8_t bda8(uint16_t off) const { return mem_.read8(0x400u + off); }
    uint16_t bda16(uint16_t off) const { return mem_.read16(0x400u + off); }
    void setBda8(uint16_t off, uint8_t v) { mem_.write8(0x400u + off, v); }
    void setBda16(uint16_t off, uint16_t v) { mem_.write16(0x400u + off, v); }

    // keyboard buffer
    bool kbdPeek(uint16_t& key);
    uint16_t kbdGet();

    // services
    CPU8086::TrapResult int10();
    CPU8086::TrapResult int13();
    CPU8086::TrapResult int16h();
    CPU8086::TrapResult int1A();
    CPU8086::TrapResult int08();

    // video helpers
    uint8_t* page(uint8_t) { return mem_.video(); }   // only text page 0 is stored
    void getCursor(uint8_t p, uint8_t& row, uint8_t& col) const;
    void setCursor(uint8_t p, uint8_t row, uint8_t col);
    void scroll(bool up, uint8_t lines, uint8_t attr, uint8_t top, uint8_t left, uint8_t bottom, uint8_t right);
    void teletype(uint8_t ch, uint8_t pageNo, bool useAttr = false, uint8_t attr = 0x07);
    void printString(const char* s);
    void clearScreen();
    void setVideoMode(uint8_t mode, bool clear);
    uint8_t diskResult(uint8_t status, bool setCarry = true);
    uint8_t transfer(DiskImage* d, bool write, uint8_t count, uint16_t cyl, uint8_t head, uint8_t sec, uint16_t seg, uint16_t off, uint8_t& done);
};

} // namespace Pocket86
