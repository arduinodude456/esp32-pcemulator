#pragma once
#include "Memory.h"
#include <stdint.h>
#include <stddef.h>

#ifndef POCKET86_CPU_186
#define POCKET86_CPU_186 0
#endif

namespace Pocket86 {

// 8086 real-mode CPU core.
//  * Implements the complete 8086 instruction set. The 80186 additions (PUSHA/POPA, BOUND,
//    PUSH imm, IMUL imm, INS/OUTS, shifts by imm8, ENTER, LEAVE) are also decoded so that
//    software built for a V20/186 still runs.
//  * Reports itself as a genuine 8086 to CPU-detection code: PUSH SP pushes the already
//    decremented SP, shift counts are not masked, FLAGS bits 12-15 always read as 1.
//    Define POCKET86_CPU_186=1 to get 80186 behaviour instead.
//  * No DOS knowledge anywhere. BIOS services are reached through "traps": the BIOS
//    points interrupt vectors into a stub area (F000:1000..11FF) and the CPU calls a
//    host hook when execution reaches that area.
class CPU8086 {
public:
    enum Flag : uint16_t {
        CF = 0x0001, PF = 0x0004, AF = 0x0010, ZF = 0x0040,
        SF = 0x0080, TF = 0x0100, IF = 0x0200, DF = 0x0400, OF = 0x0800
    };

    struct Registers {
        union { struct { uint16_t ax, cx, dx, bx, sp, bp, si, di; }; uint16_t w[8]; };
        union { struct { uint16_t es, cs, ss, ds; }; uint16_t s[4]; };
        uint16_t ip, flags;
    };

    enum TrapResult { TrapReturn, TrapBlock, TrapJumped };

    static const uint16_t TrapSegment = 0xF000;
    static const uint16_t TrapBase    = 0x1000;
    static const uint16_t TrapCount   = 0x0200;

    using PortIn    = uint8_t (*)(void*, uint16_t);
    using PortOut   = void (*)(void*, uint16_t, uint8_t);
    using Trace     = void (*)(void*, const Registers&, uint8_t);
    using TrapHook  = TrapResult (*)(void*, CPU8086&, uint16_t);
    using IrqAck    = int (*)(void*);

    explicit CPU8086(Memory& memory);

    void reset();                       // CS:IP = FFFF:0000
    bool step();                        // one instruction (or one trap / one idle poll)
    uint64_t run(uint64_t maxInstructions);

    void setPortCallbacks(PortIn in, PortOut out, void* user = nullptr);
    void setTrapHook(TrapHook hook, void* user = nullptr) { trapHook_ = hook; trapUser_ = user; }
    void setIrqAck(IrqAck ack, void* user = nullptr)      { irqAck_ = ack; irqUser_ = user; }
    void setIrqLine(bool asserted) { irqLine_ = asserted; }
    void setTrace(Trace trace, void* user = nullptr) { trace_ = trace; traceUser_ = user; }

    // Software interrupt entry (used by the BIOS to chain into a vector).
    void interrupt(uint8_t number);
    void push(uint16_t v);
    uint16_t pop();

    const Registers& registers() const { return r_; }
    Registers& registers() { return r_; }
    Memory& memory() { return mem_; }

    void halt() { halted_ = true; }
    bool halted() const { return halted_; }
    bool blocked() const { return blocked_; }
    void clearBlocked() { blocked_ = false; }
    uint64_t instructionCount() const { return instructionCount_; }
    uint32_t invalidCount() const { return invalidCount_; }
    uint8_t lastInvalidOpcode() const { return lastInvalid_; }
    uint32_t lastInvalidAddress() const { return lastInvalidAddr_; }

    uint32_t physical(uint16_t segment, uint16_t offset) const { return (((uint32_t)segment << 4) + offset) & 0xFFFFFu; }
    uint8_t peek8(uint16_t segment, uint16_t offset) const { return rd8(physical(segment, offset)); }
    uint16_t peek16(uint16_t segment, uint16_t offset) const { return (uint16_t)(peek8(segment, offset) | (peek8(segment, (uint16_t)(offset + 1)) << 8)); }

private:
    Memory& mem_;
    Registers r_;
    uint8_t* const* pages_;

    bool halted_, blocked_, irqLine_, inhibit_;
    uint64_t instructionCount_;
    uint32_t invalidCount_;
    uint8_t lastInvalid_;
    uint32_t lastInvalidAddr_;

    PortIn portIn_; PortOut portOut_; void* portUser_;
    Trace trace_; void* traceUser_;
    TrapHook trapHook_; void* trapUser_;
    IrqAck irqAck_; void* irqUser_;

    // per-instruction decode state
    int segOv_;              // -1 none, else 0..3 (ES CS SS DS)
    uint8_t rep_;            // 0 none, 1 REP/REPE, 2 REPNE
    uint16_t instrStart_;
    bool eaIsReg_;
    uint8_t eaReg_;
    uint16_t eaSeg_, eaOff_;

    inline uint8_t rd8(uint32_t a) const {
        a &= 0xFFFFFu;
        uint8_t* p = pages_ ? pages_[a >> 12] : nullptr;
        if (!p) return mem_.read8(a);
        uintptr_t u = reinterpret_cast<uintptr_t>(p);
        uint32_t o = a & 0xFFF;
        if (!(u & 1)) return p[o];
        return (uint8_t)(reinterpret_cast<const uint32_t*>(u & ~(uintptr_t)1)[o >> 2] >> ((o & 3) * 8));   // 32-bit-only page
    }
    inline void wr8(uint32_t a, uint8_t v) {
        a &= 0xFFFFFu;
        uint8_t* p = pages_ ? pages_[a >> 12] : nullptr;
        if (!p) { mem_.write8(a, v); return; }
        uintptr_t u = reinterpret_cast<uintptr_t>(p);
        uint32_t o = a & 0xFFF;
        if (!(u & 1)) { p[o] = v; return; }
        uint32_t* w = reinterpret_cast<uint32_t*>(u & ~(uintptr_t)1);
        uint32_t sh = (o & 3) * 8;
        w[o >> 2] = (w[o >> 2] & ~(0xFFu << sh)) | ((uint32_t)v << sh);
    }
    inline uint8_t rdS8(uint16_t s, uint16_t o) const { return rd8(((uint32_t)s << 4) + o); }
    inline uint16_t rdS16(uint16_t s, uint16_t o) const { return (uint16_t)(rdS8(s, o) | ((uint16_t)rdS8(s, (uint16_t)(o + 1)) << 8)); }
    inline void wrS8(uint16_t s, uint16_t o, uint8_t v) { wr8(((uint32_t)s << 4) + o, v); }
    inline void wrS16(uint16_t s, uint16_t o, uint16_t v) { wrS8(s, o, (uint8_t)v); wrS8(s, (uint16_t)(o + 1), (uint8_t)(v >> 8)); }

    inline uint8_t fetch8() { uint8_t v = rdS8(r_.cs, r_.ip); r_.ip++; return v; }
    inline uint16_t fetch16() { uint16_t lo = fetch8(); return (uint16_t)(lo | ((uint16_t)fetch8() << 8)); }

    inline uint8_t reg8(uint8_t n) const { return reinterpret_cast<const uint8_t*>(r_.w)[((n & 3) << 1) | (n >> 2)]; }
    inline void setReg8(uint8_t n, uint8_t v) { reinterpret_cast<uint8_t*>(r_.w)[((n & 3) << 1) | (n >> 2)] = v; }

    void decodeModRM(uint8_t modrm);
    uint8_t getRM8();   uint16_t getRM16();
    void setRM8(uint8_t v);  void setRM16(uint16_t v);
    inline uint16_t srcSeg() const { return segOv_ >= 0 ? r_.s[segOv_] : r_.ds; }

    inline bool flag(uint16_t f) const { return (r_.flags & f) != 0; }
    inline void setFlag(uint16_t f, bool v) { if (v) r_.flags |= f; else r_.flags &= (uint16_t)~f; }
    static inline bool parityEven(uint8_t v) { return ((0x6996u >> ((v ^ (v >> 4)) & 0xF)) & 1u) == 0; }
    void setSZP(uint16_t result, bool word);
    uint16_t alu(uint8_t kind, uint16_t a, uint16_t b, bool word);
    uint16_t incdec(uint16_t v, bool dec, bool word);
    uint16_t shiftRotate(uint8_t kind, uint16_t v, uint8_t count, bool word);
    bool condition(uint8_t c) const;
    void group3(bool word);
    void stringOp(uint8_t op);
    void invalid(uint8_t op);
    void divideError();
    void handleTrap(uint16_t id);
    bool pollIrq();
    uint8_t portIn8(uint16_t p) { return portIn_ ? portIn_(portUser_, p) : 0xFF; }
    void portOut8(uint16_t p, uint8_t v) { if (portOut_) portOut_(portUser_, p, v); }
    void execute(uint8_t op);
};

} // namespace Pocket86
