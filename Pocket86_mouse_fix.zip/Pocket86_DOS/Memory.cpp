#include "Memory.h"
#include <new>
#include <string.h>

namespace Pocket86 {

FlatMemory::FlatMemory(uint32_t size) : data_(nullptr), size_(size) {
    data_ = new (std::nothrow) uint8_t[size_];
    if (data_) memset(data_, 0, size_); else size_ = 0;
}
FlatMemory::~FlatMemory() { delete[] data_; }
uint8_t FlatMemory::read8(uint32_t a) const { return size_ ? data_[a % size_] : 0xFF; }
void FlatMemory::write8(uint32_t a, uint8_t v) { if (size_) data_[a % size_] = v; }

} // namespace Pocket86
