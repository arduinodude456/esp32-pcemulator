#pragma once
#include "Disk.h"
#include "OnScreenKeyboard.h"
#include <stdint.h>

namespace Pocket86 {

// Minimal touch file browser for mounting disk images. It takes over the whole screen while open
// (the emulator is paused), then hands the screen back. Opened with the DISK button next to KBD
// or with the console command "files".
//
//   Up      parent folder              A: B: C:   choose the drive the next tapped image is mounted on
//   Eject   remove the image from the selected drive
//   Img/All show only disk-image files (.img .ima .dsk .flp .vfd .bin) or every file
//   Reset   cold-reboot the PC (boot from the freshly mounted A:) and close the browser
//   X       close;  < >  previous / next page
// Tap a folder to enter it, tap an image to mount it. Drives that currently hold an image show their tag (A: B: C:) in green.
class FileBrowser {
public:
    typedef void (*Handler)();
    FileBrowser(TFTVideo& video, OnScreenKeyboard& keyboard, Drives& drives);
    void setResetHandler(Handler h) { reset_ = h; }
    void run();                                  // modal; returns when the user closes it

private:
    static const uint8_t kRows = 6;
    struct Entry { char name[40]; bool dir; uint32_t bytes; };

    TFTVideo& video_;
    OnScreenKeyboard& kbd_;
    Drives& drives_;
    Handler reset_;
    char path_[48];
    char msg_[80];
    bool msgOk_, showAll_;
    uint8_t target_;                             // 0 = A:, 1 = B:, 2 = C:
    int16_t page_;
    uint16_t count_;                             // entries in this folder that pass the filter
    uint8_t nRows_;
    Entry rows_[kRows];

    void list();
    void draw();
    bool handle(int16_t x, int16_t y);           // false = close
    bool fullPath(const char* name, char* out, size_t n) const;
    void goUp();
    void activate(uint8_t row);
    void mount(const char* full, const char* name);
    void eject();
    void setMsg(bool ok, const char* text);
    const char* tagFor(const char* full) const;
    DiskImage& targetDisk() { return target_ < 2 ? drives_.floppy[target_] : drives_.hard[0]; }
};

} // namespace Pocket86
