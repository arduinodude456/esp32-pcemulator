#include "FileBrowser.h"
#include <string.h>
#include <stdio.h>

#ifdef ARDUINO
#include <Arduino.h>
#include <SD.h>
#include <strings.h>

namespace Pocket86 {

namespace {
const int16_t kHeaderH = 28;
const int16_t kToolY = 30, kToolH = 28, kToolW = 68;     // 7 buttons: Up A: B: C: Eject Img/All Reset
const int16_t kListY = 62, kRowH = 30;
const int16_t kFootY = 248;

bool isImageName(const char* n) {
    static const char* const ext[] = { ".img", ".ima", ".dsk", ".flp", ".vfd", ".bin" };
    size_t len = strlen(n);
    for (unsigned i = 0; i < sizeof(ext) / sizeof(ext[0]); i++) {
        size_t el = strlen(ext[i]);
        if (len > el && strcasecmp(n + len - el, ext[i]) == 0) return true;
    }
    return false;
}

const char* baseName(const char* p) {
    const char* s = strrchr(p, '/');
    return s ? s + 1 : p;
}

bool hidden(const char* n) {
    return n[0] == '.' || strcasecmp(n, "System Volume Information") == 0 || strcasecmp(n, "ram.swap") == 0;
}
}

FileBrowser::FileBrowser(TFTVideo& video, OnScreenKeyboard& keyboard, Drives& drives)
    : video_(video), kbd_(keyboard), drives_(drives), reset_(nullptr), path_{}, msg_{}, msgOk_(true), showAll_(false),
      target_(0), page_(0), count_(0), nRows_(0), rows_{} {
    strcpy(path_, "/");
}

void FileBrowser::setMsg(bool ok, const char* text) {
    msgOk_ = ok;
    strncpy(msg_, text, sizeof(msg_) - 1);
    msg_[sizeof(msg_) - 1] = 0;
}

bool FileBrowser::fullPath(const char* name, char* out, size_t n) const {
    int w = snprintf(out, n, "%s%s%s", path_, path_[1] ? "/" : "", name);
    return w > 0 && (size_t)w < n;
}

const char* FileBrowser::tagFor(const char* full) const {
    if (drives_.floppy[0].present() && strcasecmp(drives_.floppy[0].path(), full) == 0) return "A:";
    if (drives_.floppy[1].present() && strcasecmp(drives_.floppy[1].path(), full) == 0) return "B:";
    if (drives_.hard[0].present() && strcasecmp(drives_.hard[0].path(), full) == 0) return "C:";
    return nullptr;
}

// One pass over the folder per redraw: folders first, then files; keeps only the entries of the current page.
void FileBrowser::list() {
    count_ = 0; nRows_ = 0;
    File dir = SD.open(path_);
    if (!dir || !dir.isDirectory()) { setMsg(false, "cannot read this folder"); if (dir) dir.close(); return; }
    const uint16_t first = (uint16_t)(page_ * kRows);
    for (int pass = 0; pass < 2; pass++) {
        dir.rewindDirectory();
        for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
            const char* name = baseName(f.name());
            bool isDir = f.isDirectory();
            if (hidden(name) || isDir != (pass == 0) || (!isDir && !showAll_ && !isImageName(name))) { f.close(); continue; }
            if (count_ >= first && nRows_ < kRows) {
                Entry& e = rows_[nRows_++];
                strncpy(e.name, name, sizeof(e.name) - 1); e.name[sizeof(e.name) - 1] = 0;
                e.dir = isDir;
                e.bytes = isDir ? 0 : (uint32_t)f.size();
            }
            count_++;
            f.close();
        }
    }
    dir.close();
    if (nRows_ == 0 && page_ > 0) { page_ = 0; list(); }
}

void FileBrowser::draw() {
    TFT_eSPI& t = video_.tft();
    const uint16_t cBar = t.color565(20, 40, 90), cBtn = t.color565(48, 52, 60), cSel = t.color565(30, 90, 200);
    const uint16_t cRow0 = t.color565(18, 18, 22), cRow1 = t.color565(32, 34, 40);
    const uint16_t cGreen = t.color565(90, 230, 110), cYellow = t.color565(255, 220, 90), cRed = t.color565(200, 50, 50), cWarn = t.color565(255, 140, 90);
    char buf[96];

    // header: current folder + close
    t.fillRect(0, 0, 480, kHeaderH, cBar);
    t.setTextSize(1); t.setTextColor(TFT_WHITE, cBar); t.setTextDatum(ML_DATUM);
    size_t pl = strlen(path_);
    snprintf(buf, sizeof(buf), "SD:%s%s", pl > 56 ? "..." : "", pl > 56 ? path_ + pl - 53 : path_);
    t.drawString(buf, 6, kHeaderH / 2, 1);
    t.fillRect(440, 2, 38, kHeaderH - 4, cRed);
    t.setTextDatum(MC_DATUM); t.setTextSize(2); t.setTextColor(TFT_WHITE, cRed);
    t.drawString("X", 459, kHeaderH / 2, 1);

    // toolbar
    static const char* const lab[7] = { "Up", "A:", "B:", "C:", "Eject", nullptr, "Reset" };
    for (int i = 0; i < 7; i++) {
        bool sel = (i >= 1 && i <= 3 && target_ == i - 1);
        uint16_t bg = sel ? cSel : cBtn;
        int16_t x = i * kToolW, w = (i == 6) ? 480 - x : kToolW;
        t.fillRoundRect(x + 1, kToolY, w - 2, kToolH, 4, bg);
        t.setTextSize(1); t.setTextColor(TFT_WHITE, bg); t.setTextDatum(MC_DATUM);
        t.drawString(i == 5 ? (showAll_ ? "All" : "Img") : lab[i], x + w / 2, kToolY + kToolH / 2, 1);
    }

    // list
    for (uint8_t r = 0; r < kRows; r++) {
        int16_t y = kListY + r * kRowH;
        uint16_t bg = (r & 1) ? cRow1 : cRow0;
        t.fillRect(0, y, 480, kRowH, bg);
        if (r >= nRows_) {
            if (r == 0 && count_ == 0) { t.setTextSize(2); t.setTextColor(TFT_DARKGREY, bg); t.setTextDatum(TL_DATUM); t.drawString("(empty)", 8, y + 7, 1); }
            continue;
        }
        const Entry& e = rows_[r];
        char nm[32];
        snprintf(nm, sizeof(nm), "%.28s%s", e.name, e.dir ? "/" : "");
        t.setTextSize(2); t.setTextColor(e.dir ? cYellow : TFT_WHITE, bg); t.setTextDatum(TL_DATUM);
        t.drawString(nm, 8, y + 7, 1);
        char full[48];
        if (!e.dir && fullPath(e.name, full, sizeof(full))) {
            const char* tag = tagFor(full);
            if (tag) { t.setTextColor(cGreen, bg); t.drawString(tag, 392, y + 7, 1); }
        }
        t.setTextSize(1); t.setTextColor(TFT_LIGHTGREY, bg); t.setTextDatum(MR_DATUM);
        if (e.dir) snprintf(buf, sizeof(buf), "<DIR>");
        else if (e.bytes >= 1048576UL) snprintf(buf, sizeof(buf), "%u.%uM", (unsigned)(e.bytes >> 20), (unsigned)(((e.bytes & 0xFFFFFu) * 10u) >> 20));
        else snprintf(buf, sizeof(buf), "%uK", (unsigned)((e.bytes + 1023u) >> 10));
        t.drawString(buf, 474, y + kRowH / 2, 1);
    }

    // footer: paging, message, mounted images
    t.fillRect(0, kFootY, 480, 320 - kFootY, TFT_BLACK);
    int pages = (count_ + kRows - 1) / kRows; if (pages < 1) pages = 1;
    t.fillRoundRect(1, kFootY + 2, 118, 26, 4, cBtn);
    t.fillRoundRect(361, kFootY + 2, 118, 26, 4, cBtn);
    t.setTextSize(2); t.setTextColor(TFT_WHITE, cBtn); t.setTextDatum(MC_DATUM);
    t.drawString("<", 60, kFootY + 15, 1);
    t.drawString(">", 420, kFootY + 15, 1);
    t.setTextSize(1); t.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    snprintf(buf, sizeof(buf), "Page %d/%d  (%u)", (int)page_ + 1, pages, (unsigned)count_);
    t.drawString(buf, 240, kFootY + 15, 1);
    t.setTextDatum(TL_DATUM);
    t.setTextColor(msg_[0] ? (msgOk_ ? cGreen : cWarn) : TFT_DARKGREY, TFT_BLACK);
    t.drawString(msg_[0] ? msg_ : "Tap an image to mount it on the selected drive", 4, kFootY + 36, 1);
    t.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    snprintf(buf, sizeof(buf), "A:%s  B:%s  C:%s",
             drives_.floppy[0].present() ? baseName(drives_.floppy[0].path()) : "-",
             drives_.floppy[1].present() ? baseName(drives_.floppy[1].path()) : "-",
             drives_.hard[0].present() ? baseName(drives_.hard[0].path()) : "-");
    t.drawString(buf, 4, kFootY + 52, 1);
    t.setTextDatum(TL_DATUM);
}

void FileBrowser::goUp() {
    char* s = strrchr(path_, '/');
    if (!s || s == path_) { strcpy(path_, "/"); return; }
    *s = 0;
}

void FileBrowser::mount(const char* full, const char* name) {
    DiskImage& d = targetDisk();
    const bool floppy = target_ < 2;
    char old[48] = {};
    const bool had = d.present();
    if (had) { strncpy(old, d.path(), sizeof(old) - 1); }       // copy first: open() overwrites the stored path
    char m[80];
    if (d.open(full, floppy)) {
        snprintf(m, sizeof(m), "Mounted %c: %.60s", 'A' + target_, name);
        setMsg(true, m);
    } else {
        if (had) d.open(old, floppy);                            // keep the previous image
        snprintf(m, sizeof(m), floppy ? "Not a floppy image (size must be 160K..2.88M)" : "Could not open hard disk image");
        setMsg(false, m);
    }
}

void FileBrowser::eject() {
    DiskImage& d = targetDisk();
    char m[40];
    if (!d.present()) { snprintf(m, sizeof(m), "%c: is already empty", 'A' + target_); setMsg(false, m); return; }
    d.close();
    snprintf(m, sizeof(m), "%c: ejected", 'A' + target_);
    setMsg(true, m);
}

void FileBrowser::activate(uint8_t row) {
    if (row >= nRows_) return;
    const Entry& e = rows_[row];
    char full[48];
    if (!fullPath(e.name, full, sizeof(full))) { setMsg(false, "path too long (max 47 characters)"); return; }
    if (e.dir) { strcpy(path_, full); page_ = 0; msg_[0] = 0; return; }
    mount(full, e.name);
}

bool FileBrowser::handle(int16_t x, int16_t y) {
    if (y < kHeaderH) return x < 440;
    if (y >= kToolY && y < kToolY + kToolH) {
        int b = x / kToolW; if (b > 6) b = 6;
        switch (b) {
            case 0: goUp(); page_ = 0; msg_[0] = 0; break;
            case 1: case 2: case 3: target_ = (uint8_t)(b - 1); msg_[0] = 0; break;
            case 4: eject(); break;
            case 5: showAll_ = !showAll_; page_ = 0; msg_[0] = 0; break;
            case 6: if (reset_) { reset_(); return false; } break;
        }
    } else if (y >= kListY && y < kListY + kRows * kRowH) {
        activate((uint8_t)((y - kListY) / kRowH));
    } else if (y >= kFootY && y < kFootY + 30) {
        int pages = (count_ + kRows - 1) / kRows;
        if (x < 120 && page_ > 0) page_--;
        else if (x >= 360 && page_ + 1 < pages) page_++;
    }
    return true;
}

void FileBrowser::run() {
    video_.tft().fillScreen(TFT_BLACK);
    msg_[0] = 0;
    page_ = 0;
    if (!SD.open(path_)) strcpy(path_, "/");
    list();
    draw();
    int16_t x = 0, y = 0;
    while (kbd_.pointer(x, y)) delay(20);                      // the tap that opened us
    bool down = false;
    for (;;) {
        delay(15);
        if (!kbd_.pointer(x, y)) { down = false; continue; }
        if (down) continue;
        down = true;
        if (!handle(x, y)) break;
        list();
        draw();
    }
    while (kbd_.pointer(x, y)) delay(20);
}

} // namespace Pocket86

#else   // host build: no screen

namespace Pocket86 {
FileBrowser::FileBrowser(TFTVideo& v, OnScreenKeyboard& k, Drives& d)
    : video_(v), kbd_(k), drives_(d), reset_(nullptr), path_{}, msg_{}, msgOk_(true), showAll_(false), target_(0), page_(0), count_(0), nRows_(0), rows_{} {}
void FileBrowser::run() {}
}
#endif
