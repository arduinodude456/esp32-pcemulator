#pragma once

// Shared by the Arduino sketch and the separately compiled .cpp translation units.
// Set to 0 to silence focused touch, PS/2 command, BIOS callback, and IRQ packet logs.
#ifndef POCKET86_MOUSE_DEBUG
#define POCKET86_MOUSE_DEBUG 1
#endif

// PS/2 counts sent per DOS pixel of touch movement (NUM/DEN). 1/2 = half (measured: 1/1 moved the pointer 2x too far).
// If the pointer is still too fast/slow, change these (e.g. 2/5 or 3/5).
#ifndef POCKET86_PS2_SCALE_NUM
#define POCKET86_PS2_SCALE_NUM 1
#endif
#ifndef POCKET86_PS2_SCALE_DEN
#define POCKET86_PS2_SCALE_DEN 2
#endif

// Max counts per PS/2 packet (127 = PS/2 maximum).
#ifndef POCKET86_PS2_MAX_STEP
#define POCKET86_PS2_MAX_STEP 127
#endif

// Touch behaviour: 1 = touch moves the pointer, a short tap clicks, a long press holds the button (drag).
// 0 = every touch is a held left button (old behaviour).
#ifndef POCKET86_TAP_MODE
#define POCKET86_TAP_MODE 1
#endif
#ifndef POCKET86_TAP_SLOP_PX
#define POCKET86_TAP_SLOP_PX 10     // finger may wander this many screen pixels and still count as a tap
#endif
#ifndef POCKET86_LONGPRESS_MS
#define POCKET86_LONGPRESS_MS 450   // hold still this long to start a drag
#endif
