# Pocket86: Windows 3.0 Real-Mode-Maus – Recherche und Fix

## Kurzbefund

Die Windows-Maus ist nicht gleichbedeutend mit dem DOS-Mausinterface. Windows 3.0 lädt einen Windows-Maustreiber (`MOUSE.DRV`) und muss bei einer PS/2-Konfiguration einen passenden PS/2-Weg haben. Die Windows-3.x-Enhanced-Mode-Implementierung ist ausdrücklich dokumentiert, sich über `INT 15h, AH=C2h` beim BIOS für Mausdaten anzumelden; das BIOS empfängt die PS/2-Daten über IRQ 12 und die 8042-Ports 60h/64h und ruft den Treiber-Callback auf. Die FabGL-PCEmulator-Referenz enthält genau diesen BIOS-/EBDA-/IRQ74-Pfad. `INT 33h` ist daneben vor allem die DOS-Maus-API und ersetzt den vom Windows-PS/2-Treiber verwendeten BIOSpfad nicht automatisch.

Im gelieferten Pocket86-Code waren PS/2-Pakete, C2-Dienste und Callback bereits teilweise vorhanden, aber es gab konkrete Kompatibilitätsfehler im BIOS-Callbackpfad, unvollständige C2-Status-/Parameterdienste und einen nicht wirksamen Debug-Schalter. Der wichtigste IRQ-Fehler: Anders als FabGL sicherte Pocket86 im IRQ12-Handler AX/BX/CX/DS nicht über den BIOS-Callback. Windows-Treibercode darf diese Register ändern; nach dem Callback konnte Pocket86 deshalb in beschädigtem Gastzustand weiterlaufen. Der fehlende Touchdebug war separat erklärt: `POCKET86_MOUSE_DEBUG` stand nur im `.ino`-Sketch. Arduino übersetzt `.ino` und `.cpp` als getrennte Übersetzungseinheiten; die `#if`-Blöcke in `BIOS.cpp` sahen den dortigen Schalter daher nicht.

Das sind anhand des Quellcodes reproduzierbare Fehler. Sie belegen nicht allein, dass Windows auf dem realen Pocket86-Gerät nach dem Flash garantiert funktioniert: Dafür ist ein Test mit dem konkreten ESP32-Board, dessen TFT_eSPI-/Touch-Setup und der Windows-Installation erforderlich; dieser Test war hier nicht verfügbar.

## Was Windows 3.0 im Real Mode braucht

Windows 3.0 kann mit einem 8086/8088 im Real Mode starten. In diesem Modus ist der ausgewählte Windows-Treiber und dessen Hardwarepfad entscheidend. Für eine PS/2-Maus muss der Treiber die BIOS-Pointing-Device-Schnittstelle erreichen können: C2h-Unterfunktionen erkennen/initialisieren das Gerät, richten den ES:BX-Callback ein und aktivieren das Gerät. Bei Tastatur-/Mauscontroller- oder PIC-Fehlern kann die Maus auf DOS-Ebene scheinbar verfügbar sein, während die Windows-GUI keine Bewegungen erhält.

Der BIOS-Callback ist kein optionaler Bonus: Die PS/2-Maus liefert relative X-/Y-Counts in einem Standardpaket von drei Bytes. Das BIOS muss Byte für Byte pro IRQ12 lesen, vollständig zusammenbauen und danach die Werte in einem Callback-Stacklayout übergeben. Ein separates `INT 33h` kann weiterhin für DOS-Programme bestehen, aber Windows kann es in diesem Setup ignorieren. In Windows Setup/System Setup muss außerdem ein PS/2-kompatibler Windows-Maustreiber ausgewählt sein; „No mouse“ oder ein serieller/bus-mouse-Treiber passt nicht zu dieser Emulation.

## Referenzverhalten: FabGL und Standards

### FabGL PCEmulator

Die geprüften Stellen sind `examples/VGA/PCEmulator/bios.cpp`, `bios.asm`, `machine.cpp` und `src/emudevs/i8042.cpp` im Referenzrepository.

- `bios.asm` reserviert die EBDA-Felder: Callback-Offset `+22h`, Callback-Segment `+24h`, Paketindex `+26h`, Paketgröße/Handlerflag `+27h`, Paketbytes `+28h`.
- FabGLs IRQ74h-Handler (Assembly um `int74:`) speichert AX/BX/CX/DS, liest genau ein Byte über Port 60h, sammelt bis zur konfigurierten Paketgröße, legt vier zero-extended Wörter auf dem Stack ab und führt `CALL FAR [EBDA_DRIVER_OFFSET]` aus. Nach dem Callback entfernt er die vier Wörter, setzt den Paketindex zurück, beendet den Slave-PIC-IRQ und stellt die Register wieder her.
- `BIOS::pointingDeviceInterface()` setzt für unterstützte Maus C2h AH=0/CF=0. C201 deaktiviert die Maus und setzt Sampling 100 Hz, Auflösungscode 2 (4 counts/mm), 1:1-Skalierung; in FabGL wird BH mit der Geräte-ID beschrieben und BL bleibt unverändert. C205 verwendet die reale Paketgröße der Maus, deaktiviert die Maus und löscht Callback-/EBDA-Zustand. C207 schreibt ES:BX in die EBDA und setzt Bit 7 in Flags2.
- FabGL-C2h ist nicht vollständig: C206 implementiert dort nur Set Scaling (BH=1/2); andere Funktionen liefern AH=86h/CF=1. Pocket86 kann und sollte die dokumentierten Status- und Parameterfunktionen ergänzen, statt FabGLs unimplementierte Fälle zu kopieren.
- Der 8042 startet bei FabGL mit Status 14h und Command Byte 67h. Das AUX-IRQ ist Command-Byte-Bit 1; das Abschalten der AUX-Schnittstelle ist Bit 5. Diese sind nicht dasselbe.

### IBM BIOS Interface und RBIL

IBM *PS/2 and PC BIOS Interface Technical Reference* (April 1987), Kapitel INT 15h, dokumentiert C2h: C200 enable/disable; C201 reset; C202 Samplingrate; C203 Auflösung; C204 Gerätetyp; C205 Paketgröße; C206 Status/Skalierung; C207 Callback. C207 übergibt Status, X, Y und ein reserviertes Nullwort als vier Wörter; der Benutzerhandler kehrt mit FAR RET zurück, ohne Argumente selbst zu entfernen.

RBIL Release 61 konkretisiert C206: BL Status (Bit 0 rechts, Bit 2 links, Bit 4 scaling 2:1, Bit 5 enabled), CL Auflösungscode, DL Samplingrate in Reports/Sekunde. Die C202-Raten sind Indizes 0–6 für 10,20,40,60,80,100,200 Hz; C203 akzeptiert 0–3. Die Implementierung liefert diese Statuswerte und weist ungültige Parameter mit AH=2/CF=1 zurück.

Bei C201 weicht FabGL von einer strengen Lesart der PS/2-Dokumentation/RBIL ab: Standarddokumente nennen zusätzlich ein BL-Resetresultat AA, FabGLs tatsächlicher Handler schreibt nur BH=device ID. Weil das gewünschte Vergleichssystem FabGL ist und Windows den Geräte-ID-Rückgabewert benötigt, folgt Pocket86 hier dem konkreten Referenzverhalten; BL bleibt erhalten. Der Test stellt diese Abweichung ausdrücklich sicher.

## Konkrete Pocket86-Änderungen

1. **IRQ12-Callbackregister erhalten:** Die Maus-ISR speichert AX/BX/CX/DS wie FabGL vor dem Port-60h-Read. Bei unvollständigem Paket oder fehlendem Callback stellt sie diese direkt wieder her. Beim vollständigen Callback liegt der gerettete Zustand unter den vier Argumentwörtern; der BIOS-Returnstub entfernt zuerst die Callbackargumente, restauriert DS/CX/BX/AX und führt IRET aus. Das ist nötig, weil der Windows-Callback gewöhnliche Treiberlogik ist und Register clobbern darf.
2. **INT 15h/C2h korrigiert/ergänzt:** C201 implementiert FabGLs Resetzustand und BH-Geräte-ID; C202/C203 speichern und validieren Rate/Auflösung; C206 meldet Statusbits, Auflösung, Rate und Skalierung korrekt; C207 setzt/entfernt Callback- und EBDA-Handlerflag sauber; C205 setzt den PS/2-Standardpaketpfad zurück.
3. **PS/2-Parameter unterstützen:** Die Gerätekommandos F3 (Samplingrate) und E8 (Auflösung) erwarten jetzt ein gültiges Folgedatenbyte, antworten mit ACK oder Resend und spiegeln Zustand in C206. F6/FF setzen dokumentierte Mausdefaults, E6/E7 schalten Skalierung.
4. **Debugging sichtbar machen:** `Pocket86MouseConfig.h` wird sowohl vom Sketch als auch von BIOS-/Touch-`.cpp` inkludiert. Debug ist momentan aktiv (per `POCKET86_MOUSE_DEBUG 0` abschaltbar). Die Touchkomponente meldet beim Start Quelle und Bereitschaft (`custom`, `TFT_eSPI` oder `none`) sowie Down/Up-Koordinaten. BIOS meldet C2-Calls, PS/2-Befehle und komplette Pakete. `biosLog` wird im Sketch gesetzt, bevor `coldReset()`/POST und der Gaststart laufen; ein Hosttest verifiziert, dass `BIOS::say()` den Callback tatsächlich erreicht.
5. **Touch/KBD/DISK:** Die vorhandene `keyboard.poll()`-Route bleibt bestehen; jeder Touch wird weiterhin zu `BIOS::mouseTouch()` geleitet. Der Touch-Released-Zustand benutzt weiter die letzte gültige Koordinate und verhindert damit einen Sprung zum Ursprung. KBD/DISK-Trefferflächen und Tastaturlogik wurden nicht neu verdrahtet.

## Testabdeckung und offene Verifikation

Durchgeführt:

- Hostbuild mit `g++ -std=c++17 -Wall -Wextra -Werror -O2` über BIOS, CPU8086, PC, Memory, CGA, Disk, TFTVideo, Bildschirmtastatur und Dateibrowser: erfolgreich.
- Hosttest: POST, EBDA und C1h/C0h; C201 direct und durch echte 8086-`INT 15h`-Sequenz inkl. Carryflag; C202/C203/C206 Werte/Skalierung/Buttons; 8042 Status-/Command-Byte; F3/E8-PS/2-Parameterhandshake; C205/C207; Touchmapping, aufgeteilte Bewegungsdaten, linker Tastendruck/-freigabe, Callbackstack und Paketbytes; vollständiger IRQ12-Dreibytepfad über CPU/PIC mit IF-Gating und ohne hängenden IRQ; Callback, der AX/BX/CX/DS absichtlich verändert, um die Registerrettung zu testen; INT33-Regressionspfad.
- Derselbe Hosttest mit AddressSanitizer und UndefinedBehaviorSanitizer: erfolgreich.

Nicht durchgeführt / Einschränkungen:

- Im Sandboxsystem sind weder `arduino-cli`, PlatformIO (`pio`) noch `idf.py` verfügbar; es liegt auch keine Arduino-ESP32-/TFT_eSPI-Boardkonfiguration bei. Der ESP32-/Arduino-Sketch konnte daher nicht mit der vorgesehenen Toolchain kompiliert werden.
- Kein angeschlossener Pocket86-ESP32, Touchscreen oder serieller Hardwaremonitor vorhanden. Keine End-to-End-Ausführung von Windows 3.0 auf echter Hardware. Der bestandene Hosttest belegt BIOS-/CPU-/PIC-Logik, nicht TFT-Kalibrierung oder realen Windows-Mauszeiger.
- Beim nächsten Flash sollte der Serial Monitor bei 115200 Baud mindestens `[TOUCH] source=TFT_eSPI ready=1` oder `source=custom ready=1` zeigen. Bei Touch müssen Down/Up-Meldungen erscheinen. Wenn die Touchmeldungen erscheinen, aber keine `[MOUSE] INT15`-Meldungen, erreicht der gewählte Windows-Treiber den C2h-Pfad nicht (Setup-Maustyp prüfen). Wenn C2h-Aufrufe erscheinen, aber keine Paketzeilen, als Nächstes C200/C205/C207- und IRQ12-Sequenz im Log untersuchen. In der Windows-Konfiguration „Microsoft, or IBM PS/2 mouse“ bzw. den entsprechenden PS/2-Treiber wählen, nicht einen seriellen Treiber.

## Quellen

- FabGL PCEmulator BIOS, C2h: <https://github.com/fdivitto/FabGL/blob/master/examples/VGA/PCEmulator/bios.cpp>
- FabGL PCEmulator BIOS Assembly, EBDA und IRQ74h: <https://github.com/fdivitto/FabGL/blob/master/examples/VGA/PCEmulator/bios.asm>
- FabGL 8042-Controller: <https://github.com/fdivitto/FabGL/blob/master/src/emudevs/i8042.cpp>
- IBM, *PS/2 and PC BIOS Interface Technical Reference*, April 1987, INT 15h C0/C1/C2 (lokal während der Recherche extrahierte PDF-Kopie im Bitsavers-Archiv).
- RBIL INT 15h/C2: <https://fd.lod.bz/rbil/interrup/io_mouse/15c200.html> und Unterfunktionen C201–C207.
- OS/2 Museum, *Jumpy PS/2 mouse in Enhanced mode Windows 3.x* (Treiber → C2-Callback → IRQ12/60h/64h): <https://www.os2museum.com/wp/jumpy-ps2-mouse-in-enhanced-mode-windows-3-x/>
- DOSBox-X, *Installing Windows 3.0* (Real-Mode/Setup- und Mausdriver-Kontext): <https://github.com/joncampbell123/dosbox-x/wiki/Guide:Installing-Windows-3.0>
- DOSBox-X, *Mouse support* (Gast-OS lädt eigenen Windows-/DOS-Treiber; INT33 und BIOS PS/2 sind getrennte Pfade): <https://dosbox-x.com/wiki/Guide%3AMouse-support-in-DOSBox%E2%80%90X>
- Microsoft KnowledgeBase-Archiv Q88543, Windows-Mausdriver-Setup/PS/2-Auswahl (gilt für 3.1/3.11; als ergänzende Diagnosequelle, nicht als Windows-3.0-Primärbeleg): <http://jeffpar.github.io/kbarchive/kb/088/Q88543/>
- Community-Fall Windows 3.0 Real Mode + PS/2/INT33 workaround: <https://github.com/FreddyVRetro/ISA-PicoMEM/issues/47>
