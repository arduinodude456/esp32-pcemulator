#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef ARDUINO
#include <Arduino.h>
#include <SD.h>
#else
#include <stdio.h>
#endif

namespace Pocket86 {

// One raw sector image (512-byte sectors) on the SD card (or a host file in tests).
// Floppy geometry is derived from the image size; hard disks use 16 heads x 63 sectors.
class DiskImage {
public:
    DiskImage();
    ~DiskImage();

    bool open(const char* path, bool floppy);
    void close();

    bool present() const { return present_; }
    bool isFloppy() const { return floppy_; }
    bool writable() const { return writable_; }
    const char* path() const { return path_; }

    uint32_t totalSectors() const { return sectors_; }
    uint16_t cylinders() const { return cyl_; }
    uint8_t heads() const { return heads_; }
    uint8_t sectorsPerTrack() const { return spt_; }
    uint8_t floppyType() const { return type_; }       // INT 13h/08h drive type (1=360K 2=1.2M 3=720K 4=1.44M 6=2.88M)

    bool read(uint32_t lba, uint8_t* buffer);
    bool write(uint32_t lba, const uint8_t* buffer);

    bool takeChanged() { bool c = changed_; changed_ = false; return c; }

private:
    bool present_, floppy_, writable_, changed_;
    uint32_t sectors_;
    uint16_t cyl_;
    uint8_t heads_, spt_, type_;
    char path_[48];
#ifdef ARDUINO
    File file_;
#else
    FILE* file_;
#endif
};

// The machine's drives: two floppies (A:, B:) and two hard disks (80h, 81h).
struct Drives {
    DiskImage floppy[2];
    DiskImage hard[2];

    DiskImage* byBiosNumber(uint8_t dl) {
        if (dl == 0x00) return &floppy[0];
        if (dl == 0x01) return &floppy[1];
        if (dl == 0x80) return &hard[0];
        if (dl == 0x81) return &hard[1];
        return nullptr;
    }
    uint8_t floppyCount() const { return (floppy[0].present() ? 1 : 0) + (floppy[1].present() ? 1 : 0); }
    uint8_t hardCount() const { return (hard[0].present() ? 1 : 0) + (hard[1].present() ? 1 : 0); }
};

} // namespace Pocket86
