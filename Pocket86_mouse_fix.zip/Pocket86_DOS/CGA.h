#pragma once
#include "PC.h"
#include <stdint.h>

namespace Pocket86 {

// Colour text adapter (IBM CGA, 80x25 text, 16 KiB video RAM at B8000h).
// Only the parts of the 6845 CRTC that DOS software really uses are modelled:
// cursor shape/position (regs 0A-0F) and display start address (regs 0C/0D).
class CGA {
public:
    explicit CGA(PCMemory& memory);

    uint8_t ioRead(uint16_t port);
    void ioWrite(uint16_t port, uint8_t value);
    bool handlesPort(uint16_t port) const { return port >= 0x3D0 && port <= 0x3DF; }

    // Cursor / start address as seen by the CRTC registers (offsets in character cells).
    uint16_t cursorCell() const { return (uint16_t)(((uint16_t)regs_[0x0E] << 8) | regs_[0x0F]); }
    void setCursorCell(uint16_t cell) { regs_[0x0E] = (uint8_t)(cell >> 8); regs_[0x0F] = (uint8_t)cell; }
    uint16_t startCell() const { return (uint16_t)(((uint16_t)regs_[0x0C] << 8) | regs_[0x0D]); }
    void setStartCell(uint16_t cell) { regs_[0x0C] = (uint8_t)(cell >> 8); regs_[0x0D] = (uint8_t)cell; }
    bool cursorVisible() const { return (regs_[0x0A] & 0x20) == 0 && (regs_[0x0A] & 0x1F) <= (regs_[0x0B] & 0x1F); }
    uint8_t cursorStartLine() const { return regs_[0x0A] & 0x1F; }
    uint8_t cursorEndLine() const { return regs_[0x0B] & 0x1F; }
    void setCursorShape(uint8_t startLine, uint8_t endLine) { regs_[0x0A] = startLine; regs_[0x0B] = endLine; }

    // Raw access for the renderer: 2048 cells (char, attribute) starting at B8000h (page 0 only).
    const uint8_t* cells() const { return mem_.video(); }

    void clear(uint8_t attr = 0x07);
    uint8_t modeControl() const { return modeReg_; }     // port 3D8h
    uint8_t colorControl() const { return colorReg_; }   // port 3D9h

    // Graphics modes (BIOS modes 4/5 = 320x200x4, mode 6 = 640x200x2). The mode is taken from port 3D8h,
    // so programs that program the adapter directly work as well as INT 10h callers.
    bool graphics() const { return (modeReg_ & 0x02) != 0; }
    bool hires() const { return (modeReg_ & 0x12) == 0x12; }      // 640x200 monochrome
    void setMode(uint8_t modeReg, uint8_t colorReg) { modeReg_ = modeReg; colorReg_ = colorReg; }
    void clearGraphics();                                          // zero the whole frame buffer
    void putPixel(uint16_t x, uint16_t y, uint8_t value, bool xorMode);
    uint8_t getPixel(uint16_t x, uint16_t y) const;
    // CGA colour index (0..15) for each pixel value of the current graphics mode / palette.
    void palette(uint8_t out[4]) const;

private:
    PCMemory& mem_;
    uint8_t regs_[0x20];
    uint8_t index_;
    uint8_t modeReg_;
    uint8_t colorReg_;
    uint8_t statusToggle_;
};

} // namespace Pocket86
