#include "BIOS.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace Pocket86 {

namespace {
const uint16_t kBdaKbdBuf   = 0x1E;     // keyboard ring buffer 0040:001E..003D
const uint16_t kBdaKbdEnd   = 0x3E;
const uint32_t kPitHz       = 1193182UL;
const uint16_t kDisketteTable = 0xEFC7; // F000:EFC7
const uint16_t kEbdaBytes = 1024;
const uint8_t kEbdaDriverOffset = 0x22;
const uint8_t kEbdaDriverSegment = 0x24;
const uint8_t kEbdaFlags1 = 0x26;
const uint8_t kEbdaFlags2 = 0x27;
const uint8_t kEbdaPacket = 0x28;

inline uint8_t hi8(uint16_t v) { return (uint8_t)(v >> 8); }
inline uint8_t lo8(uint16_t v) { return (uint8_t)v; }
inline void setHi(uint16_t& v, uint8_t b) { v = (uint16_t)((v & 0x00FF) | ((uint16_t)b << 8)); }
inline void setLo(uint16_t& v, uint8_t b) { v = (uint16_t)((v & 0xFF00) | b); }
inline void setCF(CPU8086::Registers& r, bool c) { if (c) r.flags |= CPU8086::CF; else r.flags &= (uint16_t)~CPU8086::CF; }
inline void setZF(CPU8086::Registers& r, bool z) { if (z) r.flags |= CPU8086::ZF; else r.flags &= (uint16_t)~CPU8086::ZF; }

CPU8086::TrapResult trapThunk(void* u, CPU8086&, uint16_t id) { return static_cast<BIOS*>(u)->trap(id); }
uint8_t portInThunk(void* u, uint16_t p) { return static_cast<BIOS*>(u)->portRead(p); }
void portOutThunk(void* u, uint16_t p, uint8_t v) { static_cast<BIOS*>(u)->portWrite(p, v); }
int irqThunk(void* u) { return static_cast<BIOS*>(u)->irqAck(); }
}

BIOS::BIOS(CPU8086& cpu, PCMemory& memory, CGA& video, Drives& drives)
    : cpu_(cpu), mem_(memory), cga_(video), drives_(drives), log_(nullptr),
      booted_(false), bootFailed_(false), posted_(false), bootDrive_(0), ebdaSegment_(0),
      irr_(0), isr_(0), imr_(0), picBase_(8), picIcwStep_(0), picReadIsr_(0),
      sirr_(0), sisr_(0), simr_(0), spicBase_(0x70), spicIcwStep_(0), spicReadIsr_(0),
      reload0_(65536), count0_(65536), reload2_(65536), pitPending_(0), pitFrac_(0), pitTotal_(0),
      pitRw_{3, 3, 3}, pitWritePhase_{0, 0, 0}, pitReadPhase_{0, 0, 0}, pitWriteLatch_{0, 0, 0}, pitReadLatch_{0, 0, 0},
      pitLatched_{false, false, false}, port61_(0), port61Toggle_(0), scancode_(0), cmosIndex_(0),
      hwSc_{}, hwWord_{}, hwHead_(0), hwCnt_(0), curWord_(0), relScan_(0), pendMods_(0), relUs_(0), relActive_(false), held_(false),
      modShift_(false), modCtrl_(false), modAlt_(false), mouseX_(0), mouseY_(0), mouseMinX_(0), mouseMaxX_(639),
      mouseMinY_(0), mouseMaxY_(199), mouseLastX_(0), mouseLastY_(0), mouseButtons_(0), mouseLastButtons_(0),
      mouseVisible_(false), mouseEnabled_(false), mouseReporting_(false), mouseCallbackSeg_(0), mouseCallbackOff_(0), mousePacketBytes_(3), auxQ_{}, auxIrqQ_{}, auxAuxQ_{}, auxHead_(0), auxCnt_(0), mousePacket_{}, mousePacketIndex_(0),
      mouseSampleRateHz_(100), mouseResolution_(2), mousePendingParam_(0), mouseScale2to1_(false),
      kbcCommandByte_(0x67), kbcExpectCommandByte_(false), kbcWriteMouse_(false),
      m33Seg_(0), m33Off_(0), m33Mask_(0), m33Pending_(0), m33MickX_(0), m33MickY_(0), m33DeltaX_(0), m33DeltaY_(0),
      m33PressCnt_{}, m33RelCnt_{}, m33PressX_{}, m33PressY_{}, m33RelX_{}, m33RelY_{} {}

void BIOS::say(const char* fmt, ...) {
    if (!log_) return;
    char buf[120];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
    log_(buf);
}

// ------------------------------------------------------------------ installation / POST

void BIOS::install() {
    cpu_.setTrapHook(trapThunk, this);
    cpu_.setPortCallbacks(portInThunk, portOutThunk, this);
    cpu_.setIrqAck(irqThunk, this);

    // ROM top: reset vector -> F000:1101 (POST trap), date, model byte, diskette parameter table.
    static const uint8_t resetVec[5] = { 0xEA, 0x01, 0x11, 0x00, 0xF0 };
    mem_.loadROM(0xFFFF0, resetVec, sizeof(resetVec));
    static const char date[9] = { '1', '0', '/', '1', '9', '/', '2', '6', 0 };
    mem_.loadROM(0xFFFF5, reinterpret_cast<const uint8_t*>(date), 9);
    static const uint8_t model = 0xFC;                 // PS/2 (AT class) model byte: Windows only tries the PS/2 pointing BIOS on these
    mem_.loadROM(0xFFFFE, &model, 1);
    // Callback return path for INT 15h/C207h: discard the four packet words,
    // restore the registers saved by IRQ12, then return to the interrupted code.
    static const uint8_t mouseCallbackReturn[] = { 0x81, 0xC4, 0x08, 0x00, 0x1F, 0x59, 0x5B, 0x58, 0xCF };
    if (!mem_.loadROM(0xF1200, mouseCallbackReturn, sizeof(mouseCallbackReturn))) say("[BIOS] failed to load mouse callback return stub");
    // Return path for the INT 33h user handler: POP ES, POP DS, POPA, IRET.
    static const uint8_t m33Return[] = { 0x07, 0x1F, 0x61, 0xCF };
    mem_.loadROM(0xF1210, m33Return, sizeof(m33Return));
    // Mouse drivers/Windows treat "INT 33h vector points at an IRET" as "no mouse driver installed".
    // The trap stub area is filled with CF (IRET), so give the INT 33h entry a different first byte (execution is trapped anyway).
    static const uint8_t m33Entry[] = { 0x90, 0xCF };
    mem_.loadROM(0xF1000u + CPU8086::TrapBase - 0x1000u + 0x33, m33Entry, sizeof(m33Entry));
    // INT 15h AH=C0h system configuration table: 16 bytes follow; feature 1
    // advertises the allocated EBDA (bit 2) and the implemented second PIC (bit 6).
    static const uint8_t sysConfig[] = {
        0x10, 0x00, 0xFC, 0x04, 0x00, 0x44, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    mem_.loadROM(0xF1040u, sysConfig, sizeof(sysConfig));
    static const uint8_t table[11] = { 0xAF, 0x02, 0x25, 0x02, 0x12, 0x1B, 0xFF, 0x54, 0xF6, 0x0F, 0x08 };
    mem_.loadROM(0xF0000u + kDisketteTable, table, sizeof(table));
}

void BIOS::post() {
    // interrupt vector table: every vector points at its own trap stub
    for (uint16_t n = 0; n < 256; n++) {
        mem_.write16((uint32_t)n * 4u, (uint16_t)(CPU8086::TrapBase + n));
        mem_.write16((uint32_t)n * 4u + 2u, CPU8086::TrapSegment);
    }
    mem_.write16(0x1E * 4u, kDisketteTable);
    mem_.write16(0x1E * 4u + 2u, CPU8086::TrapSegment);

    // BIOS data area
    for (uint16_t i = 0; i < 0x100; i++) mem_.write8(0x400u + i, 0);
    uint8_t floppies = drives_.floppyCount();
    uint16_t equip = 0x0024;                              // 80x25 colour adapter + PS/2 pointing device
    if (floppies) equip |= (uint16_t)(0x0001 | ((floppies - 1) << 6));
    setBda16(0x10, equip);
    uint16_t conventionalKB = (uint16_t)mem_.ramKilobytes();
    if (conventionalKB > 1) {
        ebdaSegment_ = (uint16_t)((conventionalKB - 1u) << 6); // reserve the top 1 KiB as FabGL does at 9FC0h
        setBda16(0x13, (uint16_t)(conventionalKB - 1u));
        setBda16(0x0E, ebdaSegment_);
        uint32_t ebdaBase = (uint32_t)ebdaSegment_ << 4;
        for (uint16_t i = 0; i < kEbdaBytes; ++i) mem_.write8(ebdaBase + i, 0);
        mem_.write8(ebdaBase, 1);                          // EBDA size in KiB
    } else {
        ebdaSegment_ = 0;
        setBda16(0x13, conventionalKB);
        setBda16(0x0E, 0);
    }
    setBda16(0x1A, kBdaKbdBuf); setBda16(0x1C, kBdaKbdBuf);
    setBda16(0x80, kBdaKbdBuf); setBda16(0x82, kBdaKbdEnd);
    setBda8(0x49, 3); setBda16(0x4A, 80); setBda16(0x4C, 0x1000); setBda16(0x4E, 0);
    setBda16(0x60, 0x0607); setBda8(0x62, 0); setBda16(0x63, 0x3D4);
    setBda8(0x65, 0x29); setBda8(0x66, 0x30);
    setBda8(0x75, drives_.hardCount());
    setBda8(0x84, 24); setBda16(0x85, 8);
    setBda8(0x96, 0);                                     // no enhanced keyboard
    hwHead_ = hwCnt_ = 0; curWord_ = 0; relActive_ = false; pendMods_ = 0; held_ = false; modShift_ = modCtrl_ = modAlt_ = false;
    mouseX_ = mouseY_ = mouseLastX_ = mouseLastY_ = 0; mouseMinX_ = mouseMinY_ = 0; mouseMaxX_ = 639; mouseMaxY_ = 199;
    mouseButtons_ = mouseLastButtons_ = 0; mouseVisible_ = false; mouseEnabled_ = false; mouseReporting_ = false;
    mouseCallbackSeg_ = mouseCallbackOff_ = 0; mousePacketBytes_ = 3; mousePacketIndex_ = 0;
    auxHead_ = auxCnt_ = 0; memset(auxIrqQ_, 0, sizeof(auxIrqQ_)); memset(auxAuxQ_, 0, sizeof(auxAuxQ_)); kbcCommandByte_ = 0x67; kbcExpectCommandByte_ = false; kbcWriteMouse_ = false;
    m33Reset();

    // chipset
    irr_ = isr_ = 0; imr_ = 0x00; picBase_ = 8; picIcwStep_ = 0; picReadIsr_ = 0;
    sirr_ = sisr_ = 0; simr_ = 0x00; spicBase_ = 0x70; spicIcwStep_ = 0; spicReadIsr_ = 0;
    reload0_ = count0_ = 65536; pitPending_ = 0; pitFrac_ = 0;
    for (int i = 0; i < 3; i++) { pitRw_[i] = 3; pitWritePhase_[i] = 0; pitReadPhase_[i] = 0; pitLatched_[i] = false; }
    updateIrq();

    cga_.setMode(0x29, 0x30);
    cga_.clear();
    cga_.setCursorShape(6, 7);
    printString("Pocket86 BIOS - 8086 PC\r\n");
    char line[48];
    snprintf(line, sizeof(line), "%uK RAM  ", (unsigned)mem_.ramKilobytes());
    printString(line);
    snprintf(line, sizeof(line), "FD:%u HD:%u\r\n\r\n", (unsigned)drives_.floppyCount(), (unsigned)drives_.hardCount());
    printString(line);
    posted_ = true;
}

bool BIOS::bootstrap() {
    static const uint8_t order[2] = { 0x00, 0x80 };
    for (int i = 0; i < 2; i++) {
        DiskImage* d = drives_.byBiosNumber(order[i]);
        if (!d || !d->present()) continue;
        uint8_t buf[512];
        if (!d->read(0, buf)) continue;
        if (buf[510] != 0x55 || buf[511] != 0xAA) continue;
        for (int k = 0; k < 512; k++) mem_.write8(0x7C00u + k, buf[k]);
        CPU8086::Registers& r = cpu_.registers();
        memset(&r.w, 0, sizeof(r.w));
        r.dx = order[i];
        r.es = r.ds = r.ss = 0; r.sp = 0x7C00;
        r.cs = 0; r.ip = 0x7C00;
        r.flags = 0xF202;
        bootDrive_ = order[i];
        booted_ = true;
        bootFailed_ = false;
        say("[BIOS] booting from drive %02X", order[i]);
        return true;
    }
    return false;
}

// ------------------------------------------------------------------ time / PIC / PIT

uint32_t BIOS::ticks() const {
    return (uint32_t)mem_.read16(0x46C) | ((uint32_t)mem_.read16(0x46E) << 16);
}

void BIOS::updateIrq() {
    if ((sirr_ & (uint8_t)~simr_) != 0) irr_ |= 4;
    else if (!(sisr_ & 0xFF)) irr_ &= (uint8_t)~4;
    uint8_t pend = (uint8_t)(irr_ & ~imr_);
    bool deliver = false;
    for (int i = 0; i < 8; i++) {
        if (isr_ & (1u << i)) break;
        if (pend & (1u << i)) { deliver = true; break; }
    }
    cpu_.setIrqLine(deliver);
}

int BIOS::irqAck() {
    uint8_t pend = (uint8_t)(irr_ & ~imr_);
    for (int i = 0; i < 8; i++) {
        if (isr_ & (1u << i)) break;
        if (pend & (1u << i)) {
            isr_ |= (uint8_t)(1u << i);
            irr_ &= (uint8_t)~(1u << i);
            if (i == 2) {
                uint8_t spend = (uint8_t)(sirr_ & ~simr_);
                for (int j = 0; j < 8; j++) if (!(sisr_ & (1u << j)) && (spend & (1u << j))) {
                    sisr_ |= (uint8_t)(1u << j); sirr_ &= (uint8_t)~(1u << j);
                    updateIrq(); return spicBase_ + j;
                }
            }
            if (i == 0 && pitPending_) pitPending_--;
            if (i == 1 && hwCnt_) {                          // keyboard: hand the next scan code to port 60h
                scancode_ = hwSc_[hwHead_]; curWord_ = hwWord_[hwHead_];
                hwHead_ = (uint8_t)((hwHead_ + 1) & 15); hwCnt_--;
                if (hwCnt_) irr_ |= 2;
            }
            updateIrq();
            return picBase_ + i;
        }
    }
    updateIrq();
    return -1;
}

void BIOS::raiseTimer() {
    if (pitPending_ && !(isr_ & 1)) irr_ |= 1;
    updateIrq();
}

uint32_t BIOS::pitCurrent(uint8_t c) const {
    if (c == 0) return count0_;
    if (c == 2) { uint32_t r = reload2_ ? reload2_ : 65536; return r - (uint32_t)(pitTotal_ % r); }
    return (uint32_t)(0x10000 - (pitTotal_ & 0xFFFF));
}

void BIOS::advance(uint32_t us) {
    touchClockUs_ += us;
    if (relActive_ && !held_) {                          // auto-release of keys that are not physically held (serial input)
        if (us >= relUs_) releaseKey();
        else relUs_ -= us;
    }
    pitFrac_ += (uint64_t)us * kPitHz;
    uint32_t t = (uint32_t)(pitFrac_ / 1000000ULL);
    pitFrac_ %= 1000000ULL;
    pitTotal_ += t;
    if (t >= count0_) {
        t -= count0_;
        uint32_t wraps = 1 + t / reload0_;
        t %= reload0_;
        count0_ = reload0_ - t;
        pitPending_ += wraps;
        if (pitPending_ > 18) pitPending_ = 18;
    } else {
        count0_ -= t;
    }
    raiseTimer();
}

void BIOS::pitWriteData(uint8_t c, uint8_t v) {
    uint8_t rw = pitRw_[c];
    uint16_t value;
    bool complete = false;
    if (rw == 1) { value = v; complete = true; }
    else if (rw == 2) { value = (uint16_t)(v << 8); complete = true; }
    else {
        if (pitWritePhase_[c] == 0) { pitWriteLatch_[c] = v; pitWritePhase_[c] = 1; return; }
        value = (uint16_t)(pitWriteLatch_[c] | ((uint16_t)v << 8));
        pitWritePhase_[c] = 0;
        complete = true;
    }
    if (!complete) return;
    uint32_t reload = value ? value : 65536;
    if (c == 0) { reload0_ = reload; count0_ = reload; }
    else if (c == 2) reload2_ = reload;
}

uint8_t BIOS::pitReadData(uint8_t c) {
    uint16_t value = pitLatched_[c] ? pitReadLatch_[c] : (uint16_t)pitCurrent(c);
    uint8_t rw = pitRw_[c];
    uint8_t out;
    if (rw == 1) { out = (uint8_t)value; pitLatched_[c] = false; }
    else if (rw == 2) { out = (uint8_t)(value >> 8); pitLatched_[c] = false; }
    else {
        if (pitReadPhase_[c] == 0) { out = (uint8_t)value; pitReadPhase_[c] = 1; }
        else { out = (uint8_t)(value >> 8); pitReadPhase_[c] = 0; pitLatched_[c] = false; }
    }
    return out;
}

// ------------------------------------------------------------------ ports

uint8_t BIOS::portRead(uint16_t p) {
    if (cga_.handlesPort(p)) return cga_.ioRead(p);
    switch (p) {
        case 0x20: return picReadIsr_ ? isr_ : irr_;
        case 0x21: return imr_;
        case 0xA0: return spicReadIsr_ ? sisr_ : sirr_;
        case 0xA1: return simr_;
        case 0x40: return pitReadData(0);
        case 0x41: return 0;
        case 0x42: return pitReadData(2);
        case 0x60:
            // One output buffer, two sources: while the keyboard IRQ1 handler is running it must see the scan code
            // (not a queued mouse byte); inside the IRQ12 handler it must see the mouse byte.
            if (auxCnt_ && !((isr_ & 2) && !(sisr_ & 0x10))) {
                uint8_t idx = auxHead_;
                uint8_t v = auxQ_[idx];
                bool consumedIrqByte = auxIrqQ_[idx] != 0;
                auxIrqQ_[idx] = 0;
                auxAuxQ_[idx] = 0;
                auxHead_ = (uint8_t)((auxHead_ + 1) & 63); auxCnt_--;
                bool irqBytesRemain = false;
                for (uint8_t n = 0, q = auxHead_; n < auxCnt_; ++n, q = (uint8_t)((q + 1) & 63))
                    if (auxIrqQ_[q]) { irqBytesRemain = true; break; }
                if (!irqBytesRemain) sirr_ &= (uint8_t)~(1u << 4);
                else if (consumedIrqByte) sirr_ |= (uint8_t)(1u << 4);
                updateIrq(); return v;
            }
            return scancode_;
        case 0x61: port61Toggle_ ^= 0x30; return (uint8_t)((port61_ & 0x0F) | port61Toggle_);
        case 0x64: return (uint8_t)(0x14 | ((auxCnt_ || hwCnt_) ? 0x01 : 0) | ((auxCnt_ && auxAuxQ_[auxHead_]) ? 0x20 : 0));
        case 0x71: return 0x00;
        default: return 0xFF;
    }
}

void BIOS::portWrite(uint16_t p, uint8_t v) {
    if (cga_.handlesPort(p)) { cga_.ioWrite(p, v); return; }
    switch (p) {
        case 0x20:
            if (v & 0x10) { picIcwStep_ = 1; imr_ = 0; isr_ = 0; irr_ = 0; }          // ICW1
            else if (v & 0x08) { if ((v & 0x03) == 0x02) picReadIsr_ = 0; else if ((v & 0x03) == 0x03) picReadIsr_ = 1; }   // OCW3
            else {                                                                      // OCW2: EOI
                if ((v & 0xE0) == 0x20) { for (int i = 0; i < 8; i++) if (isr_ & (1u << i)) { isr_ &= (uint8_t)~(1u << i); break; } }
                else if ((v & 0xE0) == 0x60) isr_ &= (uint8_t)~(1u << (v & 7));
                raiseTimer();
            }
            updateIrq();
            break;
        case 0x21:
            if (picIcwStep_ == 1) { picBase_ = (uint8_t)(v & 0xF8); picIcwStep_ = 2; }
            else if (picIcwStep_ == 2) { picIcwStep_ = 0; /* ICW3/ICW4: nothing to do */ }
            else { imr_ = v; }
            updateIrq();
            break;
        case 0xA0:
            if (v & 0x10) { spicIcwStep_ = 1; simr_ = 0; sisr_ = 0; sirr_ = 0; }
            else if (v & 0x08) { if ((v & 3) == 2) spicReadIsr_ = 0; else if ((v & 3) == 3) spicReadIsr_ = 1; }
            else if ((v & 0xE0) == 0x20) { for (int i = 0; i < 8; i++) if (sisr_ & (1u << i)) { sisr_ &= (uint8_t)~(1u << i); break; } }
            updateIrq();
            break;
        case 0xA1:
            if (spicIcwStep_ == 1) { spicBase_ = (uint8_t)(v & 0xF8); spicIcwStep_ = 2; }
            else if (spicIcwStep_ == 2) spicIcwStep_ = 0;
            else simr_ = v;
            updateIrq();
            break;
        case 0x40: pitWriteData(0, v); break;
        case 0x42: pitWriteData(2, v); break;
        case 0x43: {
            uint8_t sc = v >> 6, rw = (v >> 4) & 3;
            if (sc == 3) break;                                                         // read-back: ignored
            if (rw == 0) { pitReadLatch_[sc] = (uint16_t)pitCurrent(sc); pitLatched_[sc] = true; pitReadPhase_[sc] = 0; }
            else { pitRw_[sc] = rw; pitWritePhase_[sc] = 0; pitReadPhase_[sc] = 0; }
            break;
        }
        case 0x61: port61_ = v; break;
        case 0x64:
#if POCKET86_MOUSE_DEBUG
            if (v >= 0xA0) say("[MOUSE] 8042 cmd %02X", v);
#endif
            if (v == 0x20) auxPush(kbcCommandByte_, false, false);
            else if (v == 0xAA) auxPush(0x55, false, false);       // controller self-test
            else if (v == 0xAB || v == 0xA9) auxPush(0x00, false, false); // interface tests
            else if (v == 0x60) kbcExpectCommandByte_ = true;
            else if (v == 0xA8) {
                kbcCommandByte_ &= (uint8_t)~0x20; mouseEnabled_ = true;
                if ((kbcCommandByte_ & 0x02) && mouseReporting_)
                    for (uint8_t n = 0, q = auxHead_; n < auxCnt_; ++n, q = (uint8_t)((q + 1) & 63))
                        if (auxIrqQ_[q]) { sirr_ |= (uint8_t)(1u << 4); break; }
            } else if (v == 0xA7) {
                kbcCommandByte_ |= 0x20; mouseEnabled_ = false; sirr_ &= (uint8_t)~(1u << 4);
            } // disable AUX port
            else if (v == 0xAE) kbcCommandByte_ &= (uint8_t)~0x10; // enable keyboard interface
            else if (v == 0xAD) kbcCommandByte_ |= 0x10;          // disable keyboard interface
            else if (v == 0xD4) kbcWriteMouse_ = true;
            updateIrq();
            break;
        case 0x60:
            if (kbcExpectCommandByte_) {
                kbcCommandByte_ = v; kbcExpectCommandByte_ = false;
                if (!(kbcCommandByte_ & 0x02)) sirr_ &= (uint8_t)~(1u << 4);
                else if (!(kbcCommandByte_ & 0x20) && mouseReporting_)
                    for (uint8_t n = 0, q = auxHead_; n < auxCnt_; ++n, q = (uint8_t)((q + 1) & 63))
                        if (auxIrqQ_[q]) { sirr_ |= (uint8_t)(1u << 4); break; }
            }
            else if (kbcWriteMouse_) { kbcWriteMouse_ = false; mouseCommand(v); }
            updateIrq();
            break;
        case 0x70: cmosIndex_ = v & 0x7F; break;
        default: break;
    }
}

// ------------------------------------------------------------------ keyboard

bool BIOS::kbdPeek(uint16_t& key) {
    uint16_t head = bda16(0x1A), tail = bda16(0x1C);
    if (head == tail) return false;
    key = bda16(head);
    return true;
}

uint16_t BIOS::kbdGet() {
    uint16_t head = bda16(0x1A);
    uint16_t key = bda16(head);
    head = (uint16_t)(head + 2);
    if (head >= kBdaKbdEnd) head = kBdaKbdBuf;
    setBda16(0x1A, head);
    return key;
}

bool BIOS::kbdStore(uint16_t word) {
    uint16_t head = bda16(0x1A), tail = bda16(0x1C);
    uint16_t next = (uint16_t)(tail + 2);
    if (next >= kBdaKbdEnd) next = kBdaKbdBuf;
    if (next == head) return false;                        // buffer full
    setBda16(tail, word);
    setBda16(0x1C, next);
    return true;
}

bool BIOS::int9Owned() const {
    return mem_.read16(9u * 4u) == (uint16_t)(CPU8086::TrapBase + 9) && mem_.read16(9u * 4u + 2u) == CPU8086::TrapSegment;
}

// Scan code queue of the keyboard controller. Delivered via IRQ1 -> INT 9; port 60h returns the current code.
void BIOS::hwPush(uint8_t sc, uint16_t word) {
    if (kbcCommandByte_ & 0x10) return;                    // 8042 keyboard clock/interface disabled
    if (imr_ & 2) { scancode_ = sc; return; }              // IRQ1 masked: program polls port 60h
    if (hwCnt_ >= 16) return;
    if (hwCnt_ == 0) scancode_ = sc;
    uint8_t idx = (uint8_t)((hwHead_ + hwCnt_) & 15);
    hwSc_[idx] = sc; hwWord_[idx] = word; hwCnt_++;
    irr_ |= 2;
    updateIrq();
}

// Break code of the current key, then of the Shift/Ctrl that were made up for it.
void BIOS::releaseKey() {
    if (!relActive_) return;
    relActive_ = false;
    hwPush((uint8_t)(relScan_ | 0x80), 0);
    if (pendMods_ & 2) hwPush(0x9D, 0);
    if (pendMods_ & 1) hwPush(0xAA, 0);
    pendMods_ = 0;
}

// mods: bit0 = key needs Shift, bit1 = key needs Ctrl. Programs reading port 60h / hooking INT 9 only see
// scan codes, so without a Shift/Ctrl make code "A", "!" or Ctrl+C arrive as the plain base key.
bool BIOS::pushKey(uint8_t ascii, uint8_t scan, uint8_t hwScan, uint8_t mods) {
    uint8_t hw = (hwScan == 0xFF) ? scan : hwScan;
    uint16_t word = (uint16_t)(((uint16_t)scan << 8) | ascii);
    bool owned = int9Owned();                              // default BIOS INT 9: fill the buffer right away
    if (hw) {
        uint8_t need = 0;
        if ((mods & 1) && !modShift_) need |= 1;
        if ((mods & 2) && !modCtrl_)  need |= 2;
        if (relActive_ && (relScan_ != hw || need != pendMods_)) releaseKey();   // previous key released
        if ((need & 1) && !(pendMods_ & 1)) { hwPush(0x2A, 0); pendMods_ |= 1; }
        if ((need & 2) && !(pendMods_ & 2)) { hwPush(0x1D, 0); pendMods_ |= 2; }
        hwPush(hw, owned ? 0 : word);                      // user INT 9 hooked: the word is stored when it chains to the BIOS
        relScan_ = hw; relActive_ = true; relUs_ = 60000;
    }
    if (owned || !hw) return kbdStore(word);
    return true;
}

void BIOS::keyRelease() {
    held_ = false;
    releaseKey();
}

void BIOS::setModifiers(bool s, bool c, bool a) {
    uint8_t f = (uint8_t)(bda8(0x17) & 0xF0);
    if (s) f |= 0x02;
    if (c) f |= 0x04;
    if (a) f |= 0x08;
    setBda8(0x17, f);
    if (s != modShift_) { modShift_ = s; hwPush(s ? 0x2A : 0xAA, 0); }
    if (c != modCtrl_)  { modCtrl_ = c;  hwPush(c ? 0x1D : 0x9D, 0); }
    if (a != modAlt_)   { modAlt_ = a;   hwPush(a ? 0x38 : 0xB8, 0); }
}

void BIOS::auxPush(uint8_t value, bool irq, bool auxDevice) {
    if (auxCnt_ >= sizeof(auxQ_)) return;
    uint8_t tail = (uint8_t)((auxHead_ + auxCnt_) & 63);
    auxQ_[tail] = value;
    auxAuxQ_[tail] = auxDevice ? 1 : 0;
    bool raiseMouseIrq = irq && (kbcCommandByte_ & 0x02) && !(kbcCommandByte_ & 0x20) && mouseReporting_;
    auxIrqQ_[tail] = raiseMouseIrq ? 1 : 0;
    auxCnt_++;
    if (raiseMouseIrq) sirr_ |= (uint8_t)(1u << 4);
    updateIrq();
}

void BIOS::mouseCommand(uint8_t value) {
#if POCKET86_MOUSE_DEBUG
    say("[MOUSE] PS/2 cmd %02X", value);
#endif
    if (mousePendingParam_) {
        bool valid = false;
        if (mousePendingParam_ == 1) {
            static const uint8_t rates[] = { 10, 20, 40, 60, 80, 100, 200 };
            static const uint8_t codes[] = { 0x0A, 0x14, 0x28, 0x3C, 0x50, 0x64, 0xC8 };
            for (uint8_t i = 0; i < sizeof(codes); ++i) {
                if (value == codes[i]) { mouseSampleRateHz_ = rates[i]; valid = true; break; }
            }
        } else if (mousePendingParam_ == 2 && value <= 3) {
            mouseResolution_ = value;
            valid = true;
        }
        mousePendingParam_ = 0;
        auxPush(valid ? 0xFA : 0xFE, false);
        return;
    }
    switch (value) {
        case 0xFF:
            mouseEnabled_ = false; mouseReporting_ = false; mousePendingParam_ = 0;
            mouseSampleRateHz_ = 100; mouseResolution_ = 2; mouseScale2to1_ = false;
            auxPush(0xFA, false); auxPush(0xAA, false); auxPush(0x00, false); break;
        case 0xF4: mouseEnabled_ = true; mouseReporting_ = true; auxPush(0xFA, false); break;
        case 0xF5: mouseReporting_ = false; auxPush(0xFA, false); break;
        case 0xF6:
            mouseEnabled_ = true; mouseReporting_ = false; mousePendingParam_ = 0;
            mouseSampleRateHz_ = 100; mouseResolution_ = 2; mouseScale2to1_ = false;
            auxPush(0xFA, false); break;
        case 0xF2: auxPush(0xFA, false); auxPush(0x00, false); break; // get device ID: standard PS/2 mouse
        case 0xF3: mousePendingParam_ = 1; auxPush(0xFA, false); break; // set sample-rate parameter
        case 0xE8: mousePendingParam_ = 2; auxPush(0xFA, false); break; // set resolution parameter
        case 0xE6: mouseScale2to1_ = false; auxPush(0xFA, false); break;
        case 0xE7: mouseScale2to1_ = true; auxPush(0xFA, false); break;
        case 0xE9: auxPush(0xFA, false); auxPush(0x00, false); auxPush(0x00, false); auxPush(0x00, false); break;
        case 0xEB: auxPush(0xFA, false); auxPush(0x08, false); auxPush(0x00, false); auxPush(0x00, false); break;
        default: auxPush(0xFA, false); break;
    }
}

void BIOS::m33Reset() {
    m33Seg_ = m33Off_ = m33Mask_ = 0; m33Pending_ = 0;
    m33MickX_ = m33MickY_ = m33DeltaX_ = m33DeltaY_ = 0;
    for (int i = 0; i < 2; i++) m33PressCnt_[i] = m33RelCnt_[i] = m33PressX_[i] = m33PressY_[i] = m33RelX_[i] = m33RelY_[i] = 0;
}

void BIOS::mouseTouch(int16_t x, int16_t y, bool pressed) {
    // readTouch() has no coordinates on release; OnScreenKeyboard initializes x/y to 0
    // in that case. Preserve the last pointer position and emit only the button-up event.
    uint16_t prevX = mouseX_, prevY = mouseY_;
    uint8_t prevBtn = (uint8_t)(mouseButtons_ & 1);
    if (pressed) {
        if (x < 0) x = 0; else if (x > 479) x = 479;
        if (y < 0) y = 0; else if (y > 299) y = 299;   // the CGA picture is 480x300 at the top of the 480x320 TFT
        uint32_t xx = (uint32_t)x * 639u / 479u;
        uint32_t yy = (uint32_t)y * 199u / 299u;
        if (xx < mouseMinX_) xx = mouseMinX_; else if (xx > mouseMaxX_) xx = mouseMaxX_;
        if (yy < mouseMinY_) yy = mouseMinY_; else if (yy > mouseMaxY_) yy = mouseMaxY_;
        mouseX_ = (uint16_t)xx;
        mouseY_ = (uint16_t)yy;
    }
#if POCKET86_TAP_MODE
    // Tap vs. drag: touching only moves the pointer. A short touch without movement is a click (tap);
    // holding still for POCKET86_LONGPRESS_MS presses the button until release (drag); moving first = pointer move only.
    uint32_t nowMs = (uint32_t)(touchClockUs_ / 1000ULL);
    bool vbtn = (mouseButtons_ & 1) != 0;
    if (tapReleasePending_ && (int32_t)(nowMs - tapReleaseAt_) >= 0) { vbtn = false; tapReleasePending_ = false; }
    if (pressed) {
        if (!touchActive_) {
            touchActive_ = true; touchStartMs_ = nowMs; touchStartX_ = x; touchStartY_ = y; touchMoved_ = false; touchHeld_ = false;
        } else {
            int dxs = x - touchStartX_, dys = y - touchStartY_;
            if (dxs * dxs + dys * dys > POCKET86_TAP_SLOP_PX * POCKET86_TAP_SLOP_PX) touchMoved_ = true;
        }
        if (!touchMoved_ && !touchHeld_ && (uint32_t)(nowMs - touchStartMs_) >= POCKET86_LONGPRESS_MS) {
            touchHeld_ = true; vbtn = true; tapReleasePending_ = false;
        }
    } else if (touchActive_) {
        touchActive_ = false;
        if (touchHeld_) vbtn = false;
        else if (!touchMoved_) { vbtn = true; tapReleasePending_ = true; tapReleaseAt_ = nowMs + 60; }   // click = press, release 60 ms later
        touchHeld_ = false;
    }
    mouseButtons_ = vbtn ? 1 : 0;
#else
    mouseButtons_ = pressed ? 1 : 0;
#endif
#if POCKET86_MOUSE_DEBUG
    if ((mouseButtons_ & 1) != prevBtn)
        say("[MOUSE] BUTTON %s at %u,%u", (mouseButtons_ & 1) ? "down" : "up", (unsigned)mouseX_, (unsigned)mouseY_);
#endif

    // ---- INT 33h events (user handler, counters)
    uint8_t ev = 0;
    if (mouseX_ != prevX || mouseY_ != prevY) {
        ev |= 1;
        m33DeltaX_ = (int16_t)((int)mouseX_ - (int)prevX); m33DeltaY_ = (int16_t)((int)mouseY_ - (int)prevY);
        m33MickX_ = (int16_t)(m33MickX_ + m33DeltaX_); m33MickY_ = (int16_t)(m33MickY_ + m33DeltaY_);
    }
    if (pressed && !prevBtn) { ev |= 2; m33PressCnt_[0]++; m33PressX_[0] = mouseX_; m33PressY_[0] = mouseY_; }
    if (!pressed && prevBtn) { ev |= 4; m33RelCnt_[0]++; m33RelX_[0] = mouseX_; m33RelY_[0] = mouseY_; }
    if (ev && (m33Seg_ || m33Off_)) {
        uint8_t hit = (uint8_t)(ev & m33Mask_);
        if (hit) { m33Pending_ |= hit; sirr_ |= (uint8_t)(1u << 4); updateIrq(); }
    }

    // ---- PS/2 AUX packets (INT 15h C2 / port 60h drivers). Large jumps are split into several packets.
    if (mouseReporting_ && !(kbcCommandByte_ & 0x20)) {
        // Windows' PS/2 driver moves the pointer ~2 pixels per count, so send NUM/DEN counts per DOS pixel.
        // The unsent remainder stays in mouseLast*_ and is carried into the next packet.
        int dx = ((int)mouseX_ - (int)mouseLastX_) * POCKET86_PS2_SCALE_NUM / POCKET86_PS2_SCALE_DEN;
        int dy = ((int)mouseLastY_ - (int)mouseY_) * POCKET86_PS2_SCALE_NUM / POCKET86_PS2_SCALE_DEN;
        bool btn = mouseButtons_ != mouseLastButtons_;
        while ((dx || dy || btn) && (sizeof(auxQ_) - auxCnt_) >= 3) {
            int sx = dx > POCKET86_PS2_MAX_STEP ? POCKET86_PS2_MAX_STEP : (dx < -POCKET86_PS2_MAX_STEP ? -POCKET86_PS2_MAX_STEP : dx);
            int sy = dy > POCKET86_PS2_MAX_STEP ? POCKET86_PS2_MAX_STEP : (dy < -POCKET86_PS2_MAX_STEP ? -POCKET86_PS2_MAX_STEP : dy);
            uint8_t b = 0x08 | (mouseButtons_ & 3);
            if (sx < 0) b |= 0x10;
            if (sy < 0) b |= 0x20;
            auxPush(b, true); auxPush((uint8_t)sx, true); auxPush((uint8_t)sy, true);
            dx -= sx; dy -= sy; btn = false;
            mouseLastX_ = (uint16_t)((int)mouseLastX_ + sx * POCKET86_PS2_SCALE_DEN / POCKET86_PS2_SCALE_NUM);
            mouseLastY_ = (uint16_t)((int)mouseLastY_ - sy * POCKET86_PS2_SCALE_DEN / POCKET86_PS2_SCALE_NUM);
            mouseLastButtons_ = mouseButtons_;
        }
    }
}

static uint8_t scanOf(uint8_t ch) {
    static const char* const rows[4] = { "1234567890-=", "qwertyuiop[]", "asdfghjkl;'", "zxcvbnm,./" };
    static const uint8_t base[4] = { 0x02, 0x10, 0x1E, 0x2C };
    if (ch >= 'A' && ch <= 'Z') ch = (uint8_t)(ch + 32);
    switch (ch) {
        case ' ': return 0x39;
        case '\r': case '\n': return 0x1C;
        case 0x1B: return 0x01;
        case 0x08: case 0x7F: return 0x0E;
        case '\t': return 0x0F;
        case '`': return 0x29;
        case '\\': return 0x2B;
    }
    for (int r = 0; r < 4; r++)
        for (int i = 0; rows[r][i]; i++) if ((uint8_t)rows[r][i] == ch) return (uint8_t)(base[r] + i);
    return 0;
}

bool BIOS::pushAlt(uint8_t ch) {
    uint8_t sc = scanOf(ch);
    return sc ? pushKey(0, sc) : false;                    // Alt+key = 00:scan
}

bool BIOS::pushAltScan(uint8_t scan) {
    if (scan >= 0x3B && scan <= 0x44) return pushKey(0, (uint8_t)(scan + 0x2D), scan);   // Alt+F1..F10 = 68h..71h
    return pushKey(0, scan);
}

bool BIOS::pushAscii(uint8_t ch) {
    static const char row0[] = "1234567890-=";   // scan 02..0D
    static const char row0s[] = "!@#$%^&*()_+";
    static const char row1[] = "qwertyuiop[]";    // 10..1B
    static const char row1s[] = "QWERTYUIOP{}";
    static const char row2[] = "asdfghjkl;'";     // 1E..28
    static const char row2s[] = "ASDFGHJKL:\"";
    static const char row3[] = "zxcvbnm,./";      // 2C..35
    static const char row3s[] = "ZXCVBNM<>?";
    if (ch == '\r' || ch == '\n') return pushKey(0x0D, 0x1C);
    if (ch == 0x1B) return pushKey(0x1B, 0x01);
    if (ch == 0x08 || ch == 0x7F) return pushKey(0x08, 0x0E);
    if (ch == '\t') return pushKey(0x09, 0x0F);
    if (ch == ' ') return pushKey(' ', 0x39);
    if (ch == '`') return pushKey(ch, 0x29);
    if (ch == '~') return pushKey(ch, 0x29, 0xFF, 1);
    if (ch == '\\') return pushKey(ch, 0x2B);
    if (ch == '|') return pushKey(ch, 0x2B, 0xFF, 1);
    static const char* const rows[4]  = { row0, row1, row2, row3 };
    static const char* const rowsS[4] = { row0s, row1s, row2s, row3s };
    static const uint8_t base[4] = { 0x02, 0x10, 0x1E, 0x2C };
    for (int r = 0; r < 4; r++)
        for (int i = 0; rows[r][i]; i++) {
            if (ch == (uint8_t)rows[r][i])  return pushKey(ch, (uint8_t)(base[r] + i));
            if (ch == (uint8_t)rowsS[r][i]) return pushKey(ch, (uint8_t)(base[r] + i), 0xFF, 1);   // needs Shift
        }
    if (ch >= 1 && ch <= 26) {                                            // Ctrl+letter
        char letter = (char)('a' + ch - 1);
        for (int r = 1; r < 4; r++)
            for (int i = 0; rows[r][i]; i++) if (letter == rows[r][i]) return pushKey(ch, (uint8_t)(base[r] + i), 0xFF, 2);
    }
    return pushKey(ch, 0);
}

// ------------------------------------------------------------------ video helpers

void BIOS::getCursor(uint8_t p, uint8_t& row, uint8_t& col) const {
    uint16_t v = mem_.read16(0x450u + (p & 7) * 2u);
    col = lo8(v); row = hi8(v);
}

void BIOS::setCursor(uint8_t p, uint8_t row, uint8_t col) {
    p &= 7;
    mem_.write16(0x450u + p * 2u, (uint16_t)(((uint16_t)row << 8) | col));
    if (p == bda8(0x62)) cga_.setCursorCell((uint16_t)(p * 0x800u + (uint16_t)row * 80u + col));
}

void BIOS::setVideoMode(uint8_t mode, bool clear) {
    uint8_t modeReg, colorReg;
    switch (mode) {
        case 4:  modeReg = 0x0A; colorReg = 0x30; break;   // 320x200, 4 colours
        case 5:  modeReg = 0x0E; colorReg = 0x30; break;   // 320x200, colour burst off
        case 6:  modeReg = 0x1E; colorReg = 0x3F; break;   // 640x200, 2 colours
        case 0: case 1: modeReg = 0x28; colorReg = 0x30; mode &= 1; break;
        default: modeReg = 0x29; colorReg = 0x30; mode = 3; break;
    }
    cga_.setMode(modeReg, colorReg);
    setBda8(0x49, mode);
    setBda8(0x65, modeReg);
    setBda8(0x66, colorReg);
    if (clear) clearScreen();
}

void BIOS::clearScreen() {
    if (cga_.graphics()) cga_.clearGraphics(); else cga_.clear(0x07);
    for (int p = 0; p < 8; p++) mem_.write16(0x450u + p * 2u, 0);
    setBda8(0x62, 0);
    setBda16(0x4E, 0);
}

void BIOS::scroll(bool up, uint8_t lines, uint8_t attr, uint8_t top, uint8_t left, uint8_t bottom, uint8_t right) {
    if (cga_.graphics()) {                               // no text rendering in graphics modes: only "clear window" for the full screen
        if (lines == 0 && top == 0 && left == 0 && bottom >= 24 && right >= (cga_.hires() ? 79 : 39)) cga_.clearGraphics();
        return;
    }
    if (bottom > 24) bottom = 24;
    if (right > 79) right = 79;
    if (top > bottom || left > right) return;
    uint8_t* v = page(bda8(0x62));
    uint8_t height = (uint8_t)(bottom - top + 1);
    if (lines == 0 || lines >= height) {
        for (uint8_t r = top; r <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
        return;
    }
    if (up) {
        for (uint8_t r = top; r + lines <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = v[((r + lines) * 80 + c) * 2]; v[(r * 80 + c) * 2 + 1] = v[((r + lines) * 80 + c) * 2 + 1]; }
        for (uint8_t r = (uint8_t)(bottom - lines + 1); r <= bottom; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
    } else {
        for (int r = bottom; r - lines >= top; r--)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = v[((r - lines) * 80 + c) * 2]; v[(r * 80 + c) * 2 + 1] = v[((r - lines) * 80 + c) * 2 + 1]; }
        for (uint8_t r = top; r < top + lines; r++)
            for (uint8_t c = left; c <= right; c++) { v[(r * 80 + c) * 2] = ' '; v[(r * 80 + c) * 2 + 1] = attr; }
    }
}

void BIOS::teletype(uint8_t ch, uint8_t pageNo, bool useAttr, uint8_t attr) {
    uint8_t row, col;
    getCursor(pageNo, row, col);
    uint8_t* v = page(pageNo);
    const bool gfx = cga_.graphics();
    const uint8_t cols = (gfx && !cga_.hires()) ? 40 : 80;
    switch (ch) {
        case 0x07: break;
        case 0x08: if (col > 0) col--; break;
        case 0x0A: row++; break;
        case 0x0D: col = 0; break;
        default:
            if (!gfx) {
                v[(row * 80 + col) * 2] = ch;
                if (useAttr) v[(row * 80 + col) * 2 + 1] = attr;
            }                                            // graphics: no ROM font, the cursor just advances
            col++;
            if (col >= cols) { col = 0; row++; }
            break;
    }
    if (row >= 25) { scroll(true, 1, 0x07, 0, 0, 24, 79); row = 24; }
    setCursor(pageNo, row, col);
}

void BIOS::printString(const char* s) { while (*s) teletype((uint8_t)*s++, 0); }

// ------------------------------------------------------------------ INT 10h

CPU8086::TrapResult BIOS::int10() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax), al = lo8(r.ax);
    uint8_t activePage = bda8(0x62);
    switch (ah) {
        case 0x00: {
            uint8_t mode = al & 0x7F;                     // 0-3 text, 4/5/6 CGA graphics, anything else (MDA/EGA/VGA) -> mode 3
            setVideoMode(mode, !(al & 0x80));
            break;
        }
        case 0x01:
            cga_.setCursorShape(hi8(r.cx), lo8(r.cx));
            setBda16(0x60, (uint16_t)((lo8(r.cx) ) | (hi8(r.cx) << 8)));
            break;
        case 0x02: setCursor(hi8(r.bx), hi8(r.dx), lo8(r.dx)); break;
        case 0x03: {
            uint8_t row, col; getCursor(hi8(r.bx), row, col);
            r.dx = (uint16_t)((row << 8) | col);
            r.cx = (uint16_t)((cga_.cursorStartLine() << 8) | cga_.cursorEndLine());
            r.ax = 0;
            break;
        }
        case 0x04: r.ax = 0; break;
        case 0x05: {
            break;                                       // only page 0 exists
        }
        case 0x06: case 0x07: scroll(ah == 0x06, al, hi8(r.bx), hi8(r.cx), lo8(r.cx), hi8(r.dx), lo8(r.dx)); break;
        case 0x0B:                                       // CGA palette: BH=0 background/border colour, BH=1 palette select
            if (hi8(r.bx) == 0) cga_.setMode(cga_.modeControl(), (uint8_t)((cga_.colorControl() & 0xF0) | (lo8(r.bx) & 0x0F)));
            else if (hi8(r.bx) == 1) cga_.setMode(cga_.modeControl(), (uint8_t)((cga_.colorControl() & ~0x20) | ((lo8(r.bx) & 1) ? 0x20 : 0)));
            setBda8(0x66, cga_.colorControl());
            break;
        case 0x0C:                                       // write pixel: AL colour (bit 7 = XOR), CX x, DX y
            if (cga_.graphics()) cga_.putPixel(r.cx, r.dx, al & 0x7F, (al & 0x80) != 0);
            break;
        case 0x0D:                                       // read pixel
            if (cga_.graphics()) setLo(r.ax, cga_.getPixel(r.cx, r.dx));
            break;
        case 0x08: {
            if (cga_.graphics()) { r.ax = 0x0700; break; }
            uint8_t p = hi8(r.bx) & 3, row, col; getCursor(p, row, col);
            uint8_t* v = page(p);
            r.ax = (uint16_t)((v[(row * 80 + col) * 2 + 1] << 8) | v[(row * 80 + col) * 2]);
            break;
        }
        case 0x09: case 0x0A: {
            if (cga_.graphics()) break;                  // no ROM font: nothing is drawn
            uint8_t p = hi8(r.bx) & 3, row, col; getCursor(p, row, col);
            uint8_t* v = page(p);
            uint16_t n = r.cx; uint16_t cell = (uint16_t)(row * 80 + col);
            while (n-- && cell < 2000) {
                v[cell * 2] = al;
                if (ah == 0x09) v[cell * 2 + 1] = lo8(r.bx);
                cell++;
            }
            break;
        }
        case 0x0E: teletype(al, activePage); break;
        case 0x0F: r.ax = (uint16_t)(((cga_.graphics() && !cga_.hires() ? 40 : 80) << 8) | bda8(0x49)); setHi(r.bx, activePage); break;
        case 0x13: {
            uint8_t p = hi8(r.bx) & 3;
            uint8_t savedRow, savedCol; getCursor(p, savedRow, savedCol);
            setCursor(p, hi8(r.dx), lo8(r.dx));
            for (uint16_t i = 0; i < r.cx; i++) {
                uint8_t ch, at;
                if (al & 2) { ch = cpu_.peek8(r.es, (uint16_t)(r.bp + i * 2)); at = cpu_.peek8(r.es, (uint16_t)(r.bp + i * 2 + 1)); }
                else { ch = cpu_.peek8(r.es, (uint16_t)(r.bp + i)); at = lo8(r.bx); }
                if (ch == 7 || ch == 8 || ch == 10 || ch == 13) teletype(ch, p);
                else teletype(ch, p, true, at);
            }
            if (!(al & 1)) setCursor(p, savedRow, savedCol);
            break;
        }
        default: break;                                  // everything else: accepted, ignored
    }
    return CPU8086::TrapReturn;
}

// ------------------------------------------------------------------ INT 13h

uint8_t BIOS::diskResult(uint8_t status, bool setCarry) {
    CPU8086::Registers& r = cpu_.registers();
    setBda8(0x41, status);
    setHi(r.ax, status);
    if (setCarry) setCF(r, status != 0);
    return status;
}

uint8_t BIOS::transfer(DiskImage* d, bool write, uint8_t count, uint16_t cyl, uint8_t head, uint8_t sec, uint16_t seg, uint16_t off, uint8_t& done) {
    done = 0;
    if (!d || !d->present()) return 0x80;
    if (cyl >= d->cylinders() || head >= d->heads() || sec == 0 || sec > d->sectorsPerTrack()) return 0x04;
    if (write && !d->writable()) return 0x03;
    uint32_t lba = ((uint32_t)cyl * d->heads() + head) * d->sectorsPerTrack() + (sec - 1);
    for (uint8_t i = 0; i < count; i++) {
        uint32_t phys = (((uint32_t)seg << 4) + (uint16_t)(off + i * 512u)) & 0xFFFFFu;
        uint8_t* pg = mem_.pagePtr(phys);
        bool direct = pg && ((phys & 0xFFFu) + 512u <= 4096u) && ((uint32_t)(uint16_t)(off + i * 512u) + 512u <= 0x10000u);
        uint8_t* ram = direct ? pg + (phys & 0xFFFu) : nullptr;
        if (write) {
            uint8_t buf[512];
            const uint8_t* src = direct ? ram : buf;
            if (!direct) for (int k = 0; k < 512; k++) buf[k] = mem_.read8((phys + k) & 0xFFFFFu);
            if (!d->write(lba + i, src)) return 0x04;
        } else {
            if (direct) { if (!d->read(lba + i, ram)) return 0x04; }
            else {
                uint8_t buf[512];
                if (!d->read(lba + i, buf)) return 0x04;
                for (int k = 0; k < 512; k++) mem_.write8((phys + k) & 0xFFFFFu, buf[k]);
            }
        }
        done++;
    }
    return 0;
}

CPU8086::TrapResult BIOS::int13() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax), al = lo8(r.ax), dl = lo8(r.dx);
    DiskImage* d = drives_.byBiosNumber(dl);
    bool present = d && d->present();
    uint16_t cyl = (uint16_t)(hi8(r.cx) | ((uint16_t)(lo8(r.cx) & 0xC0) << 2));
    uint8_t sec = lo8(r.cx) & 0x3F, head = hi8(r.dx);

    switch (ah) {
        case 0x00: case 0x0D: case 0x10: case 0x11: case 0x0C: case 0x14:
            diskResult(present ? 0 : 0x80); break;
        case 0x01: {
            uint8_t st = bda8(0x41);
            setHi(r.ax, st); setCF(r, st != 0);
            break;
        }
        case 0x02: case 0x03: case 0x04: {
            uint8_t done = 0, st;
            if (al == 0) st = 0x01;
            else if (ah == 0x04) st = present ? ((cyl < d->cylinders() && head < d->heads() && sec >= 1 && sec <= d->sectorsPerTrack()) ? 0 : 0x04) : 0x80;
            else st = transfer(d, ah == 0x03, al, cyl, head, sec, r.es, r.bx, done);
            if (ah == 0x04) done = al;
            setLo(r.ax, done);
            diskResult(st);
            if (st && ah != 0x04) setLo(r.ax, done);
            break;
        }
        case 0x05: {
            uint8_t st = 0;
            if (!present) st = 0x80;
            else if (!d->writable()) st = 0x03;
            else if (cyl >= d->cylinders() || head >= d->heads()) st = 0x04;
            else {
                uint8_t blank[512]; memset(blank, 0xF6, sizeof(blank));
                uint32_t base = ((uint32_t)cyl * d->heads() + head) * d->sectorsPerTrack();
                for (uint8_t s = 0; s < d->sectorsPerTrack(); s++) d->write(base + s, blank);
            }
            diskResult(st);
            break;
        }
        case 0x08: {
            if (!present) { diskResult(dl & 0x80 ? 0x07 : 0x01); r.cx = r.dx = 0; break; }
            uint16_t maxCyl = (uint16_t)(d->cylinders() - 1);
            r.cx = (uint16_t)(((maxCyl & 0xFF) << 8) | ((maxCyl >> 2) & 0xC0) | d->sectorsPerTrack());
            r.dx = (uint16_t)(((d->heads() - 1) << 8) | (d->isFloppy() ? drives_.floppyCount() : drives_.hardCount()));
            if (d->isFloppy()) { setLo(r.bx, d->floppyType()); r.es = CPU8086::TrapSegment; r.di = kDisketteTable; }
            r.ax = 0;
            setBda8(0x41, 0);
            setCF(r, false);
            break;
        }
        case 0x15: {
            if (!present) { r.ax = 0; setCF(r, false); break; }
            if (d->isFloppy()) { r.ax = 0x0200; setCF(r, false); }
            else { uint32_t s = d->totalSectors(); r.cx = (uint16_t)(s >> 16); r.dx = (uint16_t)s; r.ax = 0x0300; setCF(r, false); }
            break;
        }
        case 0x16: {
            if (!present) { diskResult(0x80); break; }
            if (d->isFloppy() && d->takeChanged()) diskResult(0x06); else diskResult(0);
            break;
        }
        case 0x17: case 0x09: diskResult(present ? 0 : 0x80); break;
        case 0x18: {
            if (!present || !d->isFloppy()) { diskResult(present ? 0x01 : 0x80); break; }
            r.es = CPU8086::TrapSegment; r.di = kDisketteTable; diskResult(0);
            break;
        }
        default:
            diskResult(0x01);                              // invalid function (also: no INT 13h extensions)
            break;
    }
    return CPU8086::TrapReturn;
}

// ------------------------------------------------------------------ INT 16h

CPU8086::TrapResult BIOS::int16h() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax);
    uint16_t key;
    switch (ah) {
        case 0x00: case 0x10:
            if (kbdPeek(key)) { r.ax = kbdGet(); return CPU8086::TrapReturn; }
            return CPU8086::TrapBlock;
        case 0x01: case 0x11:
            if (kbdPeek(key)) { r.ax = key; setZF(r, false); } else setZF(r, true);
            return CPU8086::TrapReturn;
        case 0x02: case 0x12:
            r.ax = (ah == 0x12) ? bda16(0x17) : (uint16_t)bda8(0x17);
            return CPU8086::TrapReturn;
        case 0x05:
            setLo(r.ax, pushKey(lo8(r.cx), hi8(r.cx)) ? 0 : 1);
            return CPU8086::TrapReturn;
        default:
            return CPU8086::TrapReturn;
    }
}

// ------------------------------------------------------------------ BIOS PS/2 mouse IRQ12 / INT 15h C207h callback

CPU8086::TrapResult BIOS::int74h() {
    // FabGL's handler reads exactly one byte from port 60h for each IRQ12,
    // buffers bytes until the configured packet length, then calls the driver.
    if (!auxCnt_) {
        sisr_ &= (uint8_t)~(1u << 4); isr_ &= (uint8_t)~4u;
        if (m33Pending_ && (m33Seg_ | m33Off_)) {
            // INT 33h user handler (AX=event mask, BX=buttons, CX/DX=position, SI/DI=mickeys).
            // Save all registers; the handler's RETF lands on F000:1210 (POP ES, POP DS, POPA, IRET).
            uint8_t m = m33Pending_; m33Pending_ = 0;
            updateIrq();
#if POCKET86_MOUSE_DEBUG
            say("[MOUSE] INT33 handler call ev=%02X %04X:%04X pos=%u,%u", m, m33Seg_, m33Off_, mouseX_, mouseY_);
#endif
            CPU8086::Registers& r = cpu_.registers();
            uint16_t oldSp = r.sp;
            cpu_.push(r.ax); cpu_.push(r.cx); cpu_.push(r.dx); cpu_.push(r.bx);
            cpu_.push(oldSp); cpu_.push(r.bp); cpu_.push(r.si); cpu_.push(r.di);
            cpu_.push(r.ds); cpu_.push(r.es);
            r.ax = m; r.bx = mouseButtons_; r.cx = mouseX_; r.dx = mouseY_;
            r.si = (uint16_t)m33DeltaX_; r.di = (uint16_t)m33DeltaY_;
            cpu_.push(CPU8086::TrapSegment);
            cpu_.push(0x1210);
            r.cs = m33Seg_; r.ip = m33Off_;
            return CPU8086::TrapJumped;
        }
        updateIrq();
        return CPU8086::TrapReturn;
    }
    // FabGL preserves the registers which its assembly IRQ handler uses while
    // reading the 8042 and calling the BIOS mouse driver.
    CPU8086::Registers& r = cpu_.registers();
    cpu_.push(r.ax); cpu_.push(r.bx); cpu_.push(r.cx); cpu_.push(r.ds);
    uint8_t byte = portRead(0x60);
    if (mousePacketIndex_ < sizeof(mousePacket_)) {
        mousePacket_[mousePacketIndex_] = byte;
        if (ebdaSegment_) setEbda8((uint16_t)(kEbdaPacket + mousePacketIndex_), byte);
    }
    ++mousePacketIndex_;
    bool complete = mousePacketIndex_ >= mousePacketBytes_;
    if (ebdaSegment_) setEbda8(kEbdaFlags1, (uint8_t)((ebda8(kEbdaFlags1) & 0xF8) | (mousePacketIndex_ & 7)));
    if (complete) {
        mousePacketIndex_ = 0;
        if (ebdaSegment_) setEbda8(kEbdaFlags1, (uint8_t)(ebda8(kEbdaFlags1) & 0xF8));
#if POCKET86_MOUSE_DEBUG
        say("[MOUSE] packet %02X %02X %02X", mousePacket_[0], mousePacket_[1], mousePacket_[2]);
#endif
    }
    sisr_ &= (uint8_t)~(1u << 4); isr_ &= (uint8_t)~4u;
    if (m33Pending_) sirr_ |= (uint8_t)(1u << 4);
    updateIrq();
    if (!complete || !mouseCallbackSeg_ || !mouseCallbackOff_) {
        r.ds = cpu_.pop(); r.cx = cpu_.pop(); r.bx = cpu_.pop(); r.ax = cpu_.pop();
        return CPU8086::TrapReturn;
    }

    // FabGL pushes four zero-extended bytes from EBDA_PACKET in order before CALL FAR.
    for (uint8_t i = 0; i < 4; ++i) cpu_.push(i < mousePacketBytes_ ? mousePacket_[i] : 0);
    cpu_.push(CPU8086::TrapSegment);
    cpu_.push(0x1200);
    r.cs = mouseCallbackSeg_; r.ip = mouseCallbackOff_;
    return CPU8086::TrapJumped;
}

// ------------------------------------------------------------------ INT 33h (DOS mouse driver API)

CPU8086::TrapResult BIOS::int33h() {
    CPU8086::Registers& r = cpu_.registers();
    auto clampPos = [&]() {
        if (mouseX_ < mouseMinX_) mouseX_ = mouseMinX_;
        if (mouseX_ > mouseMaxX_) mouseX_ = mouseMaxX_;
        if (mouseY_ < mouseMinY_) mouseY_ = mouseMinY_;
        if (mouseY_ > mouseMaxY_) mouseY_ = mouseMaxY_;
    };
#if POCKET86_MOUSE_DEBUG
    { if (r.ax != 0x0003 && r.ax != 0x000B) { say("[MOUSE] INT33 AX=%04X BX=%04X CX=%04X DX=%04X", r.ax, r.bx, r.cx, r.dx); } }
#endif
    switch (r.ax) {                                       // the function number is the whole of AX
        case 0x00: case 0x21:                             // reset / software reset
            r.ax = 0xFFFF; r.bx = 2;
            mouseButtons_ = mouseLastButtons_ = 0;
            mouseX_ = mouseLastX_ = 320; mouseY_ = mouseLastY_ = 100;
            mouseEnabled_ = true; mouseReporting_ = false; mouseVisible_ = false;
            mouseMinX_ = mouseMinY_ = 0; mouseMaxX_ = 639; mouseMaxY_ = 199;
            m33Reset();
            return CPU8086::TrapReturn;
        case 0x01: mouseVisible_ = true; return CPU8086::TrapReturn;
        case 0x02: mouseVisible_ = false; return CPU8086::TrapReturn;
        case 0x03: r.bx = mouseButtons_; r.cx = mouseX_; r.dx = mouseY_; return CPU8086::TrapReturn;
        case 0x04: mouseX_ = r.cx; mouseY_ = r.dx; clampPos(); return CPU8086::TrapReturn;
        case 0x05: case 0x06: {                           // button press / release data
            uint16_t b = r.bx; if (b > 1) b = 1;
            bool press = r.ax == 0x05;
            r.ax = mouseButtons_;
            if (press) { r.bx = m33PressCnt_[b]; r.cx = m33PressX_[b]; r.dx = m33PressY_[b]; m33PressCnt_[b] = 0; }
            else       { r.bx = m33RelCnt_[b];   r.cx = m33RelX_[b];   r.dx = m33RelY_[b];   m33RelCnt_[b] = 0; }
            return CPU8086::TrapReturn;
        }
        case 0x07:
            mouseMinX_ = r.cx; mouseMaxX_ = r.dx;
            if (mouseMinX_ > mouseMaxX_) { uint16_t t = mouseMinX_; mouseMinX_ = mouseMaxX_; mouseMaxX_ = t; }
            clampPos(); return CPU8086::TrapReturn;
        case 0x08:
            mouseMinY_ = r.cx; mouseMaxY_ = r.dx;
            if (mouseMinY_ > mouseMaxY_) { uint16_t t = mouseMinY_; mouseMinY_ = mouseMaxY_; mouseMaxY_ = t; }
            clampPos(); return CPU8086::TrapReturn;
        case 0x0B: r.cx = (uint16_t)m33MickX_; r.dx = (uint16_t)m33MickY_; m33MickX_ = m33MickY_ = 0; return CPU8086::TrapReturn;
        case 0x0C:                                        // install user handler: CX = event mask, ES:DX = handler
            m33Mask_ = r.cx & 0x1F; m33Off_ = r.dx; m33Seg_ = r.es;
            if (!m33Mask_) { m33Off_ = m33Seg_ = 0; m33Pending_ = 0; }
            return CPU8086::TrapReturn;
        case 0x14: {                                      // swap user handlers
            uint16_t oM = m33Mask_, oS = m33Seg_, oO = m33Off_;
            m33Mask_ = r.cx & 0x1F; m33Off_ = r.dx; m33Seg_ = r.es;
            if (!m33Mask_) { m33Off_ = m33Seg_ = 0; m33Pending_ = 0; }
            r.cx = oM; r.es = oS; r.dx = oO;
            return CPU8086::TrapReturn;
        }
        case 0x15: r.bx = 0; return CPU8086::TrapReturn;  // driver state buffer size
        case 0x1F: r.ax = 0x001F; r.es = 0; r.bx = 0; return CPU8086::TrapReturn;   // disable driver
        case 0x20: r.ax = 0x0020; return CPU8086::TrapReturn;                        // enable driver
        case 0x24: r.ax = 0x0024; r.bx = 0x0626; r.cx = 0x0400; return CPU8086::TrapReturn;   // version 6.26, PS/2 type, IRQ 0 (PS/2)
        default: return CPU8086::TrapReturn;
    }
}

// ------------------------------------------------------------------ INT 1Ah / INT 08h

CPU8086::TrapResult BIOS::int1A() {
    CPU8086::Registers& r = cpu_.registers();
    uint8_t ah = hi8(r.ax);
    if (ah == 0x00) {
        r.dx = bda16(0x6C); r.cx = bda16(0x6E);
        r.ax = (uint16_t)bda8(0x70);
        setBda8(0x70, 0);
    } else if (ah == 0x01) {
        setBda16(0x6C, r.dx); setBda16(0x6E, r.cx); setBda8(0x70, 0);
        setHi(r.ax, 0);
    } else {
        setCF(r, true);                                  // no RTC / PCI BIOS on an XT-class machine
    }
    return CPU8086::TrapReturn;
}

CPU8086::TrapResult BIOS::int08() {
    uint32_t t = ticks() + 1;
    if (t >= 0x1800B0UL) { t = 0; setBda8(0x70, 1); }
    setBda16(0x6C, (uint16_t)t); setBda16(0x6E, (uint16_t)(t >> 16));
    isr_ &= (uint8_t)~1u;                                // end of interrupt for IRQ0
    raiseTimer();
    // chain to the user timer hook INT 1Ch; its IRET returns straight to the interrupted code
    CPU8086::Registers& r = cpu_.registers();
    r.ip = mem_.read16(0x1C * 4u);
    r.cs = mem_.read16(0x1C * 4u + 2u);
    return CPU8086::TrapJumped;
}

// ------------------------------------------------------------------ trap dispatcher

CPU8086::TrapResult BIOS::trap(uint16_t id) {
    CPU8086::Registers& r = cpu_.registers();
    if (id == 0x101 || id == 0x100) {                    // reset vector / boot retry
        if (id == 0x101 || !posted_) post();
        if (bootstrap()) return CPU8086::TrapJumped;
        if (!bootFailed_) { printString("No bootable disk. Mount an image and press any key.\r\n"); say("[BIOS] no bootable disk"); }
        bootFailed_ = true;
        uint16_t key;
        if (kbdPeek(key)) kbdGet();
        r.cs = CPU8086::TrapSegment; r.ip = 0x1100;
        r.flags |= CPU8086::IF;
        cpu_.clearBlocked();
        return CPU8086::TrapBlock;
    }
    switch (id) {
        case 0x06: {
            uint16_t ip = cpu_.peek16(r.ss, r.sp), cs = cpu_.peek16(r.ss, (uint16_t)(r.sp + 2));
            say("[CPU] invalid opcode %02X at %04X:%04X", cpu_.lastInvalidOpcode(), cs, ip);
            cpu_.halt();
            return CPU8086::TrapJumped;
        }
        case 0x08: return int08();
        case 0x09:                                       // BIOS keyboard handler (reached by IRQ1 or chained from a user INT 9)
            if (curWord_) { kbdStore(curWord_); curWord_ = 0; }
            isr_ &= (uint8_t)~2u; updateIrq(); return CPU8086::TrapReturn;
        case 0x74: return int74h();                      // BIOS PS/2 mouse IRQ12
        case 0x10: return int10();
#if POCKET86_MOUSE_DEBUG
        case 0x11: say("[MOUSE] INT11 equip=%04X", bda16(0x10)); r.ax = bda16(0x10); return CPU8086::TrapReturn;
#else
        case 0x11: r.ax = bda16(0x10); return CPU8086::TrapReturn;
#endif
        case 0x12: r.ax = bda16(0x13); return CPU8086::TrapReturn;
        case 0x13: return int13();
        case 0x14: setHi(r.ax, 0x80); return CPU8086::TrapReturn;
        case 0x15:
            // IBM PS/2 BIOS mouse services (INT 15h, AH=C2h).  DOS mouse
            // drivers use this call to decide whether a PS/2 AUX device exists
            // before they install their IRQ12 handler.
            if (hi8(r.ax) == 0xC2) {
#if POCKET86_MOUSE_DEBUG
                say("[MOUSE] INT15 AX=%04X BX=%04X ES:BX=%04X:%04X", r.ax, r.bx, r.es, r.bx);
#endif
                switch (lo8(r.ax)) {
                    case 0x00: // enable/disable, BH=0 disables and BH=1 enables
                        if (hi8(r.bx) == 0) { mouseEnabled_ = false; mouseReporting_ = false; kbcCommandByte_ |= 0x20; sirr_ &= (uint8_t)~(1u << 4); updateIrq(); }
                        else if (hi8(r.bx) == 1) {   // like the real BIOS: enable the AUX port, IRQ12 and data reporting (F4h)
                            mouseEnabled_ = true; mouseReporting_ = true;
                            kbcCommandByte_ &= (uint8_t)~0x20; kbcCommandByte_ |= 0x02;
                            mouseLastX_ = mouseX_; mouseLastY_ = mouseY_; mouseLastButtons_ = mouseButtons_;
                            for (uint8_t n = 0, q = auxHead_; n < auxCnt_; ++n, q = (uint8_t)((q + 1) & 63))
                                if (auxIrqQ_[q]) { sirr_ |= (uint8_t)(1u << 4); break; }
                            updateIrq();
                        }
                        else { setHi(r.ax, 1); setCF(r, true); break; }
                        setHi(r.ax, 0); setCF(r, false); break;
                    case 0x01: // FabGL: reset state and return the standard device ID in BH
                        mouseEnabled_ = false; mouseReporting_ = false; kbcCommandByte_ |= 0x20;
                        mouseLastX_ = mouseX_; mouseLastY_ = mouseY_; mouseButtons_ = mouseLastButtons_ = 0;
                        mousePacketIndex_ = 0; mousePendingParam_ = 0;
                        mouseSampleRateHz_ = 100; mouseResolution_ = 2; mouseScale2to1_ = false;
                        sirr_ &= (uint8_t)~(1u << 4); updateIrq();
                        setHi(r.bx, 0);                          // FabGL leaves BL unchanged; BH=standard mouse ID 0
                        setHi(r.ax, 0); setCF(r, false); break;
                    case 0x02: { // BH index 0..6: 10,20,40,60,80,100,200 reports/sec
                        static const uint8_t rates[] = { 10, 20, 40, 60, 80, 100, 200 };
                        if (hi8(r.bx) <= 6) { mouseSampleRateHz_ = rates[hi8(r.bx)]; setHi(r.ax, 0); setCF(r, false); }
                        else { setHi(r.ax, 2); setCF(r, true); }
                        break;
                    }
                    case 0x03: // BH=0..3: 1,2,4,8 counts/mm
                        if (hi8(r.bx) <= 3) { mouseResolution_ = hi8(r.bx); setHi(r.ax, 0); setCF(r, false); }
                        else { setHi(r.ax, 2); setCF(r, true); }
                        break;
                    case 0x04: // get device type
                        setHi(r.bx, 0); setHi(r.ax, 0); setCF(r, false); break;
                    case 0x05: // initialize; FabGL takes packet length from the connected mouse, not BH
                        mousePacketBytes_ = 3; mousePacketIndex_ = 0; mouseEnabled_ = false; mouseReporting_ = false;
                        mouseSampleRateHz_ = 100; mouseResolution_ = 2; mouseScale2to1_ = false; mousePendingParam_ = 0;
                        kbcCommandByte_ |= 0x20; sirr_ &= (uint8_t)~(1u << 4); updateIrq();
                        mouseCallbackSeg_ = mouseCallbackOff_ = 0;
                        if (ebdaSegment_) {
                            setEbda16(kEbdaDriverOffset, 0);
                            setEbda16(kEbdaDriverSegment, 0);
                            setEbda8(kEbdaFlags1, 0);
                            setEbda8(kEbdaFlags2, mousePacketBytes_);
                        }
                        setHi(r.ax, 0); setCF(r, false); break;
                    case 0x06: // extended commands: get status or set scaling
                        if (hi8(r.bx) == 0) {
                            uint8_t status = (uint8_t)((mouseEnabled_ ? 0x20 : 0) |
                                ((mouseButtons_ & 1) ? 0x04 : 0) | ((mouseButtons_ & 2) ? 0x01 : 0) |
                                (mouseScale2to1_ ? 0x10 : 0));
                            setLo(r.bx, status); setLo(r.cx, mouseResolution_); setLo(r.dx, mouseSampleRateHz_);
                            setHi(r.ax, 0); setCF(r, false);
                        }
                        else if (hi8(r.bx) == 1) { mouseScale2to1_ = false; setHi(r.ax, 0); setCF(r, false); }
                        else if (hi8(r.bx) == 2) { mouseScale2to1_ = true; setHi(r.ax, 0); setCF(r, false); }
                        else { setHi(r.ax, 1); setCF(r, true); }
                        break;
                    case 0x07: // register BIOS callback ES:BX
                        mouseCallbackSeg_ = r.es; mouseCallbackOff_ = r.bx;
                        if (ebdaSegment_) {
                            setEbda16(kEbdaDriverOffset, mouseCallbackOff_);
                            setEbda16(kEbdaDriverSegment, mouseCallbackSeg_);
                            uint8_t flags = ebda8(kEbdaFlags2);
                            setEbda8(kEbdaFlags2, (mouseCallbackSeg_ || mouseCallbackOff_) ? (uint8_t)(flags | 0x80) : (uint8_t)(flags & 0x7F));
                        }
                        setHi(r.ax, 0); setCF(r, false); break;
                    case 0x09: // read one queued byte (PS/2 BIOS extension)
                        if (auxCnt_) { r.bx = portRead(0x60); setHi(r.ax, 0); setCF(r, false); }
                        else { setHi(r.ax, 1); setCF(r, true); }
                        break;
                    default: setHi(r.ax, 0x86); setCF(r, true); break;
                }
                return CPU8086::TrapReturn;
            }
            if (hi8(r.ax) == 0xC1) {
                if (ebdaSegment_) { r.es = ebdaSegment_; setHi(r.ax, 0); setCF(r, false); }
                else { setHi(r.ax, 0x86); setCF(r, true); }
                return CPU8086::TrapReturn;
            }
            if (hi8(r.ax) == 0xC0) {
#if POCKET86_MOUSE_DEBUG
                say("[MOUSE] INT15 C0 (system config)");
#endif
                r.es = CPU8086::TrapSegment; r.bx = 0x1040; setHi(r.ax, 0); setCF(r, false); return CPU8086::TrapReturn; }
            setHi(r.ax, 0x86); setCF(r, true); return CPU8086::TrapReturn;
        case 0x16: return int16h();
        case 0x17: setHi(r.ax, 0x01); return CPU8086::TrapReturn;
        case 0x19:
            if (bootstrap()) return CPU8086::TrapJumped;
            return CPU8086::TrapReturn;
        case 0x1A: return int1A();
        case 0x33: return int33h();
        default: return CPU8086::TrapReturn;             // unowned vectors behave like IRET
    }
}

} // namespace Pocket86
