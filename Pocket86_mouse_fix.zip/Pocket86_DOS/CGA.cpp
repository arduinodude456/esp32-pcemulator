#include "CGA.h"
#include <string.h>

namespace Pocket86 {

CGA::CGA(PCMemory& m) : mem_(m), regs_{}, index_(0), modeReg_(0x29), colorReg_(0x30), statusToggle_(0) {
    regs_[0x0A] = 0x06;
    regs_[0x0B] = 0x07;
    clear();
}

void CGA::clear(uint8_t attr) {
    uint8_t* v = mem_.video();
    if (!v) return;
    for (uint32_t i = 0; i < PCMemory::VideoStore; i += 2) { v[i] = ' '; v[i + 1] = attr; }
    setCursorCell(0);
    setStartCell(0);
}

void CGA::clearGraphics() {
    uint8_t* v = mem_.video();
    if (v) memset(v, 0, PCMemory::VideoStore);
}

// Interleaved frame buffer: even scanlines at B800:0000, odd scanlines at B800:2000, 80 bytes per line.
void CGA::putPixel(uint16_t x, uint16_t y, uint8_t value, bool xorMode) {
    uint8_t* v = mem_.video();
    if (!v || y >= 200) return;
    uint32_t row = (uint32_t)((y & 1) ? 0x2000 : 0) + (uint32_t)(y >> 1) * 80u;
    if (hires()) {
        if (x >= 640) return;
        uint8_t mask = (uint8_t)(0x80 >> (x & 7));
        uint8_t& b = v[row + (x >> 3)];
        if (xorMode) { if (value & 1) b ^= mask; }
        else b = (uint8_t)((value & 1) ? (b | mask) : (b & ~mask));
    } else {
        if (x >= 320) return;
        uint8_t shift = (uint8_t)(6 - 2 * (x & 3));
        uint8_t& b = v[row + (x >> 2)];
        if (xorMode) b ^= (uint8_t)((value & 3) << shift);
        else b = (uint8_t)((b & ~(3 << shift)) | ((value & 3) << shift));
    }
}

uint8_t CGA::getPixel(uint16_t x, uint16_t y) const {
    const uint8_t* v = mem_.video();
    if (!v || y >= 200) return 0;
    uint32_t row = (uint32_t)((y & 1) ? 0x2000 : 0) + (uint32_t)(y >> 1) * 80u;
    if (hires()) {
        if (x >= 640) return 0;
        return (uint8_t)((v[row + (x >> 3)] >> (7 - (x & 7))) & 1);
    }
    if (x >= 320) return 0;
    return (uint8_t)((v[row + (x >> 2)] >> (6 - 2 * (x & 3))) & 3);
}

void CGA::palette(uint8_t out[4]) const {
    if (hires()) {                                   // 1 bit/pixel: black + foreground from 3D9h bits 0-3
        out[0] = 0; out[1] = out[2] = out[3] = (uint8_t)(colorReg_ & 0x0F);
        return;
    }
    static const uint8_t pal0[3] = {2, 4, 6};        // green, red, brown
    static const uint8_t pal1[3] = {3, 5, 7};        // cyan, magenta, white
    static const uint8_t palBW[3] = {3, 4, 7};       // colour burst off (mode 5): cyan, red, white
    const uint8_t* p = (modeReg_ & 0x04) ? palBW : ((colorReg_ & 0x20) ? pal1 : pal0);
    uint8_t hi = (colorReg_ & 0x10) ? 8 : 0;
    out[0] = (uint8_t)(colorReg_ & 0x0F);            // background / border colour
    for (int i = 0; i < 3; i++) out[i + 1] = (uint8_t)(p[i] + hi);
}

uint8_t CGA::ioRead(uint16_t p) {
    switch (p) {
        case 0x3D4: return index_;
        case 0x3D5: return regs_[index_ & 0x1F];
        case 0x3D8: return modeReg_;
        case 0x3D9: return colorReg_;
        case 0x3DA:
            // Alternate retrace/blanking bits so code that waits for either state always terminates.
            statusToggle_++;
            return (uint8_t)(((statusToggle_ & 2) ? 0x08 : 0x00) | ((statusToggle_ & 1) ? 0x01 : 0x00));
        default: return 0xFF;
    }
}

void CGA::ioWrite(uint16_t p, uint8_t v) {
    switch (p) {
        case 0x3D4: index_ = v & 0x1F; break;
        case 0x3D5: regs_[index_ & 0x1F] = v; break;
        case 0x3D8: modeReg_ = v; break;
        case 0x3D9: colorReg_ = v; break;
        default: break;
    }
}

} // namespace Pocket86
