# Pocket86 DOS – 8086-PC-Emulator für ESP32

Bootet **FreeDOS 1.4 (Floppy Edition)** von SD-Karte. Anzeige: 480x320 TFT (TFT_eSPI), 80x25 Farbtext (CGA).

## SD-Karte (Root)
| Datei | Laufwerk | Pflicht |
|---|---|---|
| `x86BOOT.img` (1.44M-Image aus `FD14-FloppyEdition/144m`) | A: | ja (oder hd.img) |
| `x86B.img` | B: | nein |
| `hd.img` (leeres Raw-Image) | C: | wird automatisch auf der SD-Karte angelegt |

Unterstützte Floppy-Größen: 160K/180K/320K/360K/720K/1.2M/1.44M/2.88M. Festplatte: 16 Köpfe x 63 Sektoren, bis 504 MB. Beim Start wird automatisch `/hd.img` mit 64 Zylindern (ca. 31,5 MiB) erzeugt, falls die Datei noch nicht existiert. Dafür müssen mindestens ca. 32 MiB auf der SD-Karte frei sein. Dieses Image ist zunächst leer; FreeDOS kann es mit FDISK partitionieren und anschließend formatieren.

**SD-Swap (`USE_SWAP_SD 1`, Standard):** Reicht der interne RAM nicht, wird `/ram.swap` (bei 640 KB = 640 KB, bei jedem Start neu mit Nullen angelegt) als Auslagerung benutzt. `POCKET86_SWAP_SLOTS` (16) DRAM-Seiten bilden einen Cache-Pool (FIFO); alle übrigen Seiten bleiben fest im RAM. Ausgelagerte Seiten werden nur zurückgeschrieben, wenn sich ihr Inhalt geändert hat (32-Bit-Prüfsumme). Deutlich langsamer als echter RAM; Befehl `status` zeigt swap in/out.

## Bedienung
Tastatur über den Serial Monitor (115200 Baud). Pfeiltasten/F-Tasten über ANSI-Sequenzen.
**Ctrl+]** gefolgt von einer Zeile = Konsolenbefehl: `mount a /x86DSK01.img` (Diskwechsel), `mount c /hd.img`, `reset`, `status`.

## Was neu ist (gegenüber der Vorversion)
- CPU-Kern komplett neu: vollständiger 8086-Befehlssatz (plus 186-Zusatzbefehle), echtes 8086-Verhalten für CPU-Erkennung, Interrupt-Fenster nach STI/MOV SS, REP unterbrechbar.
- BIOS über Traps: alle Vektoren zeigen auf F000:1000+n, DOS kann Vektoren ersetzen und verketten.
- 8259-PIC, 8253-PIT (18,2 Hz IRQ0 in Echtzeit), BDA, Tastaturpuffer wie beim echten BIOS.
- INT 10h (Scroll, Cursor, Attribute, Teletype, Write String), INT 13h (CHS-Lesen/Schreiben, Parameter, Diskwechsel-Erkennung, Format), INT 16h, INT 1Ah.
- Farbtext statt MDA; SD-Images werden mit `r+` geöffnet (die alte Version öffnete mit "w" und hätte Images abgeschnitten).
- **RAM-Allokator (neu):** Bluetooth-Speicher wird beim Start an den Heap zurückgegeben (`esp_bt_mem_release`), danach wird der Heap in möglichst wenigen Riesenblöcken abgeräumt: erst DRAM (nur `POCKET86_HEAP_RESERVE` = 6 KB bleiben frei), dann der komplette freie IRAM (`MALLOC_CAP_EXEC`) als 32-Bit-Seiten. Der Serial-Monitor zeigt pro Stufe (PSRAM/DRAM/IRAM) die KB.
- RAM-Größe automatisch (bis 640 KB) je nach freiem Heap; bei ESP32 wird freier IRAM für ausgerichtete 32-Bit-Seiten genutzt. Für MS-DOS 2.66 werden mindestens 383 KB verlangt; zu wenig RAM → Fehlermeldung.

## Getestet (Host-Build, `host_test/`)
Auf dem PC mit den Originaldateien: Kernel-Boot, Sprachmenü mit Timeout, FDAUTO.BAT, VINFO/VECHO/VASK, Installer, FDISK (Partitionierung 32-MB-Image), Reboot über Reset-Vektor, FORMAT C: und Dateisystemtest. 0 ungültige Opcodes.
**Nicht getestet:** Lauf auf echter ESP32-Hardware (TFT, SD, Geschwindigkeit). Das Kopieren der Pakete von den weiteren Installer-Disketten ist ebenfalls nicht durchgespielt.

Der mitgelieferte Regressionstest `host_test_mouse_irq.cpp` (erwartet 1:1-Skalierung und altes Touchverhalten, daher `-DPOCKET86_PS2_SCALE_DEN=1 -DPOCKET86_TAP_MODE=0`) lässt sich im Sketch-Ordner mit `g++ -DPOCKET86_PS2_SCALE_DEN=1 -DPOCKET86_TAP_MODE=0 -std=c++17 -Wall -Wextra -Werror -O2 -I. host_test_mouse_irq.cpp BIOS.cpp CPU8086.cpp PC.cpp Memory.cpp CGA.cpp Disk.cpp OnScreenKeyboard.cpp TFTVideo.cpp -o /tmp/pocket86_mouse_test && /tmp/pocket86_mouse_test` bauen. Er prüft BIOS-POST/EBDA, INT 15h/C1h und C2h, 8042-Kommandobyte, IRQ12-Packet-/Callbackpfad, Touchmapping sowie INT 33h. Der ESP32-Sketch selbst benötigt Arduino-ESP32 und das passende TFT_eSPI-Boardsetup.

## SD-Karte / SPI
Die SD hängt wie im VideoPlayer-Sketch an einem eigenen Bus: `SPIClass sdSPI(HSPI)` mit SCK 18, MISO 19, MOSI 23, CS 5, 40 MHz (`POCKET86_SD_*` oben im Sketch änderbar; bei Lesefehlern `POCKET86_SD_FREQ 25000000`). Display und Touch laufen über TFT_eSPI (`User_Setup.h`).

## Datei-Browser (Touch)
Neben **KBD** sitzt der Button **DISK** (oder Konsolenbefehl `files`). Der Emulator pausiert, solange der Browser offen ist.
Ordner antippen = öffnen, Image antippen = auf das gewählte Laufwerk mounten (Auswahl **A: / B: / C:** oben). **Up** = Ordner hoch, **Eject** = Image aus dem gewählten Laufwerk entfernen, **Img/All** = nur Disk-Images (.img .ima .dsk .flp .vfd .bin) oder alle Dateien, **Reset** = PC neu starten (z. B. nach dem Mounten einer Boot-Diskette von A:) und Browser schließen, **X** = schließen, **< >** = blättern. Mit Image belegte Laufwerke zeigen ihr Kürzel grün hinter dem Dateinamen. Schlägt ein Mount fehl (z. B. falsche Diskettengröße), bleibt das vorherige Image eingehängt. Pfade dürfen höchstens 47 Zeichen lang sein; `ram.swap` und versteckte Dateien werden nicht angezeigt.

## Bildschirmtastatur (Touch)
Kleines **KBD**-Feld unten rechts antippen → Tastatur fährt über die untere Bildschirmhälfte (Textfenster mit 14 Zeilen folgt dem Cursor). **Hide** blendet sie wieder aus. Ebenen: QWERTY mit Shift/Ctrl/**Alt** (je ein Tastendruck, Alt+Taste = 00:Scancode, Alt+F1..F10 = 68h..71h), **Fn** = F1–F10, Bild↑/↓, Pos1/Ende/Einf/Entf und Sonderzeichen; Pfeile und Backspace wiederholen beim Halten.
Der 8042 folgt FabGLs Resetstatus (14h) und Command-Byte (67h); A7/A8 steuern AUX-Port-Bit 5, AD/AE Keyboard-Port-Bit 4. Der BIOS-IRQ12-Handler liest pro IRQ ein Byte von Port 60h, sammelt das Paket und ruft den registrierten Callback anschließend mit vier Stack-Wörtern auf. BDA:0040:000E zeigt auf eine 1-KiB-EBDA am oberen Ende des verfügbaren konventionellen Speichers; INT 15h/C1h gibt deren Segment zurück. INT 15h/C2h synchronisiert Paketlänge und registrierten ES:BX-Callback in den FabGL-kompatiblen EBDA-Feldern. Beim Loslassen bleibt die letzte Touch-Position erhalten, da TFT_eSPI dann keine gültigen Koordinaten liefert. Touch läuft über TFT_eSPI (`TOUCH_CS` etc. in der `User_Setup.h`) und imitiert eine echte PS/2-Maus am 8042-AUX-Port: Port 60h/64h, Mausbefehle, 3-Byte-Datenpakete und IRQ12 über Slave-PIC-Eingang 4 (INT 74h) werden unterstützt. Dadurch können auch Treiber wie Windows 3.0 direkt die PS/2-Maus erkennen; zusätzlich ist INT 33h implementiert. Fingerbewegungen werden auf 640x200 DOS-Mauskoordinaten abgebildet, Berühren entspricht der linken Maustaste. Beim ersten Start fragt die Kalibrierung nach (gespeichert im Flash/NVS wie beim VideoPlayer-Sketch); neu kalibrieren: Display beim Start berühren oder Konsolenbefehl `calibrate`. Eigener Touch-Code (z. B. XPT2046 auf separatem SPI): `#define POCKET86_CUSTOM_TOUCH` und `bool pocket86ReadTouch(int16_t* x, int16_t* y)` im Sketch bereitstellen (true solange gedrückt, Koordinaten 480x320 quer).

## Hinweise
- Alle Dateien müssen im Sketch-Ordner liegen. `MDA.h/.cpp` entfällt, neu sind `CGA.*`; alte Ordnerinhalte vorher löschen.
- Schreibzugriffe gehen direkt ins Image – Originale vorher sichern.
- Nicht unterstützt: EGA/VGA-Modi, Sound, XMS/EMS (8086), 386-Programme.
- **CGA-Grafik:** Modus 4/5 (320x200, 4 Farben, Palette 0/1/BW, Intensität) und Modus 6 (640x200, 1 Farbe). Umschaltung per INT 10h/00h oder direkt über Port 3D8h/3D9h; INT 10h/0Bh (Palette), 0Ch/0Dh (Pixel schreiben/lesen), Framebuffer bei B800:0000/2000 (16 KB). Ausgabe 320x200 → 480x300 (1,5x), 640x200 → 480x300 (gestaucht), es werden nur geänderte Zeilen übertragen. Bei offener Bildschirmtastatur wird das Bild oben abgeschnitten. **Kein ROM-Zeichensatz:** Text über INT 10h (Teletype/Write Char) wird im Grafikmodus nicht gezeichnet. Der Video-RAM wächst von 4 auf 16 KB, entsprechend weniger Heap bleibt für den PC-RAM.
- Host-Test: `cd host_test && g++ -std=c++11 -O2 -o p86host p86host.cpp ../Pocket86_DOS/*.cpp` (ohne `.ino`; `TFTVideo.cpp` kompiliert dort ohne TFT). Beispiel: `./p86host -a x86BOOT.img -s 40 -k '3:1' -S 30`.
- **Tastatur im CGA-/Grafikmodus:** Tasten laufen jetzt auch über den Tastaturcontroller (Port 60h, IRQ1 -> INT 9, Make- und Break-Codes). Programme/Spiele, die INT 9 selbst übernehmen oder Port 60h lesen, bekommen Eingaben; Bildschirmtasten bleiben gedrückt, solange der Finger auf der Taste liegt. Shift/Ctrl/Alt setzen zusätzlich die Flags in 0040:0017 (INT 16h/02h). Die Buttons KBD/DISK werden über dem Grafikbild neu gezeichnet.

- **Tastatur-Fix:** Großbuchstaben, Shift-Zeichen (`! @ # ... ~ |`) und Ctrl+Buchstabe senden jetzt auch über Port 60h/INT 9 die passenden Shift-/Ctrl-Make- und Break-Codes (vorher kam nur der Scancode der Grundtaste an, Programme zeigten dann z. B. `1` statt `!`). Serielle UTF-8-Umlaute (ä ö ü Ä Ö Ü ß) werden auf CP437 abgebildet.

- **Maus-Fix (Windows 3.0):** Die frühere INT-33h-Implementierung allein deckte den Windows-PS/2-Pfad nicht ab. Die IRQ12-Routine sichert jetzt wie FabGL AX/BX/CX/DS über den BIOS-Callback und stellt sie beim IRET wieder her. C201 liefert nach FabGLs tatsächlichem Code die Geräte-ID 00h in BH und lässt BL unverändert; C206 meldet die IBM/RBIL-Statusbits (aktiv, linke/rechte Taste, Auflösung, Hz). C1h/EBDA, C205/C207, 8042-AUX-Port und drei Byte pro PS/2-Paket bleiben Teil des Pfads. INT 33h bleibt als zusätzliche DOS-Schnittstelle verfügbar. Große Touch-Sprünge werden auf mehrere Pakete aufgeteilt. Die gezielte Serialdiagnose ist vorübergehend standardmäßig aktiv; in `Pocket86MouseConfig.h` `POCKET86_MOUSE_DEBUG` auf `0` setzen, um sie auszuschalten. Der gemeinsame Header ist nötig, weil Sketch und `.cpp` getrennte Übersetzungseinheiten sind. Angezeigt werden Touchquelle/Bereitschaft, Berührungswechsel, BIOS-/PS/2-Aufrufe und vollständige Pakete. Der Hosttest prüft diese Log-Verbindung; Windows auf echter ESP32-Hardware muss danach separat verifiziert werden.

- **Tippen vs. Ziehen:** Berühren bewegt nur den Zeiger. Kurzes Tippen = Linksklick, still halten (450 ms) = Taste gedrückt halten (Ziehen), erst bewegen = nur Zeiger bewegen. Einstellbar in `Pocket86MouseConfig.h` (`POCKET86_TAP_MODE`, `_TAP_SLOP_PX`, `_LONGPRESS_MS`). Test: `host_test_tap.cpp`.

- **Tastatur/Maus-Konflikt:** Port 60h liefert im IRQ1-Handler immer den Scancode, im IRQ12-Handler das Mausbyte (vorher bekam der Tastaturtreiber ggf. Mausbytes). Berührungen, die auf der Bildschirmtastatur oder den KBD/DISK-Feldern beginnen, bewegen/klicken die Maus nicht mehr.
