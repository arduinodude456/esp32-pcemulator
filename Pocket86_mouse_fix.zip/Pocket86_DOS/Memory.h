#pragma once
#include <stdint.h>
#include <stddef.h>

namespace Pocket86 {

// Abstract bus memory. The CPU only ever talks to this interface.
// A backend may additionally expose its RAM as a page table (see pageTable()).
class Memory {
public:
    virtual ~Memory() {}
    virtual uint8_t read8(uint32_t address) const = 0;
    virtual void write8(uint32_t address, uint8_t value) = 0;
    // Optional fast path: table of 256 pointers, one per 4 KiB page of the 1 MiB space
    // (nullptr entries fall back to read8/write8). A set bit 0 in an entry marks 32-bit-only memory.
    virtual uint8_t* const* pageTable() const { return nullptr; }

    uint16_t read16(uint32_t address) const {
        return (uint16_t)read8(address) | ((uint16_t)read8(address + 1u) << 8);
    }
    void write16(uint32_t address, uint16_t value) {
        write8(address, (uint8_t)value);
        write8(address + 1u, (uint8_t)(value >> 8));
    }
};

// Simple flat 1 MiB memory, used by unit tests.
class FlatMemory final : public Memory {
public:
    explicit FlatMemory(uint32_t size = 0x100000u);
    ~FlatMemory();
    uint8_t read8(uint32_t address) const override;
    void write8(uint32_t address, uint8_t value) override;
    uint32_t size() const { return size_; }
    uint8_t* data() { return data_; }
private:
    uint8_t* data_;
    uint32_t size_;
};

} // namespace Pocket86
