#include "BIOS.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

using namespace Pocket86;

static unsigned mouseLogCount = 0;
static void captureMouseLog(const char* line) {
    if (strncmp(line, "[MOUSE]", 7) == 0) ++mouseLogCount;
}

static int biosPicAck(void* context) {
    return static_cast<BIOS*>(context)->irqAck();
}

static uint16_t readStackWord(PCMemory& memory, uint16_t ss, uint16_t sp, uint16_t offset) {
    return memory.read16((((uint32_t)ss << 4) + sp + offset) & 0xFFFFFu);
}

static void deliverPacket(BIOS& bios, CPU8086& cpu, PCMemory& memory,
                          uint8_t status, uint8_t dx, uint8_t dy) {
    const uint16_t expectedAx = cpu.registers().ax, expectedBx = cpu.registers().bx;
    const uint16_t expectedCx = cpu.registers().cx, expectedDs = cpu.registers().ds;
    for (int byte = 0; byte < 3; ++byte) {
        assert(bios.irqAck() == 0x74);
        cpu.registers().cs = 0x2000;
        cpu.registers().ip = 0x0100;
        cpu.interrupt(0x74);
        assert(cpu.step()); // execute the BIOS INT 74h trap
        if (byte < 2) {
            assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0100);
        } else {
            assert(cpu.registers().cs == 0x1000 && cpu.registers().ip == 0x0100);
            uint16_t sp = cpu.registers().sp;
            assert(readStackWord(memory, 0x7000, sp, 0) == 0x1200);
            assert(readStackWord(memory, 0x7000, sp, 2) == 0xF000);
            assert(readStackWord(memory, 0x7000, sp, 4) == 0x0000);
            assert(readStackWord(memory, 0x7000, sp, 6) == dy);
            assert(readStackWord(memory, 0x7000, sp, 8) == dx);
            assert(readStackWord(memory, 0x7000, sp, 10) == status);
            for (int i = 0; i < 6; ++i) assert(cpu.step()); // clobber AX/BX/CX/DS, then guest callback RETF
            assert(cpu.registers().cs == 0xF000 && cpu.registers().ip == 0x1200);
            for (int i = 0; i < 5; ++i) assert(cpu.step()); // discard four args, restore DS/CX/BX/AX
            assert(cpu.step()); // IRET to interrupted guest
            assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0100);
            assert(cpu.registers().sp == 0x1000);
            assert(cpu.registers().ax == expectedAx && cpu.registers().bx == expectedBx);
            assert(cpu.registers().cx == expectedCx && cpu.registers().ds == expectedDs);
        }
    }
}

int main() {
    PCMemory memory;
    assert(memory.allocate(640));
    CPU8086 cpu(memory);
    CGA video(memory);
    Drives drives;
    BIOS bios(cpu, memory, video, drives);
    bios.install();
    assert(bios.trap(0x101) == CPU8086::TrapBlock); // run POST without a bootable disk

    // FabGL exposes a 1-KiB EBDA through BDA:0040:000E and INT 15h/C1h.
    uint16_t ebdaSeg = memory.read16(0x40E);
    assert(ebdaSeg == 0x9FC0);
    assert(memory.read16(0x413) == 639);
    assert(memory.read8((uint32_t)ebdaSeg << 4) == 1);
    cpu.registers().ax = 0xC000;
    cpu.registers().flags |= CPU8086::CF;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert(cpu.registers().es == CPU8086::TrapSegment && cpu.registers().bx == 0x1040);
    assert(memory.read16(0xF1040) == 16 && memory.read8(0xF1045) == 0x44);
    assert((cpu.registers().flags & CPU8086::CF) == 0);
    cpu.registers().ax = 0xC100;
    cpu.registers().flags |= CPU8086::CF;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert(cpu.registers().es == ebdaSeg && (cpu.registers().ax >> 8) == 0);
    assert((cpu.registers().flags & CPU8086::CF) == 0);

    // FabGL 8042 reset state: status SYSFLAG|INH; IRQ1/IRQ12 enabled,
    // translation enabled, AUX interface clock disabled.
    assert(bios.portRead(0x64) == 0x14);
    bios.portWrite(0x64, 0x20);
    uint8_t commandByte = bios.portRead(0x60);
    assert((commandByte & 0x67) == 0x67);

    // AD/AE control command-byte bit 4; they must not toggle IRQ1 bit 0.
    bios.portWrite(0x64, 0xAD);
    bios.portWrite(0x64, 0x20);
    commandByte = bios.portRead(0x60);
    assert((commandByte & 0x11) == 0x11);
    bios.portWrite(0x64, 0xAE);

    // A7/A8 control command-byte bit 5, not IRQ12-enable bit 1.
    bios.portWrite(0x64, 0xA8);
    bios.portWrite(0x64, 0x20);
    commandByte = bios.portRead(0x60);
    assert((commandByte & 0x22) == 0x02);
    bios.portWrite(0x64, 0xA7);
    bios.portWrite(0x64, 0x20);
    commandByte = bios.portRead(0x60);
    assert((commandByte & 0x22) == 0x22);
    bios.portWrite(0x64, 0xA8);

    // FabGL INT 15h/C201 resets the mouse and writes the standard ID to BH, leaving BL untouched.
    bios.setLogger(captureMouseLog);
    cpu.registers().ax = 0xC201;
    cpu.registers().bx = 0x1234;
    cpu.registers().flags |= CPU8086::CF;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert(cpu.registers().bx == 0x0034);
    assert((cpu.registers().ax >> 8) == 0 && (cpu.registers().flags & CPU8086::CF) == 0);
    assert(mouseLogCount == 1);

    // Exercise the real guest INT 15h entry/trap/IRET path as well as direct BIOS dispatch.
    memory.write8(0x20100, 0xB8); memory.write16(0x20101, 0xC201); // MOV AX,C201h
    memory.write8(0x20103, 0xCD); memory.write8(0x20104, 0x15);   // INT 15h
    cpu.registers().cs = 0x2000; cpu.registers().ip = 0x0100;
    cpu.registers().ss = 0x7000; cpu.registers().sp = 0x1000;
    cpu.registers().bx = 0x1234; cpu.registers().flags |= CPU8086::CF;
    assert(cpu.step()); assert(cpu.step()); assert(cpu.step());
    assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0105);
    assert(cpu.registers().ax == 0x0001 && cpu.registers().bx == 0x0034);
    assert((cpu.registers().flags & CPU8086::CF) == 0 && mouseLogCount == 2);

    // IBM/RBIL C206 status: bit 5 enabled, bit 2 left, bit 0 right;
    // CL=2 means 4 counts/mm and DL=100 reports/s after reset.
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    cpu.registers().cx = cpu.registers().dx = 0xFFFF;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert((cpu.registers().bx & 0xFF) == 0 && (cpu.registers().cx & 0xFF) == 2 && (cpu.registers().dx & 0xFF) == 100);
    assert((cpu.registers().flags & CPU8086::CF) == 0);
    cpu.registers().ax = 0xC202; cpu.registers().bx = 0x0600;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    cpu.registers().ax = 0xC203; cpu.registers().bx = 0x0300;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert((cpu.registers().cx & 0xFF) == 3 && (cpu.registers().dx & 0xFF) == 200);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0200;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().bx & 0x10));
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0100;
    assert(bios.trap(0x15) == CPU8086::TrapReturn); // restore 1:1

    // Exercise the device-side PS/2 parameter handshake through 8042 command 0xD4.
    bios.portWrite(0x64, 0xD4); bios.portWrite(0x60, 0xF3);
    assert((bios.portRead(0x64) & 0x21) == 0x21 && bios.portRead(0x60) == 0xFA);
    bios.portWrite(0x64, 0xD4); bios.portWrite(0x60, 0xC8);
    assert((bios.portRead(0x64) & 0x21) == 0x21 && bios.portRead(0x60) == 0xFA);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().dx & 0xFF) == 200);
    bios.portWrite(0x64, 0xD4); bios.portWrite(0x60, 0xE8);
    assert((bios.portRead(0x64) & 0x21) == 0x21 && bios.portRead(0x60) == 0xFA);
    bios.portWrite(0x64, 0xD4); bios.portWrite(0x60, 0x03);
    assert((bios.portRead(0x64) & 0x21) == 0x21 && bios.portRead(0x60) == 0xFA);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().cx & 0xFF) == 3);
    // Restore documented defaults before the callback/packet path.
    bios.portWrite(0x64, 0xD4); bios.portWrite(0x60, 0xF6);
    assert((bios.portRead(0x64) & 0x21) == 0x21 && bios.portRead(0x60) == 0xFA);

    // Enable device reporting, then drain its AUX ACK before sending touch data.
    bios.portWrite(0x64, 0xD4);
    bios.portWrite(0x60, 0xF4);
    assert((bios.portRead(0x64) & 0x21) == 0x21); // OBF + AUX source
    (void)bios.portRead(0x60);

    // FabGL C205 takes packet length from the connected mouse, and disables only the port.
    cpu.registers().ax = 0xC205;
    cpu.registers().bx = 0x0400;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    uint32_t ebda = (uint32_t)ebdaSeg << 4;
    assert(memory.read16(ebda + 0x22) == 0 && memory.read16(ebda + 0x24) == 0);
    assert(memory.read8(ebda + 0x26) == 0 && memory.read8(ebda + 0x27) == 3);
    bios.portWrite(0x64, 0xA8);

    // Register a guest far callback through INT 15h/C207h.
    cpu.registers().ax = 0xC207;
    cpu.registers().es = 0x1000;
    cpu.registers().bx = 0x0100;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert(memory.read16(ebda + 0x22) == 0x0100 && memory.read16(ebda + 0x24) == 0x1000);
    assert(memory.read8(ebda + 0x27) == 0x83);
    cpu.registers().ax = 0xC200;
    cpu.registers().bx = 0x0100;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    assert((bios.portRead(0x64) & 0x01) == 0); // no output byte is pending
    bios.portWrite(0x64, 0x20);
    assert((bios.portRead(0x60) & 0x22) == 0x02); // IRQ12 enabled, AUX port clock enabled
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().bx & 0xFF) == 0x20);
    // The driver callback deliberately clobbers the registers that FabGL's
    // IRQ74 wrapper saves; its IRET path must restore the interrupted state.
    const uint8_t clobberCallback[] = { 0xB8,0x34,0x12, 0xBB,0x78,0x56, 0xB9,0xBC,0x9A,
                                        0xB8,0xF0,0xDE, 0x8E,0xD8, 0xCB };
    for (unsigned i = 0; i < sizeof(clobberCallback); ++i) memory.write8(0x10100 + i, clobberCallback[i]);
    memory.write16(0x74 * 4, (uint16_t)(CPU8086::TrapBase + 0x74));
    memory.write16(0x74 * 4 + 2, CPU8086::TrapSegment);

    cpu.registers().ss = 0x7000;
    cpu.registers().sp = 0x1000;
    cpu.registers().flags |= CPU8086::IF;
    cpu.registers().ax = 0x1111; cpu.registers().bx = 0x2222;
    cpu.registers().cx = 0x3333; cpu.registers().ds = 0x4444;

    // Press at the right edge -> the 639-pixel jump is split into 127-count packets (5 x 127 + 4).
    bios.mouseTouch(479, 0, true);
    for (int i = 0; i < 5; i++) deliverPacket(bios, cpu, memory, 0x09, 0x7F, 0x00);
    deliverPacket(bios, cpu, memory, 0x09, 0x04, 0x00);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().bx & 0xFF) == 0x24);
    // On release readTouch has no coordinates; it must not teleport the pointer to 0,0.
    bios.mouseTouch(0, 0, false);
    deliverPacket(bios, cpu, memory, 0x08, 0x00, 0x00);
    cpu.registers().ax = 0xC206; cpu.registers().bx = 0x0000;
    assert(bios.trap(0x15) == CPU8086::TrapReturn && (cpu.registers().bx & 0xFF) == 0x20);
    assert(bios.irqAck() == -1);
    assert(memory.read8(ebda + 0x28) == 0x08);
    assert(memory.read8(ebda + 0x29) == 0x00 && memory.read8(ebda + 0x2A) == 0x00);

    // Callback return stub must discard packet args, restore saved registers, then IRET.
    assert(memory.read8(0xF1200) == 0x81);
    assert(memory.read8(0xF1201) == 0xC4);
    assert(memory.read8(0xF1202) == 0x08);
    assert(memory.read8(0xF1203) == 0x00);
    assert(memory.read8(0xF1204) == 0x1F && memory.read8(0xF1205) == 0x59);
    assert(memory.read8(0xF1206) == 0x5B && memory.read8(0xF1207) == 0x58);
    assert(memory.read8(0xF1208) == 0xCF);

    assert(memory.read8(0xF1033) != 0xCF);              // INT 33h entry must not look like a bare IRET
    // INT 33h: function number is the whole AX (AX=0003h must not be treated as reset).
    cpu.registers().ax = 0x0000; assert(bios.trap(0x33) == CPU8086::TrapReturn);
    assert(cpu.registers().ax == 0xFFFF && cpu.registers().bx == 2);
    cpu.registers().ax = 0x0003; assert(bios.trap(0x33) == CPU8086::TrapReturn);
    assert(cpu.registers().cx == 320 && cpu.registers().dx == 100 && cpu.registers().bx == 0);

    // Additional DOS INT 33h user-handler path: install via AX=000Ch.
    memory.write8(0x10200, 0xCB);                       // handler: RETF
    cpu.registers().ax = 0x000C; cpu.registers().cx = 0x001F; cpu.registers().es = 0x1000; cpu.registers().dx = 0x0200;
    assert(bios.trap(0x33) == CPU8086::TrapReturn);
    bios.mouseTouch(240, 160, true);                    // move + left press
    assert(bios.irqAck() == 0x74);
    cpu.registers().cs = 0x2000; cpu.registers().ip = 0x0100;
    cpu.registers().ax = 0x1111; cpu.registers().si = 0x2222;
    cpu.interrupt(0x74);
    assert(cpu.step());
    assert(cpu.registers().cs == 0x1000 && cpu.registers().ip == 0x0200);
    assert(cpu.registers().ax == 0x0003 && cpu.registers().bx == 1);
    assert(cpu.registers().cx == 320 && cpu.registers().dx == 106);
    assert(cpu.step());                                 // RETF -> F000:1210
    for (int i = 0; i < 3; i++) assert(cpu.step());     // POP ES, POP DS, POPA
    assert(cpu.step());                                 // IRET
    assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0100);
    assert(cpu.registers().ax == 0x1111 && cpu.registers().si == 0x2222);

    // CPU IF must gate a pending hardware IRQ12; STI/IF-enabled polling then enters INT 74h.
    bios.install();
    assert(bios.trap(0x101) == CPU8086::TrapBlock);
    cpu.registers().ax = 0xC200;
    cpu.registers().bx = 0x0100;
    assert(bios.trap(0x15) == CPU8086::TrapReturn);
    memory.write8(0x20100, 0x90);                         // NOP at the interrupted guest address
    cpu.registers().cs = 0x2000; cpu.registers().ip = 0x0100;
    cpu.registers().ss = 0x7000; cpu.registers().sp = 0x1000;
    cpu.registers().flags = 0xF002;                     // IF clear
    cpu.setIrqAck(biosPicAck, &bios);
    bios.mouseTouch(20, 20, true);
    assert(cpu.step());
    assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0101); // IRQ masked
    cpu.registers().flags |= CPU8086::IF;
    for (int byte = 0; byte < 3; ++byte) {
        assert(cpu.step());
        assert(cpu.registers().cs == CPU8086::TrapSegment && cpu.registers().ip == CPU8086::TrapBase + 0x74);
        assert(cpu.step());                                 // execute IRQ12 BIOS trap, consume one AUX byte
        assert(cpu.registers().cs == 0x2000 && cpu.registers().ip == 0x0101);
        assert((cpu.registers().flags & CPU8086::IF) != 0);
    }
    assert(bios.irqAck() == -1);                             // no stuck/re-triggered slave-PIC request
    assert(memory.read8(ebda + 0x26) == 0);                 // complete packet, no partial-byte residue
    puts("8042/PIC/INT74 press-release guest callback regression: PASS");
    return 0;
}
