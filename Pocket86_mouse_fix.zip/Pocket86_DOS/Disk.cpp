#include "Disk.h"
#include <string.h>

namespace Pocket86 {

namespace {
struct FloppyFormat { uint32_t bytes; uint16_t cyl; uint8_t heads, spt, type; };
const FloppyFormat kFormats[] = {
    {  163840UL, 40, 1,  8, 1 },   // 160K
    {  184320UL, 40, 1,  9, 1 },   // 180K
    {  327680UL, 40, 2,  8, 1 },   // 320K
    {  368640UL, 40, 2,  9, 1 },   // 360K
    {  737280UL, 80, 2,  9, 3 },   // 720K
    { 1228800UL, 80, 2, 15, 2 },   // 1.2M
    { 1474560UL, 80, 2, 18, 4 },   // 1.44M
    { 2949120UL, 80, 2, 36, 6 },   // 2.88M
};
}

DiskImage::DiskImage()
    : present_(false), floppy_(true), writable_(false), changed_(false), sectors_(0),
      cyl_(0), heads_(0), spt_(0), type_(0), path_{}
#ifdef ARDUINO
      , file_()
#else
      , file_(nullptr)
#endif
{}

DiskImage::~DiskImage() { close(); }

void DiskImage::close() {
#ifdef ARDUINO
    if (file_) file_.close();
#else
    if (file_) { fclose(file_); file_ = nullptr; }
#endif
    present_ = false;
    sectors_ = 0;
}

bool DiskImage::open(const char* path, bool floppy) {
    close();
    strncpy(path_, path, sizeof(path_) - 1);
    path_[sizeof(path_) - 1] = 0;
    floppy_ = floppy;
    writable_ = true;
    uint32_t bytes = 0;
#ifdef ARDUINO
    file_ = SD.open(path_, "r+");              // read/write, never truncates
    if (!file_) { writable_ = false; file_ = SD.open(path_, FILE_READ); }
    if (!file_) return false;
    bytes = (uint32_t)file_.size();
#else
    file_ = fopen(path_, "r+b");
    if (!file_) { writable_ = false; file_ = fopen(path_, "rb"); }
    if (!file_) return false;
    fseek(file_, 0, SEEK_END);
    bytes = (uint32_t)ftell(file_);
#endif
    if (bytes < 512) { close(); return false; }

    if (floppy_) {
        bool found = false;
        for (unsigned i = 0; i < sizeof(kFormats) / sizeof(kFormats[0]); i++) {
            if (kFormats[i].bytes == bytes) {
                cyl_ = kFormats[i].cyl; heads_ = kFormats[i].heads; spt_ = kFormats[i].spt; type_ = kFormats[i].type;
                found = true; break;
            }
        }
        if (!found) { close(); return false; }
    } else {
        heads_ = 16; spt_ = 63; type_ = 0;
        uint32_t c = bytes / (512UL * heads_ * spt_);
        if (c < 1) c = 1;
        if (c > 1024) c = 1024;
        cyl_ = (uint16_t)c;
    }
    sectors_ = bytes / 512UL;
    present_ = true;
    changed_ = true;
    return true;
}

bool DiskImage::read(uint32_t lba, uint8_t* b) {
    if (!present_ || lba >= sectors_) return false;
#ifdef ARDUINO
    if (!file_.seek((uint32_t)(lba * 512UL))) return false;
    return file_.read(b, 512) == 512;
#else
    if (fseek(file_, (long)(lba * 512UL), SEEK_SET) != 0) return false;
    return fread(b, 1, 512, file_) == 512;
#endif
}

bool DiskImage::write(uint32_t lba, const uint8_t* b) {
    if (!present_ || !writable_ || lba >= sectors_) return false;
#ifdef ARDUINO
    if (!file_.seek((uint32_t)(lba * 512UL))) return false;
    bool ok = file_.write(b, 512) == 512;
    file_.flush();
    return ok;
#else
    if (fseek(file_, (long)(lba * 512UL), SEEK_SET) != 0) return false;
    bool ok = fwrite(b, 1, 512, file_) == 512;
    fflush(file_);
    return ok;
#endif
}

} // namespace Pocket86
