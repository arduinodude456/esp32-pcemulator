#include "OnScreenKeyboard.h"
#include <string.h>

#ifdef ARDUINO
#include <Arduino.h>
//#include <Preferences.h>

namespace Pocket86 {

namespace {
const int16_t kTop = 140;          // keyboard occupies y = 140..319
const int16_t kRowH = 36;
const int16_t kUnit = 32;          // 15 units = 480 px

enum Kind : uint8_t { K_CHAR, K_ASCII, K_SCAN, K_SHIFT, K_CTRL, K_ALT, K_FN, K_HIDE };

#define C(ch) { ch, K_CHAR, (uint8_t)ch[0], 1 }
#define A(label, code, u) { label, K_ASCII, code, u }
#define S(label, code, u) { label, K_SCAN, code, u }

// ---- main layer
typedef OnScreenKeyboard::Key KeyT;
const KeyT mainRow0[] = { A("Esc", 0x1B, 1), C("1"), C("2"), C("3"), C("4"), C("5"), C("6"), C("7"), C("8"), C("9"), C("0"), C("-"), C("="), A("Bksp", 0x08, 2) };
const KeyT mainRow1[] = { A("Tab", 0x09, 2), C("q"), C("w"), C("e"), C("r"), C("t"), C("y"), C("u"), C("i"), C("o"), C("p"), C("["), C("]"), C("\\") };
const KeyT mainRow2[] = { { "Ctrl", K_CTRL, 0, 2 }, C("a"), C("s"), C("d"), C("f"), C("g"), C("h"), C("j"), C("k"), C("l"), C(";"), C("'"), A("Enter", 0x0D, 2) };
const KeyT mainRow3[] = { { "Shift", K_SHIFT, 0, 2 }, C("z"), C("x"), C("c"), C("v"), C("b"), C("n"), C("m"), C(","), C("."), C("/"), S("Up", 0x48, 1), S("Del", 0x53, 2) };
const KeyT mainRow4[] = { { "Fn", K_FN, 0, 2 }, { "Alt", K_ALT, 0, 2 }, { " ", K_CHAR, ' ', 6 }, S("Lt", 0x4B, 1), S("Dn", 0x50, 1), S("Rt", 0x4D, 1), { "Hide", K_HIDE, 0, 2 } };
// ---- Fn layer (rows 3 and 4 are shared with the main layer)
const KeyT fnRow0[] = { A("Esc", 0x1B, 1), S("F1", 0x3B, 1), S("F2", 0x3C, 1), S("F3", 0x3D, 1), S("F4", 0x3E, 1), S("F5", 0x3F, 1), S("F6", 0x40, 1), S("F7", 0x41, 1), S("F8", 0x42, 1), S("F9", 0x43, 1), S("F10", 0x44, 1), S("PgUp", 0x49, 2), S("PgDn", 0x51, 2) };
const KeyT fnRow1[] = { C("`"), C("~"), C("!"), C("@"), C("#"), C("$"), C("%"), C("^"), C("&"), C("*"), C("("), C(")"), C("_"), C("+"), S("Ins", 0x52, 1) };
const KeyT fnRow2[] = { S("Home", 0x47, 2), C("["), C("]"), C("{"), C("}"), C("|"), C(":"), C("\""), C("<"), C(">"), C("?"), S("Del", 0x53, 1), S("End", 0x4F, 2) };

#undef C
#undef A
#undef S

// character after Shift on a US layout
uint8_t shifted(uint8_t c) {
    if (c >= 'a' && c <= 'z') return (uint8_t)(c - 32);
    static const char from[] = "1234567890-=[]\\;',./`";
    static const char to[]   = "!@#$%^&*()_+{}|:\"<>?~";
    for (int i = 0; from[i]; i++) if ((uint8_t)from[i] == c) return (uint8_t)to[i];
    return c;
}
}

OnScreenKeyboard::OnScreenKeyboard(TFTVideo& video, BIOS& bios)
    : video_(video), bios_(bios), visible_(false), touchOk_(false), down_(false), fnLayer_(false), shift_(false), ctrl_(false), alt_(false),
      pressedRow_(0), pressedIdx_(0), hasPressed_(false), lastPoll_(0), repeatAt_(0), diskHandler_(nullptr) {}

const OnScreenKeyboard::Key* OnScreenKeyboard::rowKeys(uint8_t row, uint8_t& count) const {
    switch (row) {
        case 0: if (fnLayer_) { count = sizeof(fnRow0) / sizeof(KeyT); return fnRow0; } count = sizeof(mainRow0) / sizeof(KeyT); return mainRow0;
        case 1: if (fnLayer_) { count = sizeof(fnRow1) / sizeof(KeyT); return fnRow1; } count = sizeof(mainRow1) / sizeof(KeyT); return mainRow1;
        case 2: if (fnLayer_) { count = sizeof(fnRow2) / sizeof(KeyT); return fnRow2; } count = sizeof(mainRow2) / sizeof(KeyT); return mainRow2;
        case 3: count = sizeof(mainRow3) / sizeof(KeyT); return mainRow3;
        default: count = sizeof(mainRow4) / sizeof(KeyT); return mainRow4;
    }
}

// ---------------------------------------------------------------- touch

bool OnScreenKeyboard::readTouch(int16_t& x, int16_t& y) {
#if defined(POCKET86_CUSTOM_TOUCH)
    extern bool pocket86ReadTouch(int16_t* x, int16_t* y);
    return pocket86ReadTouch(&x, &y);
#elif defined(TOUCH_CS)
    uint16_t tx = 0, ty = 0;
    if (!video_.tft().getTouch(&tx, &ty)) return false;
    x = (int16_t)tx; y = (int16_t)ty;
    return true;
#else
    (void)x; (void)y;
    return false;
#endif
}

void OnScreenKeyboard::calibrate() {
#if defined(TOUCH_CS) && !defined(POCKET86_CUSTOM_TOUCH)
    uint16_t cal[5];

    video_.tft().fillScreen(TFT_BLACK);
    video_.tft().calibrateTouch(
        cal, TFT_MAGENTA, TFT_BLACK, 15
    );
    video_.tft().setTouch(cal);

    video_.tft().fillScreen(TFT_BLACK);
    video_.invalidate();
#endif
}

void OnScreenKeyboard::begin() {
#if defined(POCKET86_CUSTOM_TOUCH)
    touchOk_ = true;
#elif defined(TOUCH_CS)
    calibrate();
    touchOk_ = true;
#else
    touchOk_ = false;
#endif

#if POCKET86_MOUSE_DEBUG
    Serial.printf("[TOUCH] source=%s ready=%u\n",
#if defined(POCKET86_CUSTOM_TOUCH)
                  "custom",
#elif defined(TOUCH_CS)
                  "TFT_eSPI",
#else
                  "none",
#endif
                  (unsigned)touchOk_);
#endif

    video_.setOverlay(&OnScreenKeyboard::overlayThunk, this);
    if (touchOk_) drawHandle();
}

void OnScreenKeyboard::overlayThunk(void* self) {
    OnScreenKeyboard* k = static_cast<OnScreenKeyboard*>(self);
    if (!k->visible_ && k->touchOk_) k->drawHandle();
}

// ---------------------------------------------------------------- layout / drawing

void OnScreenKeyboard::keyRect(uint8_t row, uint8_t idx, int16_t& x, int16_t& y, int16_t& w, int16_t& h) const {
    uint8_t n; const Key* keys = rowKeys(row, n);
    int16_t ux = 0;
    for (uint8_t i = 0; i < idx; i++) ux += keys[i].units;
    x = ux * kUnit; w = keys[idx].units * kUnit;
    // the last key of a short row stretches to the screen edge
    if (idx == n - 1) w = 480 - x;
    y = kTop + row * kRowH; h = kRowH;
}

bool OnScreenKeyboard::hit(int16_t px, int16_t py, uint8_t& row, uint8_t& idx) const {
    if (py < kTop || py >= kTop + kRows * kRowH) return false;
    row = (uint8_t)((py - kTop) / kRowH);
    uint8_t n; rowKeys(row, n);
    for (uint8_t i = 0; i < n; i++) {
        int16_t x, y, w, h; keyRect(row, i, x, y, w, h);
        if (px >= x && px < x + w) { idx = i; return true; }
    }
    return false;
}

void OnScreenKeyboard::drawKey(uint8_t row, uint8_t idx, bool pressed) {
    uint8_t n; const Key* keys = rowKeys(row, n);
    const Key& k = keys[idx];
    int16_t x, y, w, h; keyRect(row, idx, x, y, w, h);
    TFT_eSPI& t = video_.tft();
    bool active = (k.kind == K_SHIFT && shift_) || (k.kind == K_CTRL && ctrl_) || (k.kind == K_ALT && alt_) || (k.kind == K_FN && fnLayer_);
    uint16_t bg = pressed ? TFT_WHITE : (active ? t.color565(30, 90, 200) : t.color565(48, 52, 60));
    uint16_t fg = pressed ? TFT_BLACK : TFT_WHITE;
    t.fillRoundRect(x + 1, y + 1, w - 2, h - 2, 4, bg);
    char lab[8];
    strncpy(lab, k.label, sizeof(lab) - 1); lab[sizeof(lab) - 1] = 0;
    if (k.kind == K_CHAR && k.code != ' ') { lab[0] = (char)(shift_ ? shifted(k.code) : k.code); lab[1] = 0; }
    if (k.kind == K_CHAR && k.code == ' ') { strcpy(lab, "space"); }
    uint8_t len = (uint8_t)strlen(lab);
    t.setTextColor(fg, bg);
    t.setTextDatum(MC_DATUM);
    t.setTextSize(len <= 1 ? 2 : 1);
    t.drawString(lab, x + w / 2, y + h / 2, 1);
    t.setTextDatum(TL_DATUM);
    t.setTextSize(1);
}

void OnScreenKeyboard::drawAll() {
    video_.tft().fillRect(0, kTop, 480, 320 - kTop, TFT_BLACK);
    for (uint8_t r = 0; r < kRows; r++) {
        uint8_t n; rowKeys(r, n);
        for (uint8_t i = 0; i < n; i++) drawKey(r, i, false);
    }
}

void OnScreenKeyboard::drawHandle() {
    TFT_eSPI& t = video_.tft();
    const uint16_t bg = t.color565(48, 52, 60);
    t.setTextColor(TFT_WHITE, bg);
    t.setTextDatum(MC_DATUM);
    t.setTextSize(1);
    t.fillRoundRect(412, 290, 66, 28, 6, bg);
    t.drawString("KBD  ^", 445, 304, 1);
    if (diskHandler_) {
        t.fillRoundRect(340, 290, 66, 28, 6, bg);
        t.drawString("DISK", 373, 304, 1);
    }
    t.setTextDatum(TL_DATUM);
}

void OnScreenKeyboard::redraw() {
    if (visible_) drawAll();
    else if (touchOk_) drawHandle();
}

void OnScreenKeyboard::show(bool on) {
    if (on == visible_) return;
    visible_ = on;
    bios_.keyRelease();
    if (on) {
        video_.setVisibleRows(14);
        drawAll();
    } else {
        video_.setVisibleRows(25);       // clears the keyboard area and redraws the status lines
        video_.update();
        if (touchOk_) drawHandle();
    }
}

// ---------------------------------------------------------------- key handling

void OnScreenKeyboard::sendChar(uint8_t c) {
    if (ctrl_) {
        if (c >= 'a' && c <= 'z') c = (uint8_t)(c - 'a' + 1);
        else if (c >= 'A' && c <= 'Z') c = (uint8_t)(c - 'A' + 1);
        else if (c == '[') c = 0x1B;
        else if (c == '\\') c = 0x1C;
        bios_.pushAscii(c);
    } else {
        bios_.pushAscii(shift_ ? shifted(c) : c);
    }
}

void OnScreenKeyboard::syncMods() { bios_.setModifiers(shift_, ctrl_, alt_); }

void OnScreenKeyboard::fire(const Key& k) {
    bool oneShotDone = true;
    switch (k.kind) {
        case K_CHAR:  if (alt_) bios_.pushAlt(k.code); else sendChar(k.code); break;
        case K_ASCII: if (alt_) bios_.pushAlt(k.code); else bios_.pushAscii(k.code); break;
        case K_SCAN:  if (alt_) bios_.pushAltScan(k.code); else bios_.pushScan(k.code); break;
        case K_SHIFT: shift_ = !shift_; oneShotDone = false; drawAll(); syncMods(); break;
        case K_CTRL:  ctrl_ = !ctrl_;   oneShotDone = false; drawAll(); syncMods(); break;
        case K_ALT:   alt_ = !alt_;     oneShotDone = false; drawAll(); syncMods(); break;
        case K_FN:    fnLayer_ = !fnLayer_; oneShotDone = false; drawAll(); break;
        case K_HIDE:  show(false); return;
    }
    if (oneShotDone && (shift_ || ctrl_ || alt_)) { shift_ = false; ctrl_ = false; alt_ = false; drawAll(); syncMods(); }
}

void OnScreenKeyboard::poll() {
    if (!touchOk_) return;
    uint32_t now = millis();
    if (now - lastPoll_ < 25) return;
    lastPoll_ = now;

    int16_t x = 0, y = 0;
    bool touched = readTouch(x, y);
#if POCKET86_MOUSE_DEBUG
    if (touched != down_)
        Serial.printf("[TOUCH] %s raw=%d,%d\n", touched ? "down" : "up", (int)x, (int)y);
#endif
    // A touch that starts on the on-screen keyboard or the KBD/DISK handles is a UI touch: it must not move or click the mouse.
    if (touched && !prevTouched_) uiTouch_ = (visible_ && y >= kTop) || (!visible_ && y >= 280 && x >= 330);
    if (!touched) uiTouch_ = false;
    prevTouched_ = touched;
    bios_.mouseTouch(x, y, touched && !uiTouch_);

    if (!visible_) {
        if (touched && !down_ && y >= 280) {
            if (x >= 400) show(true);
            else if (x >= 330 && diskHandler_) { down_ = true; diskHandler_(); return; }
        }
        down_ = touched;
        return;
    }
    if (touched) {
        if (!down_) {
            down_ = true;
            uint8_t r, i;
            if (hit(x, y, r, i)) {
                uint8_t n; const Key* keys = rowKeys(r, n);
                hasPressed_ = true; pressedRow_ = r; pressedIdx_ = i;
                drawKey(r, i, true);
                Key k = keys[i];
                fire(k);
                if (k.kind == K_CHAR || k.kind == K_ASCII || k.kind == K_SCAN) bios_.keyHold(true);   // key stays down until the finger lifts
                repeatAt_ = now + 450;
            }
        } else if (hasPressed_ && now >= repeatAt_) {
            uint8_t n; const Key* keys = rowKeys(pressedRow_, n);
            const Key& k = keys[pressedIdx_];
            bool repeatable = (k.kind == K_SCAN) || (k.kind == K_ASCII && k.code == 0x08);
            if (repeatable) { Key kk = k; fire(kk); repeatAt_ = now + 90; }
        }
    } else if (down_) {
        down_ = false;
        bios_.keyRelease();
        if (hasPressed_ && visible_) drawKey(pressedRow_, pressedIdx_, false);
        hasPressed_ = false;
    }
}

} // namespace Pocket86

#else   // host build: the keyboard needs the TFT, nothing to do
namespace Pocket86 {
OnScreenKeyboard::OnScreenKeyboard(TFTVideo& v, BIOS& b) : video_(v), bios_(b), visible_(false), touchOk_(false), down_(false), fnLayer_(false), shift_(false), ctrl_(false), alt_(false), pressedRow_(0), pressedIdx_(0), hasPressed_(false), lastPoll_(0), repeatAt_(0), diskHandler_(nullptr) {}
void OnScreenKeyboard::begin() {}
void OnScreenKeyboard::calibrate() {}
void OnScreenKeyboard::poll() {}
void OnScreenKeyboard::redraw() {}
void OnScreenKeyboard::show(bool) {}
}
#endif
