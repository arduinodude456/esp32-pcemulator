#pragma once
#include "CGA.h"
#include <stdint.h>
#ifdef ARDUINO
#include <TFT_eSPI.h>
#endif

namespace Pocket86 {

// Renders the 80x25 colour text screen on a 480x320 TFT: 6x8 glyphs in 6x10 cells (480x250),
// the area below holds two status lines. With the on-screen keyboard open only a window of
// 14 text rows (following the cursor) is shown above the keyboard.
class TFTVideo {
public:
    explicit TFTVideo(CGA& cga);
    void begin();
    void update();                                    // redraws changed cells only
    void status(const char* text, uint8_t line = 0);  // status line 0/1 (max ~80 chars)
    void setVisibleRows(uint8_t rows);                // 25 = full screen, 14 = above the keyboard
    void refreshAll();                                // clear the whole TFT and redraw text + status (after a full-screen overlay)
    typedef void (*Overlay)(void*);
    void setOverlay(Overlay fn, void* ctx) { overlay_ = fn; overlayCtx_ = ctx; }   // redrawn on top of the CGA graphics image (KBD/DISK handles)
    void invalidate() { viewDirty_ = true; }          // force a full redraw (after touching the TFT directly)
#ifdef ARDUINO
    TFT_eSPI& tft() { return tft_; }
#endif
private:
    CGA& cga_;
    uint8_t shadow_[4000];
    uint16_t lastCursor_;
    bool lastCursorOn_, initialized_, viewDirty_;
    uint16_t lastStart_;
    uint8_t visibleRows_, firstRow_, lastFirstRow_;
    bool gfxActive_;
    Overlay overlay_;
    void* overlayCtx_;
    uint8_t lastMode_, lastColor_;
    uint32_t rowHash_[200];                           // per-scanline checksum of the CGA frame buffer
    char statusText_[2][96];
#ifdef ARDUINO
    TFT_eSPI tft_;
    uint16_t palette_[16];
#endif
    void drawCell(uint16_t index, bool cursor);
    void updateGraphics();                            // CGA 320x200x4 / 640x200x2, scaled to 480x300
    void drawStatus(uint8_t line);
};

} // namespace Pocket86
