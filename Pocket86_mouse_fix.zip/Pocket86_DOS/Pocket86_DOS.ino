// Pocket86 DOS - 8086 PC emulator for ESP32 + 480x320 TFT (TFT_eSPI) + SD card.
// Boots FreeDOS (or any DOS) from raw disk images on the SD card:
//   /x86BOOT.img   floppy A:   (required unless /hd.img exists)
//   /x86B.img      floppy B:   (optional)
//   /hd.img        hard disk C: (optional, raw image, 16 heads x 63 sectors/track)
// Keyboard: type into the Arduino serial monitor (115200 baud). Arrow keys / F-keys work with
// ANSI escape sequences (most terminal programs). Console commands: press Ctrl+] then type a line:
//   mount a /x86DSK01.img    swap floppy A: (also b)    mount c /hd.img   attach hard disk
//   reset                    cold reboot                 status            print info
//   calibrate                redo touch calibration      kbd               toggle on-screen keyboard
//   files                    open the touch file browser (same as the DISK button)
// Touch: tap the small KBD handle (bottom right) to open the on-screen keyboard, DISK (left of it) to open the file browser.
#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include <esp_heap_caps.h>
#include "sdkconfig.h"
#if defined(CONFIG_BT_ENABLED)
#include "esp_bt.h"
#endif
#include "CPU8086.h"
#include "PC.h"
#include "CGA.h"
#include "Disk.h"
#include "BIOS.h"
#include "TFTVideo.h"
#include "OnScreenKeyboard.h"
#include "FileBrowser.h"

// SD card on its own SPI bus (HSPI instance on pins 18/19/23), separate from the TFT/touch bus.
// Same wiring as the VideoPlayer sketch. Lower POCKET86_SD_FREQ to 25000000 on read errors.
#ifndef POCKET86_SD_CS
#define POCKET86_SD_CS   5
#endif
#ifndef POCKET86_SD_SCK
#define POCKET86_SD_SCK  18
#endif
#ifndef POCKET86_SD_MISO
#define POCKET86_SD_MISO 19
#endif
#ifndef POCKET86_SD_MOSI
#define POCKET86_SD_MOSI 23
#endif
#ifndef POCKET86_SD_FREQ
#define POCKET86_SD_FREQ 80000000  // try 80 MHz; use 40000000 for long wires or read errors
#endif
#ifndef POCKET86_RAM_KB
#define POCKET86_RAM_KB 640        // maximum emulated RAM; less is used if the heap is smaller
#endif
#ifndef POCKET86_AUTO_CREATE_HD
#define POCKET86_AUTO_CREATE_HD 1  // create /hd.img on the SD card when absent
#endif
#ifndef USE_SWAP_SD
#define USE_SWAP_SD 1              // 1 = missing RAM pages live in /ram.swap on the SD card (paged through a DRAM cache pool)
#endif
#ifndef POCKET86_HD_CYLINDERS
#define POCKET86_HD_CYLINDERS 64  // aligned CHS image: 16 heads x 63 sectors/track
#endif
#ifndef POCKET86_HEAP_RESERVE
#define POCKET86_HEAP_RESERVE (1UL * 64)    // DRAM kept free for SD, TFT, serial and stacks (was 20 KB; raise if you see resets)
#endif
#ifndef POCKET86_MIN_RAM_KB
#define POCKET86_MIN_RAM_KB 383    // minimum emulated RAM to start; without PSRAM an ESP32 reaches only ~250 KB, so lower this (e.g. 192) to boot anyway
#endif
#ifndef POCKET86_BL_PIN
#define POCKET86_BL_PIN -1         // backlight GPIO if TFT_eSPI does not drive it (CYD 3.5": 27)
#endif
#ifndef POCKET86_DEBUG
#define POCKET86_DEBUG 1
#endif

using namespace Pocket86;

SPIClass sdSPI(HSPI);
PCMemory pcMemory;
CGA cga(pcMemory);
Drives drives;
CPU8086 cpu(pcMemory);
BIOS bios(cpu, pcMemory, cga, drives);
TFTVideo display(cga);
OnScreenKeyboard keyboard(display, bios);
FileBrowser browser(display, keyboard, drives);

static bool machineReady = false;
static uint32_t lastMicros = 0, lastDraw = 0, lastReport = 0, lastLive = 0;
static uint64_t lastInstr = 0;
static bool cmdMode = false;
static String cmdLine;
static uint8_t escState = 0;       // 0 none, 1 ESC seen, 2 ESC[ or ESC O, 3 ESC[<digit>
static uint8_t escNum = 0;

static void biosLog(const char* line) { Serial.println(line); }

static void showStatus() {
    char s[96];
    snprintf(s, sizeof(s), "A:%s  B:%s  C:%s  %uKB", drives.floppy[0].present() ? drives.floppy[0].path() : "-",
             drives.floppy[1].present() ? drives.floppy[1].path() : "-", drives.hard[0].present() ? drives.hard[0].path() : "-",
             (unsigned)pcMemory.ramKilobytes());
    display.status(s);
}

static void errorScreen(const char* text) {
    Serial.print("ERROR: "); Serial.println(text);
    cga.clear();
    uint8_t* v = pcMemory.video();
    for (int i = 0; text[i] && i < 160; i++) v[i * 2] = (uint8_t)text[i];
    display.update();
}

static bool mountDrive(char which, const char* path) {
    if (which == 'a' || which == 'b') return drives.floppy[which - 'a'].open(path, true);
    if (which == 'c' || which == 'd') return drives.hard[which - 'c'].open(path, false);
    return false;
}

// Create a blank raw hard-disk image in the SD card's FAT filesystem. The
// image is aligned to the emulated geometry so classic CHS-only DOS tools can
// address every sector.
static bool createHardDiskImage(const char* path) {
    if (SD.exists(path)) return true;
    const uint32_t sectors = (uint32_t)POCKET86_HD_CYLINDERS * 16UL * 63UL;
    const uint32_t bytes = sectors * 512UL;
    Serial.printf("[Pocket86] creating %s (%lu bytes) ...\n", path, (unsigned long)bytes);
    File f = SD.open(path, FILE_WRITE);
    if (!f) return false;
    uint8_t zero[4096] = {};
    uint32_t left = bytes;
    while (left) {
        size_t n = left < sizeof(zero) ? left : sizeof(zero);
        if (f.write(zero, n) != n) { f.close(); return false; }
        left -= (uint32_t)n;
    }
    f.flush();
    f.close();
    Serial.println("[Pocket86] /hd.img created");
    return true;
}

static void coldReset() { cpu.reset(); bios.install(); }

// DISK button / "files" command: touch file browser for mounting images. The emulator pauses while it is open.
static void openBrowser() {
    if (!keyboard.touchAvailable()) { Serial.println("file browser needs touch; use: mount a|b|c <path>"); return; }
    if (keyboard.visible()) keyboard.show(false);
    browser.run();
    display.refreshAll();
    keyboard.redraw();
    showStatus();
    lastMicros = micros();                                 // do not count the pause as emulated time
}

static void runCommand(const String& line) {
    String l = line; l.trim();
    if (l.startsWith("mount ")) {
        char which = l.charAt(6);
        String path = l.substring(8); path.trim();
        bool ok = mountDrive(which, path.c_str());
        Serial.println(ok ? "mounted" : "mount failed (file missing or unsupported size)");
        showStatus();
    } else if (l == "files") {
        openBrowser();
    } else if (l == "calibrate") {
        keyboard.calibrate();
    } else if (l == "kbd") {
        keyboard.show(!keyboard.visible());
    } else if (l == "reset") {
        coldReset();
        Serial.println("reset");
    } else if (l == "status") {
        showStatus();
        Serial.printf("RAM %uKB (resident %uKB, swap slots %u, swap in %u out %u), instructions %llu, invalid opcodes %u, ticks %u\n", (unsigned)pcMemory.ramKilobytes(),
                      (unsigned)pcMemory.residentKilobytes(), (unsigned)pcMemory.swapSlots(), (unsigned)pcMemory.swapIns(), (unsigned)pcMemory.swapOuts(),
                      (unsigned long long)cpu.instructionCount(), (unsigned)cpu.invalidCount(), (unsigned)bios.ticks());
    } else {
        Serial.println("commands: mount a|b|c <path>, files, reset, status, calibrate, kbd");
    }
}

// Serial monitors send UTF-8; DOS expects the OEM code page (CP437/850), so map the common German letters.
static uint8_t utf8ToOem(uint16_t cp) {
    switch (cp) {
        case 0xE4: return 0x84; case 0xF6: return 0x94; case 0xFC: return 0x81;   // ae oe ue
        case 0xC4: return 0x8E; case 0xD6: return 0x99; case 0xDC: return 0x9A;   // Ae Oe Ue
        case 0xDF: return 0xE1; case 0xB0: return 0xF8;                           // sz, degree
        case 0xE9: return 0x82; case 0xE8: return 0x8A; case 0xE0: return 0x85;
        default: return 0;
    }
}
static uint8_t utf8Lead = 0;

static void feedSerial() {
    while (Serial.available()) {
        int ch = Serial.read();
        if (ch < 0) break;
        if (cmdMode) {
            if (ch == '\r' || ch == '\n') { if (cmdLine.length()) runCommand(cmdLine); cmdLine = ""; cmdMode = false; }
            else cmdLine += (char)ch;
            continue;
        }
        if (ch == 0x1D) { cmdMode = true; cmdLine = ""; Serial.println("[console] command:"); continue; }
        if (escState == 0) {
            if (ch >= 0xC0) { utf8Lead = (uint8_t)ch; continue; }              // UTF-8 lead byte
            if (ch >= 0x80) {                                                  // UTF-8 continuation byte
                if (utf8Lead) { uint8_t oem = utf8ToOem((uint16_t)(((utf8Lead & 0x1F) << 6) | (ch & 0x3F))); utf8Lead = 0; if (oem) bios.pushKey(oem, 0); }
                continue;
            }
            if (ch == 0x1B) { escState = 1; continue; }
            bios.pushAscii((uint8_t)ch);
        } else if (escState == 1) {
            if (ch == '[' || ch == 'O') { escState = 2; escNum = 0; } else { bios.pushAscii(0x1B); escState = 0; bios.pushAscii((uint8_t)ch); }
        } else {
            if (ch >= '0' && ch <= '9') { escNum = (uint8_t)(escNum * 10 + (ch - '0')); escState = 3; continue; }
            uint8_t scan = 0;
            switch (ch) {
                case 'A': scan = 0x48; break; case 'B': scan = 0x50; break; case 'C': scan = 0x4D; break; case 'D': scan = 0x4B; break;
                case 'H': scan = 0x47; break; case 'F': scan = 0x4F; break;
                case 'P': scan = 0x3B; break; case 'Q': scan = 0x3C; break; case 'R': scan = 0x3D; break; case 'S': scan = 0x3E; break;
                case '~':
                    switch (escNum) {
                        case 1: scan = 0x47; break; case 2: scan = 0x52; break; case 3: scan = 0x53; break; case 4: scan = 0x4F; break;
                        case 5: scan = 0x49; break; case 6: scan = 0x51; break;
                        case 15: scan = 0x3F; break; case 17: scan = 0x40; break; case 18: scan = 0x41; break; case 19: scan = 0x42; break;
                        case 20: scan = 0x43; break; case 21: scan = 0x44; break;
                    }
                    break;
            }
            if (scan) bios.pushScan(scan);
            escState = 0;
        }
    }
}

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println(); Serial.println("[Pocket86] START");
#if defined(CONFIG_BT_ENABLED)
    {   // Bluetooth is never used: hand its reserved controller/host RAM back to the heap (tens of KB of DRAM).
        uint32_t before = heap_caps_get_free_size(MALLOC_CAP_8BIT);
        esp_err_t e = esp_bt_mem_release(ESP_BT_MODE_BTDM);
        Serial.printf("[Pocket86] BT memory release: %s, DRAM free %u -> %u\n", e == ESP_OK ? "ok" : "failed", (unsigned)before, (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
    }
#endif

    if (POCKET86_BL_PIN >= 0) { pinMode(POCKET86_BL_PIN, OUTPUT); digitalWrite(POCKET86_BL_PIN, HIGH); }
    display.begin();
    keyboard.setDiskHandler(openBrowser);                   // DISK button next to KBD (set before begin() draws the handles)
    browser.setResetHandler(coldReset);
    keyboard.begin();                                       // touch + calibration (before SD, like VideoPlayer)
    const char* title = "POCKET86 8086 PC";
    uint8_t* v = pcMemory.video();
    for (int i = 0; title[i]; i++) v[i * 2] = (uint8_t)title[i];
    display.update();

    sdSPI.begin(POCKET86_SD_SCK, POCKET86_SD_MISO, POCKET86_SD_MOSI, POCKET86_SD_CS);
    uint32_t activeSdFreq = POCKET86_SD_FREQ;
    if (!SD.begin(POCKET86_SD_CS, sdSPI, POCKET86_SD_FREQ)) {
        if (POCKET86_SD_FREQ > 40000000 && SD.begin(POCKET86_SD_CS, sdSPI, 40000000)) {
            activeSdFreq = 40000000;
            Serial.println("[Pocket86] SD OK at fallback 40 MHz");
        } else { errorScreen("SD CARD NOT FOUND"); return; }
    }
    if (activeSdFreq == 40000000) Serial.println("[Pocket86] SD OK at 40 MHz");
    else Serial.printf("[Pocket86] SD OK at %lu Hz\n", (unsigned long)activeSdFreq);
    #if USE_SWAP_SD
    pcMemory.configureSwap("/ram.swap");       // experimental: overflow RAM pages on SD
    #endif
    if (SD.exists("/x86BOOT.img")) Serial.println(mountDrive('a', "/x86BOOT.img") ? "[Pocket86] A: /x86BOOT.img" : "[Pocket86] A: unsupported image size");
    else if (SD.exists("/dos.img")) Serial.println(mountDrive('a', "/dos.img") ? "[Pocket86] A: /dos.img (legacy name)" : "[Pocket86] A: unsupported image size");
    if (SD.exists("/x86B.img"))    Serial.println(mountDrive('b', "/x86B.img") ? "[Pocket86] B: /x86B.img" : "[Pocket86] B: unsupported image size");
    #if POCKET86_AUTO_CREATE_HD
    if (!SD.exists("/hd.img") && !createHardDiskImage("/hd.img")) Serial.println("[Pocket86] C: could not create /hd.img");
    #endif
    if (SD.exists("/hd.img"))      Serial.println(mountDrive('c', "/hd.img") ? "[Pocket86] C: /hd.img (SD hard disk)" : "[Pocket86] C: failed");
    if (!drives.floppy[0].present() && !drives.hard[0].present()) { errorScreen("NO DISK IMAGE: put x86BOOT.img on the SD root"); return; }

    Serial.printf("[Pocket86] before RAM allocation: DRAM free %u, IRAM free %u, PSRAM %s\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT), (unsigned)heap_caps_get_free_size(MALLOC_CAP_EXEC), psramFound() ? "yes" : "no");
    pcMemory.allocate(POCKET86_RAM_KB, POCKET86_HEAP_RESERVE);
    uint32_t kb = pcMemory.ramKilobytes();
    Serial.printf("[Pocket86] emulated RAM: %u KB (%u KB of it in IRAM), DRAM left %u\n", (unsigned)kb, (unsigned)pcMemory.iramKilobytes(), (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
    if (kb < POCKET86_MIN_RAM_KB) {
        char m[80];
        snprintf(m, sizeof(m), "NOT ENOUGH RAM: %u KB, need >=%u KB (heap %u)", (unsigned)kb, (unsigned)POCKET86_MIN_RAM_KB, (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
        errorScreen(m);
        return;
    }

    bios.setLogger(biosLog);
    coldReset();
    showStatus();
    machineReady = true;
    lastMicros = micros();
    Serial.println("[Pocket86] running. Keyboard: this serial monitor. Ctrl+] = console command.");
}

void loop() {
    if (!machineReady) { delay(100); return; }
    feedSerial();
    keyboard.poll();

    uint32_t now = micros();
    uint32_t dt = now - lastMicros;
    lastMicros = now;
    bios.advance(dt > 200000UL ? 200000UL : dt);           // real time drives the PIT / IRQ0

    cpu.run(3000);
    if (cpu.blocked() || (cpu.halted() && (cpu.registers().flags & CPU8086::IF))) delay(1);   // idle: let the system breathe

    uint32_t ms = millis();
    if (ms - lastDraw >= 40) { lastDraw = ms; display.update(); }
    if (ms - lastLive >= 1000) {
        lastLive = ms;
        char s[96];
        uint32_t csPhys = (uint32_t)cpu.registers().cs << 4;
        bool outside = csPhys >= pcMemory.ramKilobytes() * 1024UL && csPhys < 0xB8000UL;     // executing where no RAM exists
        if (outside)
            snprintf(s, sizeof(s), "CPU RUNS OUTSIDE RAM (%uKB) - FreeDOS needs >=%uKB", (unsigned)pcMemory.ramKilobytes(), (unsigned)POCKET86_MIN_RAM_KB);
        else
            snprintf(s, sizeof(s), "RAM %uKB  instr %llu  CS:IP %04X:%04X  boot:%s", (unsigned)pcMemory.ramKilobytes(),
                     (unsigned long long)cpu.instructionCount(), cpu.registers().cs, cpu.registers().ip,
                     bios.booted() ? "yes" : (bios.bootFailed() ? "FAILED" : "no"));
        display.status(s, 1);
    }
#if POCKET86_DEBUG
    if (ms - lastReport >= 2000) {
        lastReport = ms;
        uint64_t n = cpu.instructionCount();
        const CPU8086::Registers& r = cpu.registers();
        Serial.printf("[CPU] %llu instr (+%llu/2s) CS:IP=%04X:%04X invalid=%u boot=%d\n", (unsigned long long)n,
                      (unsigned long long)(n - lastInstr), r.cs, r.ip, (unsigned)cpu.invalidCount(), bios.booted() ? 1 : 0);
        lastInstr = n;
    }
#endif
    if (cpu.halted() && !(cpu.registers().flags & CPU8086::IF)) {
        static bool said = false;
        if (!said) { said = true; Serial.println("[CPU] halted with interrupts disabled (Ctrl+] then 'reset')"); }
    }
}
