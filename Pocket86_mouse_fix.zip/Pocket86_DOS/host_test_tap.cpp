// Tap / long-press / move detection test (POCKET86_TAP_MODE=1)
#include <cassert>
#include <cstdio>
#include "BIOS.h"
#include "CGA.h"
#include "CPU8086.h"
#include "Disk.h"
#include "Memory.h"
using namespace Pocket86;
static BIOS* B; static CPU8086* C;
static int btn() { C->registers().ax = 3; B->trap(0x33); return C->registers().bx & 1; }
int main() {
    PCMemory memory; assert(memory.allocate(640));
    CPU8086 cpu(memory); CGA video(memory); Drives drives; BIOS bios(cpu, memory, video, drives);
    B = &bios; C = &cpu; bios.install(); bios.trap(0x101);
    // tap: down 100 ms, no movement -> click (press then release ~60 ms later)
    bios.mouseTouch(100, 100, true); assert(btn() == 0);
    bios.advance(100000); bios.mouseTouch(101, 100, true); assert(btn() == 0);
    bios.advance(25000); bios.mouseTouch(0, 0, false); assert(btn() == 1);
    bios.advance(30000); bios.mouseTouch(0, 0, false); assert(btn() == 1);
    bios.advance(40000); bios.mouseTouch(0, 0, false); assert(btn() == 0);
    // swipe: moves more than slop -> never presses
    bios.advance(100000); bios.mouseTouch(100, 100, true);
    bios.advance(25000); bios.mouseTouch(150, 100, true); assert(btn() == 0);
    bios.advance(25000); bios.mouseTouch(0, 0, false); assert(btn() == 0);
    bios.advance(100000); bios.mouseTouch(0, 0, false); assert(btn() == 0);
    // long press -> button held until release, even while dragging
    bios.mouseTouch(200, 100, true);
    for (int i = 0; i < 20; i++) { bios.advance(25000); bios.mouseTouch(200, 100, true); }
    assert(btn() == 1);
    bios.advance(25000); bios.mouseTouch(260, 120, true); assert(btn() == 1);
    bios.advance(25000); bios.mouseTouch(0, 0, false); assert(btn() == 0);
    puts("tap/long-press/swipe: PASS");
    return 0;
}
