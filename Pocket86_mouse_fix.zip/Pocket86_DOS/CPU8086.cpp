#include "CPU8086.h"
#include <string.h>

namespace Pocket86 {

CPU8086::CPU8086(Memory& m)
    : mem_(m), r_(), pages_(nullptr),
      halted_(false), blocked_(false), irqLine_(false), inhibit_(false),
      instructionCount_(0), invalidCount_(0), lastInvalid_(0), lastInvalidAddr_(0),
      portIn_(nullptr), portOut_(nullptr), portUser_(nullptr),
      trace_(nullptr), traceUser_(nullptr), trapHook_(nullptr), trapUser_(nullptr),
      irqAck_(nullptr), irqUser_(nullptr),
      segOv_(-1), rep_(0), instrStart_(0), eaIsReg_(false), eaReg_(0), eaSeg_(0), eaOff_(0) {
    reset();
}

void CPU8086::reset() {
    memset(&r_, 0, sizeof(r_));
    r_.cs = 0xFFFF;
    r_.flags = 0xF002;
    pages_ = mem_.pageTable();
    halted_ = blocked_ = irqLine_ = inhibit_ = false;
    instructionCount_ = 0;
    invalidCount_ = 0;
}

void CPU8086::setPortCallbacks(PortIn in, PortOut out, void* user) { portIn_ = in; portOut_ = out; portUser_ = user; }

// ---------------------------------------------------------------- stack / interrupts

void CPU8086::push(uint16_t v) { r_.sp = (uint16_t)(r_.sp - 2); wrS16(r_.ss, r_.sp, v); }
uint16_t CPU8086::pop() { uint16_t v = rdS16(r_.ss, r_.sp); r_.sp = (uint16_t)(r_.sp + 2); return v; }

void CPU8086::interrupt(uint8_t n) {
    push((uint16_t)(r_.flags | 0xF002));
    push(r_.cs);
    push(r_.ip);
    r_.flags &= (uint16_t)~(IF | TF);
    r_.ip = rdS16(0, (uint16_t)(n * 4u));
    r_.cs = rdS16(0, (uint16_t)(n * 4u + 2u));
    halted_ = false;
}

bool CPU8086::pollIrq() {
    int v = irqAck_ ? irqAck_(irqUser_) : -1;
    if (v < 0) return false;
    interrupt((uint8_t)v);
    return true;
}

void CPU8086::divideError() { interrupt(0); }

void CPU8086::invalid(uint8_t op) {
    invalidCount_++;
    lastInvalid_ = op;
    lastInvalidAddr_ = physical(r_.cs, instrStart_);
    r_.ip = instrStart_;
    interrupt(6);
}

void CPU8086::handleTrap(uint16_t id) {
    TrapResult tr = trapHook_(trapUser_, *this, id);
    if (tr == TrapReturn) {
        uint16_t nip = pop();
        uint16_t ncs = pop();
        uint16_t nfl = pop();
        const uint16_t arith = CF | PF | AF | ZF | SF | OF;
        r_.flags = (uint16_t)(((nfl & 0x0FD5) & ~arith) | (r_.flags & arith) | 0xF002);
        r_.ip = nip;
        r_.cs = ncs;
    } else if (tr == TrapBlock) {
        // Stay on the stub with interrupts enabled; the caller retries when run() is called again.
        r_.flags |= IF;
        blocked_ = true;
    }
}

// ---------------------------------------------------------------- operand decoding

void CPU8086::decodeModRM(uint8_t m) {
    uint8_t mod = m >> 6, rm = m & 7;
    if (mod == 3) { eaIsReg_ = true; eaReg_ = rm; return; }
    eaIsReg_ = false;
    uint16_t off = 0;
    int seg = 3; // DS
    switch (rm) {
        case 0: off = (uint16_t)(r_.bx + r_.si); break;
        case 1: off = (uint16_t)(r_.bx + r_.di); break;
        case 2: off = (uint16_t)(r_.bp + r_.si); seg = 2; break;
        case 3: off = (uint16_t)(r_.bp + r_.di); seg = 2; break;
        case 4: off = r_.si; break;
        case 5: off = r_.di; break;
        case 6: if (mod == 0) { off = 0; } else { off = r_.bp; seg = 2; } break;
        default: off = r_.bx; break;
    }
    if (mod == 0) {
        if (rm == 6) off = fetch16();
    } else if (mod == 1) {
        off = (uint16_t)(off + (int16_t)(int8_t)fetch8());
    } else {
        off = (uint16_t)(off + fetch16());
    }
    eaOff_ = off;
    eaSeg_ = r_.s[segOv_ >= 0 ? segOv_ : seg];
}

uint8_t CPU8086::getRM8()   { return eaIsReg_ ? reg8(eaReg_) : rdS8(eaSeg_, eaOff_); }
uint16_t CPU8086::getRM16() { return eaIsReg_ ? r_.w[eaReg_] : rdS16(eaSeg_, eaOff_); }
void CPU8086::setRM8(uint8_t v)   { if (eaIsReg_) setReg8(eaReg_, v); else wrS8(eaSeg_, eaOff_, v); }
void CPU8086::setRM16(uint16_t v) { if (eaIsReg_) r_.w[eaReg_] = v; else wrS16(eaSeg_, eaOff_, v); }

// ---------------------------------------------------------------- flags / ALU

void CPU8086::setSZP(uint16_t res, bool w) {
    res &= w ? 0xFFFF : 0xFF;
    uint16_t f = (uint16_t)(r_.flags & ~(SF | ZF | PF));
    if (res == 0) f |= ZF;
    if (res & (w ? 0x8000 : 0x80)) f |= SF;
    if (parityEven((uint8_t)res)) f |= PF;
    r_.flags = f;
}

// kind: 0 ADD, 1 OR, 2 ADC, 3 SBB, 4 AND, 5 SUB, 6 XOR, 7 CMP
uint16_t CPU8086::alu(uint8_t kind, uint16_t a16, uint16_t b16, bool w) {
    uint32_t m = w ? 0xFFFFu : 0xFFu, msb = w ? 0x8000u : 0x80u;
    uint32_t a = a16 & m, b = b16 & m, r = 0;
    bool cf = false, af = false, of = false;
    switch (kind) {
        case 0: case 2: {
            uint32_t c = (kind == 2 && flag(CF)) ? 1u : 0u;
            r = a + b + c;
            cf = r > m; af = ((a ^ b ^ r) & 0x10) != 0; of = ((~(a ^ b) & (a ^ r)) & msb) != 0;
            break;
        }
        case 3: case 5: case 7: {
            uint32_t c = (kind == 3 && flag(CF)) ? 1u : 0u;
            r = a - b - c;
            cf = a < b + c; af = ((a ^ b ^ r) & 0x10) != 0; of = (((a ^ b) & (a ^ r)) & msb) != 0;
            break;
        }
        case 1: r = a | b; break;
        case 4: r = a & b; break;
        default: r = a ^ b; break;
    }
    uint16_t f = r_.flags & ~(CF | AF | OF);
    if (cf) f |= CF;
    if (af) f |= AF;
    if (of) f |= OF;
    r_.flags = f;
    setSZP((uint16_t)r, w);
    return (uint16_t)(r & m);
}

uint16_t CPU8086::incdec(uint16_t v, bool dec, bool w) {
    uint32_t m = w ? 0xFFFFu : 0xFFu, msb = w ? 0x8000u : 0x80u;
    uint32_t a = v & m, r = dec ? (a - 1) & m : (a + 1) & m;
    uint16_t f = r_.flags & ~(AF | OF);
    if ((a ^ r ^ 1) & 0x10) f |= AF;
    if (dec ? (a == msb) : (r == msb)) f |= OF;
    r_.flags = f;
    setSZP((uint16_t)r, w);
    return (uint16_t)r;
}

// kind = ModRM reg field: 0 ROL 1 ROR 2 RCL 3 RCR 4 SHL 5 SHR 6 SAL 7 SAR
uint16_t CPU8086::shiftRotate(uint8_t kind, uint16_t v16, uint8_t count, bool w) {
#if POCKET86_CPU_186
    count &= 0x1F;
#endif
    uint32_t bits = w ? 16 : 8, m = w ? 0xFFFFu : 0xFFu, msb = w ? 0x8000u : 0x80u;
    uint32_t v = v16 & m;
    if (count == 0) return (uint16_t)v;
    bool cf = flag(CF);
    uint32_t prev = v;
    for (uint8_t i = 0; i < count; i++) {
        prev = v;
        switch (kind) {
            case 0: { bool c = (v & msb) != 0; v = ((v << 1) | (c ? 1u : 0u)) & m; cf = c; break; }
            case 1: { bool c = (v & 1) != 0; v = (v >> 1) | (c ? msb : 0u); cf = c; break; }
            case 2: { bool c = (v & msb) != 0; v = ((v << 1) | (cf ? 1u : 0u)) & m; cf = c; break; }
            case 3: { bool c = (v & 1) != 0; v = (v >> 1) | (cf ? msb : 0u); cf = c; break; }
            case 4: case 6: { cf = (v & msb) != 0; v = (v << 1) & m; break; }
            case 5: { cf = (v & 1) != 0; v >>= 1; break; }
            default: { cf = (v & 1) != 0; v = (v >> 1) | (v & msb); break; }
        }
    }
    bool of;
    switch (kind) {
        case 0: case 2: case 4: case 6: of = (((v & msb) != 0) != cf); break;
        case 1: case 3: of = (((v & msb) != 0) != ((v & (msb >> 1)) != 0)); break;
        case 5: of = (prev & msb) != 0; break;
        default: of = false; break;
    }
    uint16_t f = r_.flags & ~(CF | OF);
    if (cf) f |= CF;
    if (of) f |= OF;
    r_.flags = f;
    if (kind >= 4) setSZP((uint16_t)v, w);
    (void)bits;
    return (uint16_t)v;
}

bool CPU8086::condition(uint8_t c) const {
    bool r;
    switch ((c >> 1) & 7) {
        case 0: r = flag(OF); break;
        case 1: r = flag(CF); break;
        case 2: r = flag(ZF); break;
        case 3: r = flag(CF) || flag(ZF); break;
        case 4: r = flag(SF); break;
        case 5: r = flag(PF); break;
        case 6: r = flag(SF) != flag(OF); break;
        default: r = flag(ZF) || (flag(SF) != flag(OF)); break;
    }
    return (c & 1) ? !r : r;
}

// ---------------------------------------------------------------- group 3 (F6/F7)

void CPU8086::group3(bool w) {
    uint8_t m = fetch8();
    decodeModRM(m);
    uint8_t k = (m >> 3) & 7;
    if (!w) {
        uint8_t v = getRM8();
        switch (k) {
            case 0: case 1: alu(4, v, fetch8(), false); setFlag(CF, false); setFlag(OF, false); break;
            case 2: setRM8((uint8_t)~v); break;
            case 3: setRM8((uint8_t)alu(5, 0, v, false)); break;
            case 4: { uint16_t p = (uint16_t)(reg8(0) * v); r_.ax = p; bool c = (p >> 8) != 0; setFlag(CF, c); setFlag(OF, c); break; }
            case 5: { int16_t p = (int16_t)((int8_t)reg8(0) * (int8_t)v); r_.ax = (uint16_t)p; bool c = (p != (int16_t)(int8_t)p); setFlag(CF, c); setFlag(OF, c); break; }
            case 6: {
                if (v == 0) { divideError(); break; }
                uint16_t n = r_.ax; uint16_t q = (uint16_t)(n / v);
                if (q > 0xFF) { divideError(); break; }
                setReg8(0, (uint8_t)q); setReg8(4, (uint8_t)(n % v));
                break;
            }
            default: {
                int8_t d = (int8_t)v;
                if (d == 0) { divideError(); break; }
                int16_t n = (int16_t)r_.ax; int32_t q = n / d, rem = n % d;
                if (q > 127 || q < -128) { divideError(); break; }
                setReg8(0, (uint8_t)q); setReg8(4, (uint8_t)rem);
                break;
            }
        }
    } else {
        uint16_t v = getRM16();
        switch (k) {
            case 0: case 1: alu(4, v, fetch16(), true); setFlag(CF, false); setFlag(OF, false); break;
            case 2: setRM16((uint16_t)~v); break;
            case 3: setRM16(alu(5, 0, v, true)); break;
            case 4: { uint32_t p = (uint32_t)r_.ax * v; r_.ax = (uint16_t)p; r_.dx = (uint16_t)(p >> 16); bool c = r_.dx != 0; setFlag(CF, c); setFlag(OF, c); break; }
            case 5: { int32_t p = (int32_t)(int16_t)r_.ax * (int32_t)(int16_t)v; r_.ax = (uint16_t)p; r_.dx = (uint16_t)((uint32_t)p >> 16); bool c = (p != (int32_t)(int16_t)p); setFlag(CF, c); setFlag(OF, c); break; }
            case 6: {
                if (v == 0) { divideError(); break; }
                uint32_t n = ((uint32_t)r_.dx << 16) | r_.ax; uint32_t q = n / v;
                if (q > 0xFFFF) { divideError(); break; }
                r_.ax = (uint16_t)q; r_.dx = (uint16_t)(n % v);
                break;
            }
            default: {
                int16_t d = (int16_t)v;
                if (d == 0) { divideError(); break; }
                int64_t n = (int32_t)(((uint32_t)r_.dx << 16) | r_.ax); int64_t q = n / d, rem = n % d;
                if (q > 32767 || q < -32768) { divideError(); break; }
                r_.ax = (uint16_t)q; r_.dx = (uint16_t)rem;
                break;
            }
        }
    }
}

// ---------------------------------------------------------------- string instructions

void CPU8086::stringOp(uint8_t op) {
    bool w = (op & 1) != 0;
    int16_t d = flag(DF) ? (w ? -2 : -1) : (w ? 2 : 1);
    bool cmpKind = (op == 0xA6 || op == 0xA7 || op == 0xAE || op == 0xAF);
    uint16_t sseg = srcSeg();
    if (rep_ && r_.cx == 0) return;
    for (;;) {
        switch (op) {
            case 0xA4: case 0xA5:
                if (w) wrS16(r_.es, r_.di, rdS16(sseg, r_.si)); else wrS8(r_.es, r_.di, rdS8(sseg, r_.si));
                r_.si = (uint16_t)(r_.si + d); r_.di = (uint16_t)(r_.di + d); break;
            case 0xA6: case 0xA7:
                if (w) alu(7, rdS16(sseg, r_.si), rdS16(r_.es, r_.di), true); else alu(7, rdS8(sseg, r_.si), rdS8(r_.es, r_.di), false);
                r_.si = (uint16_t)(r_.si + d); r_.di = (uint16_t)(r_.di + d); break;
            case 0xAA: case 0xAB:
                if (w) wrS16(r_.es, r_.di, r_.ax); else wrS8(r_.es, r_.di, reg8(0));
                r_.di = (uint16_t)(r_.di + d); break;
            case 0xAC: case 0xAD:
                if (w) r_.ax = rdS16(sseg, r_.si); else setReg8(0, rdS8(sseg, r_.si));
                r_.si = (uint16_t)(r_.si + d); break;
            case 0xAE: case 0xAF:
                if (w) alu(7, r_.ax, rdS16(r_.es, r_.di), true); else alu(7, reg8(0), rdS8(r_.es, r_.di), false);
                r_.di = (uint16_t)(r_.di + d); break;
            case 0x6C: case 0x6D:
                if (w) { uint16_t v = (uint16_t)(portIn8(r_.dx) | (portIn8((uint16_t)(r_.dx + 1)) << 8)); wrS16(r_.es, r_.di, v); }
                else wrS8(r_.es, r_.di, portIn8(r_.dx));
                r_.di = (uint16_t)(r_.di + d); break;
            case 0x6E: case 0x6F:
                if (w) { uint16_t v = rdS16(sseg, r_.si); portOut8(r_.dx, (uint8_t)v); portOut8((uint16_t)(r_.dx + 1), (uint8_t)(v >> 8)); }
                else portOut8(r_.dx, rdS8(sseg, r_.si));
                r_.si = (uint16_t)(r_.si + d); break;
            default: break;
        }
        if (!rep_) return;
        r_.cx--;
        if (r_.cx == 0) return;
        if (cmpKind) {
            if (rep_ == 1 && !flag(ZF)) return;
            if (rep_ == 2 && flag(ZF)) return;
        }
        if (irqLine_ && flag(IF)) { r_.ip = instrStart_; return; }  // let the interrupt in, then resume the REP
    }
}

// ---------------------------------------------------------------- main decoder

void CPU8086::execute(uint8_t op) {
    if (op < 0x40 && (op & 6) != 6) {
        uint8_t k = (op >> 3) & 7;
        switch (op & 7) {
            case 0: { uint8_t m = fetch8(); decodeModRM(m); uint8_t r = (uint8_t)alu(k, getRM8(), reg8((m >> 3) & 7), false); if (k != 7) setRM8(r); return; }
            case 1: { uint8_t m = fetch8(); decodeModRM(m); uint16_t r = alu(k, getRM16(), r_.w[(m >> 3) & 7], true); if (k != 7) setRM16(r); return; }
            case 2: { uint8_t m = fetch8(); decodeModRM(m); uint8_t reg = (m >> 3) & 7; uint8_t r = (uint8_t)alu(k, reg8(reg), getRM8(), false); if (k != 7) setReg8(reg, r); return; }
            case 3: { uint8_t m = fetch8(); decodeModRM(m); uint8_t reg = (m >> 3) & 7; uint16_t r = alu(k, r_.w[reg], getRM16(), true); if (k != 7) r_.w[reg] = r; return; }
            case 4: { uint8_t r = (uint8_t)alu(k, reg8(0), fetch8(), false); if (k != 7) setReg8(0, r); return; }
            default: { uint16_t r = alu(k, r_.ax, fetch16(), true); if (k != 7) r_.ax = r; return; }
        }
    }

    switch (op) {
        // ---- segment push/pop, BCD
        case 0x06: push(r_.es); return;
        case 0x0E: push(r_.cs); return;
        case 0x16: push(r_.ss); return;
        case 0x1E: push(r_.ds); return;
        case 0x07: r_.es = pop(); return;
        case 0x17: r_.ss = pop(); inhibit_ = true; return;
        case 0x1F: r_.ds = pop(); return;
        case 0x27: { // DAA
            uint8_t al = reg8(0); bool cf = flag(CF), af = flag(AF);
            if (((al & 0x0F) > 9) || af) { if (al > 0x99 || cf) { al = (uint8_t)(al + 0x60); cf = true; } else cf = false; al = (uint8_t)(al + 6); af = true; }
            else { if (al > 0x99 || cf) { al = (uint8_t)(al + 0x60); cf = true; } else cf = false; af = false; }
            setReg8(0, al); setFlag(CF, cf); setFlag(AF, af); setSZP(al, false); return;
        }
        case 0x2F: { // DAS
            uint8_t al = reg8(0); bool cf = flag(CF), af = flag(AF);
            if (((al & 0x0F) > 9) || af) {
                if (al > 0x99 || cf) { al = (uint8_t)(al - 0x60); cf = true; } else cf = (al <= 5);
                al = (uint8_t)(al - 6); af = true;
            } else { if (al > 0x99 || cf) { al = (uint8_t)(al - 0x60); cf = true; } else cf = false; af = false; }
            setReg8(0, al); setFlag(CF, cf); setFlag(AF, af); setSZP(al, false); return;
        }
        case 0x37: { // AAA
            uint8_t al = reg8(0), ah = reg8(4);
            if (((al & 0x0F) > 9) || flag(AF)) { al = (uint8_t)(al + 6); ah = (uint8_t)(ah + 1); setFlag(AF, true); setFlag(CF, true); }
            else { setFlag(AF, false); setFlag(CF, false); }
            setReg8(0, al & 0x0F); setReg8(4, ah); return;
        }
        case 0x3F: { // AAS
            uint8_t al = reg8(0), ah = reg8(4);
            if (((al & 0x0F) > 9) || flag(AF)) { al = (uint8_t)(al - 6); ah = (uint8_t)(ah - 1); setFlag(AF, true); setFlag(CF, true); }
            else { setFlag(AF, false); setFlag(CF, false); }
            setReg8(0, al & 0x0F); setReg8(4, ah); return;
        }

        // ---- INC/DEC/PUSH/POP reg
        case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
        case 0x48: case 0x49: case 0x4A: case 0x4B: case 0x4C: case 0x4D: case 0x4E: case 0x4F:
            r_.w[op & 7] = incdec(r_.w[op & 7], op >= 0x48, true); return;
        case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57:
            { uint16_t v = r_.w[op & 7];
#if !POCKET86_CPU_186
              if ((op & 7) == 4) v = (uint16_t)(v - 2);   // 8086 pushes the decremented SP
#endif
              push(v); return; }
        case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F:
            { uint16_t v = pop(); r_.w[op & 7] = v; return; }

        // ---- 80186 additions
        case 0x60: { uint16_t t = r_.sp; push(r_.ax); push(r_.cx); push(r_.dx); push(r_.bx); push(t); push(r_.bp); push(r_.si); push(r_.di); return; }
        case 0x61: { r_.di = pop(); r_.si = pop(); r_.bp = pop(); pop(); r_.bx = pop(); r_.dx = pop(); r_.cx = pop(); r_.ax = pop(); return; }
        case 0x62: { uint8_t m = fetch8(); decodeModRM(m); if (eaIsReg_) { invalid(op); return; }
            int16_t idx = (int16_t)r_.w[(m >> 3) & 7], lo = (int16_t)rdS16(eaSeg_, eaOff_), hi = (int16_t)rdS16(eaSeg_, (uint16_t)(eaOff_ + 2));
            if (idx < lo || idx > hi) { r_.ip = instrStart_; interrupt(5); } return; }
        case 0x68: push(fetch16()); return;
        case 0x6A: push((uint16_t)(int16_t)(int8_t)fetch8()); return;
        case 0x69: case 0x6B: {
            uint8_t m = fetch8(); decodeModRM(m); int32_t a = (int16_t)getRM16();
            int32_t b = (op == 0x69) ? (int16_t)fetch16() : (int16_t)(int8_t)fetch8();
            int32_t p = a * b; r_.w[(m >> 3) & 7] = (uint16_t)p; bool c = (p != (int32_t)(int16_t)p); setFlag(CF, c); setFlag(OF, c); return; }
        case 0x6C: case 0x6D: case 0x6E: case 0x6F: stringOp(op); return;

        // ---- conditional jumps
        case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
        case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F:
            { int8_t d = (int8_t)fetch8(); if (condition(op & 15)) r_.ip = (uint16_t)(r_.ip + d); return; }

        // ---- group 1
        case 0x80: case 0x81: case 0x82: case 0x83: {
            bool w = (op & 1) != 0; uint8_t m = fetch8(); decodeModRM(m); uint8_t k = (m >> 3) & 7;
            if (!w) { uint8_t a = getRM8(); uint8_t b = fetch8(); uint8_t r = (uint8_t)alu(k, a, b, false); if (k != 7) setRM8(r); }
            else {
                uint16_t a = getRM16(); uint16_t b = (op == 0x83) ? (uint16_t)(int16_t)(int8_t)fetch8() : fetch16();
                uint16_t r = alu(k, a, b, true); if (k != 7) setRM16(r);
            }
            return;
        }
        case 0x84: { uint8_t m = fetch8(); decodeModRM(m); alu(4, getRM8(), reg8((m >> 3) & 7), false); return; }
        case 0x85: { uint8_t m = fetch8(); decodeModRM(m); alu(4, getRM16(), r_.w[(m >> 3) & 7], true); return; }
        case 0x86: { uint8_t m = fetch8(); decodeModRM(m); uint8_t reg = (m >> 3) & 7; uint8_t a = getRM8(); setRM8(reg8(reg)); setReg8(reg, a); return; }
        case 0x87: { uint8_t m = fetch8(); decodeModRM(m); uint8_t reg = (m >> 3) & 7; uint16_t a = getRM16(); setRM16(r_.w[reg]); r_.w[reg] = a; return; }
        case 0x88: { uint8_t m = fetch8(); decodeModRM(m); setRM8(reg8((m >> 3) & 7)); return; }
        case 0x89: { uint8_t m = fetch8(); decodeModRM(m); setRM16(r_.w[(m >> 3) & 7]); return; }
        case 0x8A: { uint8_t m = fetch8(); decodeModRM(m); setReg8((m >> 3) & 7, getRM8()); return; }
        case 0x8B: { uint8_t m = fetch8(); decodeModRM(m); r_.w[(m >> 3) & 7] = getRM16(); return; }
        case 0x8C: { uint8_t m = fetch8(); decodeModRM(m); setRM16(r_.s[(m >> 3) & 3]); return; }
        case 0x8D: { uint8_t m = fetch8(); decodeModRM(m); if (eaIsReg_) { invalid(op); return; } r_.w[(m >> 3) & 7] = eaOff_; return; }
        case 0x8E: { uint8_t m = fetch8(); decodeModRM(m); uint8_t sr = (m >> 3) & 3; r_.s[sr] = getRM16(); if (sr == 2) inhibit_ = true; return; }
        case 0x8F: { uint8_t m = fetch8(); decodeModRM(m); uint16_t v = pop(); setRM16(v); return; }

        // ---- XCHG AX,r / CBW / CWD / CALL far / flags
        case 0x90: return;
        case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97:
            { uint16_t t = r_.ax; r_.ax = r_.w[op & 7]; r_.w[op & 7] = t; return; }
        case 0x98: r_.ax = (uint16_t)(int16_t)(int8_t)reg8(0); return;
        case 0x99: r_.dx = (r_.ax & 0x8000) ? 0xFFFF : 0; return;
        case 0x9A: { uint16_t off = fetch16(), seg = fetch16(); push(r_.cs); push(r_.ip); r_.cs = seg; r_.ip = off; return; }
        case 0x9B: return;
        case 0x9C: push((uint16_t)(r_.flags | 0xF002)); return;
        case 0x9D: r_.flags = (uint16_t)((pop() & 0x0FD5) | 0xF002); return;
        case 0x9E: r_.flags = (uint16_t)((r_.flags & 0xFF00) | (reg8(4) & 0xD5) | 0x02); return;
        case 0x9F: setReg8(4, (uint8_t)((r_.flags & 0xD5) | 0x02)); return;

        // ---- MOV accumulator <-> moffs
        case 0xA0: { uint16_t o = fetch16(); setReg8(0, rdS8(srcSeg(), o)); return; }
        case 0xA1: { uint16_t o = fetch16(); r_.ax = rdS16(srcSeg(), o); return; }
        case 0xA2: { uint16_t o = fetch16(); wrS8(srcSeg(), o, reg8(0)); return; }
        case 0xA3: { uint16_t o = fetch16(); wrS16(srcSeg(), o, r_.ax); return; }

        case 0xA4: case 0xA5: case 0xA6: case 0xA7: case 0xAA: case 0xAB: case 0xAC: case 0xAD: case 0xAE: case 0xAF:
            stringOp(op); return;
        case 0xA8: alu(4, reg8(0), fetch8(), false); return;
        case 0xA9: alu(4, r_.ax, fetch16(), true); return;

        // ---- MOV immediate
        case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7:
            setReg8(op & 7, fetch8()); return;
        case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF:
            r_.w[op & 7] = fetch16(); return;

        // ---- shifts by imm8 (186), RET, LES/LDS, MOV r/m,imm
        case 0xC0: case 0xC1: {
            bool w = (op & 1) != 0; uint8_t m = fetch8(); decodeModRM(m); uint8_t cnt = fetch8(); uint8_t k = (m >> 3) & 7;
            if (w) setRM16(shiftRotate(k, getRM16(), cnt, true)); else setRM8((uint8_t)shiftRotate(k, getRM8(), cnt, false));
            return;
        }
        case 0xC2: { uint16_t n = fetch16(); r_.ip = pop(); r_.sp = (uint16_t)(r_.sp + n); return; }
        case 0xC3: r_.ip = pop(); return;
        case 0xC4: case 0xC5: {
            uint8_t m = fetch8(); decodeModRM(m); if (eaIsReg_) { invalid(op); return; }
            uint16_t off = rdS16(eaSeg_, eaOff_), seg = rdS16(eaSeg_, (uint16_t)(eaOff_ + 2));
            r_.w[(m >> 3) & 7] = off; if (op == 0xC4) r_.es = seg; else r_.ds = seg; return;
        }
        case 0xC6: { uint8_t m = fetch8(); decodeModRM(m); setRM8(fetch8()); return; }
        case 0xC7: { uint8_t m = fetch8(); decodeModRM(m); setRM16(fetch16()); return; }
        case 0xC8: { // ENTER
            uint16_t size = fetch16(); uint8_t level = fetch8() & 0x1F;
            push(r_.bp); uint16_t frame = r_.sp;
            if (level > 0) { uint16_t bp = r_.bp; for (uint8_t i = 1; i < level; i++) { bp = (uint16_t)(bp - 2); push(rdS16(r_.ss, bp)); } push(frame); }
            r_.bp = frame; r_.sp = (uint16_t)(r_.sp - size); return;
        }
        case 0xC9: r_.sp = r_.bp; r_.bp = pop(); return;
        case 0xCA: { uint16_t n = fetch16(); r_.ip = pop(); r_.cs = pop(); r_.sp = (uint16_t)(r_.sp + n); return; }
        case 0xCB: r_.ip = pop(); r_.cs = pop(); return;
        case 0xCC: interrupt(3); return;
        case 0xCD: { uint8_t n = fetch8(); interrupt(n); return; }
        case 0xCE: if (flag(OF)) interrupt(4); return;
        case 0xCF: r_.ip = pop(); r_.cs = pop(); r_.flags = (uint16_t)((pop() & 0x0FD5) | 0xF002); return;

        // ---- shifts / rotates by 1 or CL
        case 0xD0: case 0xD1: case 0xD2: case 0xD3: {
            bool w = (op & 1) != 0; uint8_t m = fetch8(); decodeModRM(m); uint8_t cnt = (op & 2) ? reg8(1) : 1; uint8_t k = (m >> 3) & 7;
            if (w) setRM16(shiftRotate(k, getRM16(), cnt, true)); else setRM8((uint8_t)shiftRotate(k, getRM8(), cnt, false));
            return;
        }
        case 0xD4: { uint8_t b = fetch8(); if (b == 0) { divideError(); return; } uint8_t al = reg8(0); setReg8(4, al / b); setReg8(0, al % b); setSZP(reg8(0), false); return; }
        case 0xD5: { uint8_t b = fetch8(); uint8_t v = (uint8_t)(reg8(0) + reg8(4) * b); setReg8(0, v); setReg8(4, 0); setSZP(v, false); return; }
        case 0xD6: setReg8(0, flag(CF) ? 0xFF : 0x00); return;
        case 0xD7: setReg8(0, rdS8(srcSeg(), (uint16_t)(r_.bx + reg8(0)))); return;
        case 0xD8: case 0xD9: case 0xDA: case 0xDB: case 0xDC: case 0xDD: case 0xDE: case 0xDF:
            { uint8_t m = fetch8(); decodeModRM(m); return; }   // FPU escape: no coprocessor, ignore

        // ---- loops
        case 0xE0: case 0xE1: case 0xE2: {
            int8_t d = (int8_t)fetch8(); r_.cx--;
            bool take = r_.cx != 0 && (op == 0xE2 || (op == 0xE1 ? flag(ZF) : !flag(ZF)));
            if (take) { r_.ip = (uint16_t)(r_.ip + d); }
            return;
        }
        case 0xE3: { int8_t d = (int8_t)fetch8(); if (r_.cx == 0) r_.ip = (uint16_t)(r_.ip + d); return; }

        // ---- port I/O
        case 0xE4: setReg8(0, portIn8(fetch8())); return;
        case 0xE5: { uint8_t p = fetch8(); uint8_t lo = portIn8(p), hi = portIn8((uint8_t)(p + 1)); r_.ax = (uint16_t)(lo | (hi << 8)); return; }
        case 0xE6: portOut8(fetch8(), reg8(0)); return;
        case 0xE7: { uint8_t p = fetch8(); portOut8(p, reg8(0)); portOut8((uint8_t)(p + 1), reg8(4)); return; }
        case 0xEC: setReg8(0, portIn8(r_.dx)); return;
        case 0xED: { uint8_t lo = portIn8(r_.dx), hi = portIn8((uint16_t)(r_.dx + 1)); r_.ax = (uint16_t)(lo | (hi << 8)); return; }
        case 0xEE: portOut8(r_.dx, reg8(0)); return;
        case 0xEF: portOut8(r_.dx, reg8(0)); portOut8((uint16_t)(r_.dx + 1), reg8(4)); return;

        // ---- jumps / calls
        case 0xE8: { int16_t d = (int16_t)fetch16(); push(r_.ip); r_.ip = (uint16_t)(r_.ip + d); return; }
        case 0xE9: { int16_t d = (int16_t)fetch16(); r_.ip = (uint16_t)(r_.ip + d); return; }
        case 0xEA: { uint16_t off = fetch16(), seg = fetch16(); r_.ip = off; r_.cs = seg; return; }
        case 0xEB: { int8_t d = (int8_t)fetch8(); r_.ip = (uint16_t)(r_.ip + d); return; }

        case 0xF1: return;
        case 0xF4: halted_ = true; return;
        case 0xF5: setFlag(CF, !flag(CF)); return;
        case 0xF6: group3(false); return;
        case 0xF7: group3(true); return;
        case 0xF8: setFlag(CF, false); return;
        case 0xF9: setFlag(CF, true); return;
        case 0xFA: setFlag(IF, false); return;
        case 0xFB: setFlag(IF, true); inhibit_ = true; return;
        case 0xFC: setFlag(DF, false); return;
        case 0xFD: setFlag(DF, true); return;

        case 0xFE: {
            uint8_t m = fetch8(); decodeModRM(m); uint8_t k = (m >> 3) & 7;
            if (k > 1) { invalid(op); return; }
            setRM8((uint8_t)incdec(getRM8(), k == 1, false)); return;
        }
        case 0xFF: {
            uint8_t m = fetch8(); decodeModRM(m); uint8_t k = (m >> 3) & 7;
            switch (k) {
                case 0: case 1: setRM16(incdec(getRM16(), k == 1, true)); return;
                case 2: { uint16_t t = getRM16(); push(r_.ip); r_.ip = t; return; }
                case 3: { if (eaIsReg_) { invalid(op); return; }
                    uint16_t off = rdS16(eaSeg_, eaOff_), seg = rdS16(eaSeg_, (uint16_t)(eaOff_ + 2));
                    push(r_.cs); push(r_.ip); r_.cs = seg; r_.ip = off; return; }
                case 4: r_.ip = getRM16(); return;
                case 5: { if (eaIsReg_) { invalid(op); return; }
                    uint16_t off = rdS16(eaSeg_, eaOff_), seg = rdS16(eaSeg_, (uint16_t)(eaOff_ + 2));
                    r_.cs = seg; r_.ip = off; return; }
                default: { uint16_t v = getRM16(); push(v); return; }
            }
        }
        default:
            invalid(op);
            return;
    }
}

// ---------------------------------------------------------------- stepping

bool CPU8086::step() {
    if (halted_) {
        if (irqLine_ && flag(IF) && pollIrq()) { /* woke up and entered the handler */ }
        return false;
    }
    bool tf = flag(TF);
    if (inhibit_) {
        inhibit_ = false;
    } else if (irqLine_ && flag(IF)) {
        if (pollIrq()) { instructionCount_++; return true; }
    }

    if (r_.cs == TrapSegment && (uint16_t)(r_.ip - TrapBase) < TrapCount && trapHook_) {
        handleTrap((uint16_t)(r_.ip - TrapBase));
        instructionCount_++;
        return true;
    }

    if (trace_) trace_(traceUser_, r_, rdS8(r_.cs, r_.ip));

    instrStart_ = r_.ip;
    segOv_ = -1;
    rep_ = 0;
    uint8_t op;
    for (;;) {
        op = fetch8();
        if (op == 0x26) segOv_ = 0;
        else if (op == 0x2E) segOv_ = 1;
        else if (op == 0x36) segOv_ = 2;
        else if (op == 0x3E) segOv_ = 3;
        else if (op == 0xF2) rep_ = 2;
        else if (op == 0xF3) rep_ = 1;
        else if (op == 0xF0) { /* LOCK: no effect */ }
        else break;
    }
    execute(op);
    instructionCount_++;
    if (tf && !halted_ && flag(TF) == true) interrupt(1);
    return true;
}

uint64_t CPU8086::run(uint64_t maxInstructions) {
    uint64_t n = 0;
    blocked_ = false;
    while (n < maxInstructions) {
        if (!step()) break;
        n++;
        if (blocked_) break;
    }
    return n;
}

} // namespace Pocket86
